package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StartJobWidget extends Page {

    @FindBy(xpath = "//span[contains(.,'START')]")
    private WebElement start;

    @FindBy(xpath = "//span[contains(.,'Cancel')]")
    private WebElement cancel;

    public StartJobWidget(WebDriver driver) {
        super(driver);
    }

    public void clickStart() {
        element.click(start);
    }

    public void clickCancel() {
        element.click(cancel);
    }

}
