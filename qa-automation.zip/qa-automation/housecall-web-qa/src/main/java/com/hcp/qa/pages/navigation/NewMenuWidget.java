package com.hcp.qa.pages.navigation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class NewMenuWidget extends Page {

	@FindBy(xpath = "//li[@data-testid='add-new-job']")
	private WebElement job;

	@FindBy(xpath = "//li[@data-testid='add-new-proposal']")
	private WebElement proposal;

	@FindBy(xpath = "//li[@data-testid='add-new-estimate']")
	private WebElement estimate;

	@FindBy(xpath = "//li[@data-testid='add-new-event']")
	private WebElement event;

	@FindBy(xpath = "//li[@data-testid='add-new-customer']")
	private WebElement customer;

	public NewMenuWidget(WebDriver driver) {
		super(driver);
	}

	public void clickJob() {
		waitHelper.waitForElementToBeClickable(job);
		job.click();
	}

	public void clickProposal() {
		proposal.click();
	}

	public void clickEstimate() {
		waitHelper.waitForElementToBeClickable(estimate);
		estimate.click();
	}

	public void clickEvent() {
		waitHelper.waitForElementToBeClickable(event);
		event.click();
	}

	public void clickCustomer() {
		waitHelper.waitForElementToBeClickable(customer);
		customer.click();
	}

}
