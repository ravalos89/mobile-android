package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.pages.admin.AdminLoginPage;
import com.hcp.qa.pages.admin.AdminPage;
import com.hcp.qa.pages.billing.pages.MyPlanPage;

public class AdminHelper {

	private final WaitHelper waitHelper;
	String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");

	String adminUser = ConfigHandler.getStringPropertyValueFromKey("hcp.web.admin.user");

	String adminPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.admin.password");

	String adminHCPAssistUser = ConfigHandler.getStringPropertyValueFromKey("hcp.web.admin.hcpassist.user");

	String adminHCPAssistPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.admin.hcpassist.password");

	private String adminUrl = baseUrl + "/admin";

	private String oldAdminUrl = baseUrl + "/admin/old";

	WebDriver driver;

	public AdminHelper(WebDriver driver) {
		this.driver = driver;
		this.waitHelper = new WaitHelper(driver);
	}

	public void goToAdminPage() {
		driver.navigate().to(adminUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToOldAdminPage() {
		driver.navigate().to(oldAdminUrl);
	}

	public void login() {
		goToAdminPage();
		AdminLoginPage admin = new AdminLoginPage(driver);
		if(ConfigHandler.getTargetEnv().equals("preflight"))
		admin.clickShowEmailLink();
		admin.setEmail(adminUser);
		admin.setPassword(adminPassword);
		admin.clickSubmit();
		waitHelper.waitForPageLoaded();
	}

	public void navigateToHCPAssist() {
		AdminPage admin = new AdminPage(driver);
		admin.clickHamburgerMenu();
		admin.clickHCPAssist();
	}

	public MyPlanPage navigateToCompanyMyPlanPage(String orgId) {
		driver.navigate().to(adminUrl + "/companies/" + orgId);
		waitHelper.waitForPageLoaded();

		return new MyPlanPage(driver); }

	public void loginAsHCPAssistUser() {
		AdminLoginPage admin = new AdminLoginPage(driver);
		admin.waitForPageToLoad(1);
		goToAdminPage();		
		admin.setEmail(adminHCPAssistUser);
		admin.setPassword(adminHCPAssistPassword);
		admin.clickSubmit();
	}

	public void logout() {
		goToAdminPage();
		AdminPage admin = new AdminPage(driver);
		admin.clickProfileIcon();
		admin.clickLogout();
	}

}
