package com.hcp.qa.pages.jobfields;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

import static org.openqa.selenium.By.xpath;

public class JobFieldDialog extends Page {

	@FindBy(xpath = "//p[.='Job fields']")
	WebElement addJobField;

	@FindBy(css = "[data-testid='job-field-select-autocomplete']")
	private WebElement jobTypeOnJob;
	
	@FindBy(xpath = "(//input[@data-testid='job-field-select-autocomplete'])[2]")
	private WebElement bussinessUnitOnJob;

	@FindBy(xpath = "//button[@title='Clear']")
	private WebElement jobTypeClose;
	
	@FindBy(xpath = "(//button[@title='Clear'])[2]")
	private WebElement bussinessUnitClose;

	public JobFieldDialog(WebDriver driver) {
		super(driver);
	}

	public void addJobTypeToJob(String jobType) {
		element.click(addJobField);
		element.type(jobTypeOnJob, jobType);
		element.click(xpath("//*[.='"+jobType+"']"));
	}
	
	public void addBusinessUnitToJob(String businessUnit) {
		bussinessUnitOnJob.sendKeys(businessUnit);
		element.click(xpath("//*[.='"+businessUnit+"']"));
	}

	public void deleteJobType() {
		element.click(jobTypeOnJob);
		element.click(jobTypeClose);
		element.click(jobTypeOnJob);
	}
	public void deleteBusinessUnit() {
		element.click(bussinessUnitOnJob);
		element.click(bussinessUnitClose);
	}

	public boolean isJobFieldAdded(String JobFieldName) {
	
		return element.isDisplayed(xpath("//input[@value='"+JobFieldName+"']"));
	}

}