package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.pages.common.Page;

import static java.time.Duration.ofSeconds;

public class HCPClientLoginPage extends Page{
	
	@FindBy(xpath="//input[@name='passwordConfirmation']")
	private WebElement confirmPasswordToViewPaln;

	@FindBy(id = "email")
	private WebElement email;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(xpath = "//span[text()='SIGN IN']")
	private WebElement signInBtn;

	public HCPClientLoginPage(WebDriver driver) {
		super(driver);
	}
		
	public boolean verifyServicePlanConfirmation(String planName) {
		try {
			new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS))
			.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[.='"+planName+"']")));
			return true;
		} catch(NoSuchElementException e) {
			return false;
		}		
	}

	public void signInHcpClient(String email,String password) {
		element.type(this.email, email);
		element.type(this.password, password);
		element.click(signInBtn);
	}

}
