package com.hcp.qa.pages.dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class OpenEstimatesWidget extends Page{
	
	@FindBy(xpath = "//span[@title='Add estimate']")
	private WebElement addEstimateIcon;

	public OpenEstimatesWidget(WebDriver driver) {
		super(driver);
	}

	public void clickAddEstimateIcon() {
		waitHelper.waitForElementToBeNotVisible(By.xpath("//span[contains(.,'Open estimates')]/ancestor::div/following-sibling::div[@role='progressbar']"));
		waitHelper.waitForElementToBeClickable(addEstimateIcon, LONG_WAIT_TIME_IN_SECS).click();
	}
}
