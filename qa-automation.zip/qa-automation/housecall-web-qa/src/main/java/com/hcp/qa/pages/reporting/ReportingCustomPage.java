package com.hcp.qa.pages.reporting;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.pages.common.Page;
import com.hcp.qa.reports.ReportUtils;

public class ReportingCustomPage extends Page {
	
	ReportUtils reportUtils = new ReportUtils();

	@FindBy(xpath = "//tr/td[1]//span")
	List<WebElement> reportNames;
	
	@FindBy(xpath="//button[@aria-label='more menu']")
	List<WebElement> moreMenuBtn;
	
	@FindBy(xpath="//li[contains(text(),'Delete')]")
	WebElement deleteBtn;
	
	@FindBy(xpath="//span[contains(text(),'Delete')]")
	WebElement confirmDeleteBtn;
	
	public ReportingCustomPage(WebDriver driver) {
		super(driver);
	}

	public void verifyReportName(String expectedReportName) {
		waitHelper.waitForPageLoaded();
		List<String> reportNameOptions = new ArrayList<>();

		for (WebElement reportName : reportNames) {
			reportNameOptions.add(element.getText(reportName));
		}

		if (reportNameOptions.contains(expectedReportName)) {
			reportUtils.reporter("The report was successfully created", expectedReportName);
		} else {
			reportUtils.fail("Report is not in the list: " + reportNames);
		}
	}
	
	public void deleteCustomReports() {
		boolean flag = false;
		waitHelper.waitForPageLoaded();

		do {
			element.click(moreMenuBtn.get(0));
			element.click(deleteBtn);
			element.click(confirmDeleteBtn);
			waitHelper.waitForPageLoaded();
			reportUtils.reporter("The report was successfully","deleted");
			Sleep.seconds(7);

			if (driver.findElements(By.xpath("//button[@aria-label='more menu']")).size() > 0) {
				moreMenuBtn = driver.findElements(By.xpath("//button[@aria-label='more menu']"));

			} else {
				flag = true;
			}
		} while (flag == false);

	}

}
