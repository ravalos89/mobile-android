package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FieldTechWidget extends Page {

    @FindBy(xpath = "//h3//*[contains(text(),'Field tech status')]")
    private WebElement fieldTechHeader;

    @FindBy(css = ".MuiTable-root tbody tr td:nth-child(5) div")
    private WebElement fieldTechArrow;

    @FindBy(xpath = "//span[.='Edit']")
    private WebElement editBtn;

    @FindBy(name = "travelHours")
    private WebElement traveltime;

    @FindBy(name = "jobHours")
    private WebElement jobTime;

    @FindBy(name = "note")
    private WebElement enterNotes;

    @FindBy(xpath = "//span[.='Save']")
    private WebElement saveButton;

    @FindBy(css = ".MuiTable-root tbody tr td:nth-child(2) div p")
    private WebElement fieldTechStatus;

    @FindBy(css = ".MuiIconButton-colorInherit")
    private WebElement crossIcon;

    @FindBy(xpath = "(//div[p[text()='Total travel time']]/following-sibling::div/p)[1]")
    private WebElement totalTravelTimeHours;

    @FindBy(xpath = "(//div[p[text()='Total travel time']]/following-sibling::div/p)[2]")
    private WebElement totalTravelTimeMinutes;

    @FindBy(xpath = "(//div[p[text()='Total job time']]/following-sibling::div/p)[1]")
    private WebElement totalJobTimeHours;

    @FindBy(xpath = "(//div[p[text()='Total job time']]/following-sibling::div/p)[2]")
    private WebElement totalJobTimeMinutes;

    public FieldTechWidget(WebDriver driver) {
        super(driver);
    }

    public void waitForFieldTechWidget() {
        waitHelper.waitForElementToBeVisible(fieldTechHeader);
    }

    public void openFieldTech() {
        element.click(fieldTechArrow);
    }

    public void clickEdit() {
        element.click(editBtn);
    }

    public void enterTravelTimeHour(String time) {
        element.type(traveltime, time);
    }

    public void enterTravelJobTimeHour(String time) {
        element.type(jobTime, time);
    }

    public void clickSave() {
        element.click(saveButton);
    }

    public String isFieldTechStatus() {
        return element.getText(fieldTechStatus);
    }

    public void closeWidget() {
        element.click(crossIcon);
    }


    public void enterNotes(String note) {
        element.type(enterNotes, note);
    }

    public String getTotalTravelTimeHours() {
        return element.getText(totalTravelTimeHours);
    }

    public String getTotalTravelTimeMinutes() {
        return element.getText(totalTravelTimeMinutes);
    }

    public String getTotalJobTimeHours() {
        return element.getText(totalJobTimeHours);
    }

    public String getTotalJobTimeMinutes() {
        return element.getText(totalJobTimeMinutes);
    }

}
