package com.hcp.qa.helpers;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.gmail.GmailMessageClient;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.myapps.MyAppsPage;
import com.hcp.qa.pages.payment.CreditCardInformationWidget;
import com.hcp.qa.pages.serviceplan.AddServicePlanToCustomerPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPaymentsWidget;
import com.hcp.qa.pages.serviceplan.HCPClientReviewAndConfirmPlanPage;
import com.hcp.qa.pages.serviceplan.ServicePlanTemplatePage;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.pages.serviceplan.ServicePlansDashboardPage;

public class ServicePlanHelper {
	
	static String customerId;
	CustomerHelper customerHelper;
	NavigationHelper navigationHelper;
	PaymentHelper paymentHelper;
	
	WebDriver driver;
	private int WAIT_TIME_FOR_EMAIL = 20;
	protected static Logger LOG = LoggerFactory.getLogger(ServicePlanHelper.class);
	
	String createAccountFromEmailPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.gmail.password");
	
	String planDescription = "Test Description";
	public String visitsPerYear = "4";
	public String monthlyAmount = "50";
	public String quarterlyAmount = "120";
	public String addOnItemName = "Test Add On";
	public String addOnItemPrice = "50";
	public String addedOnItemPriceOnCreatedPlan = "49.92";
	
	public ServicePlanHelper(WebDriver driver) {
		this.driver = driver;
	}

	public void goToServicePlanPage() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.waitForPageToLoad(2);
		dashboard.getTopMenu().clickMyApps();
		MyAppsPage myApps = new MyAppsPage(driver);
		myApps.clickServicePlan();
		new ServicePlansDashboardPage(driver);
	}
	
	public void addServicePlan(String planName) {
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickAddServicePlan();

		ServicePlanTemplatePage addPlan = new ServicePlanTemplatePage(driver);
		addPlan.enterPlanName(planName);
		addPlan.enterPlanDescription(planDescription);
		addPlan.clickNext();

		addPlan.enterVisitsPerYear(visitsPerYear);
		addPlan.clickDurationEndsAfter();
		addPlan.enterMonthlyAmount(monthlyAmount);
		addPlan.clickEveryQuarterCheckbox();
		addPlan.enterQuarterlyAmount(quarterlyAmount);
		addPlan.togglePayableCash();
		addPlan.clickNext();

		addPlan.enterAddOnItemName(addOnItemName);
		addPlan.enterAddOnItemPrice(addOnItemPrice);
		addPlan.clickCreatePlan();
	}
	

	public void acceptServicePlanForcustomer(String customerId, String planName) {
		customerHelper = new CustomerHelper(driver);
		navigationHelper=new NavigationHelper(driver);
		navigationHelper.goToCustomer(customerId);

		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddServicePlan();

		AddServicePlanToCustomerPage addPlanToCustomer = new AddServicePlanToCustomerPage(driver);
		addPlanToCustomer.searchAndSelectPlan(planName);
		addPlanToCustomer.selectAcceptPlanForCustomer();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickAdd();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickFinishAndPay();		

	}
	
	public void deleteExistingServicePlans() {
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		List<WebElement> servicePlans = servicePlansPage.getAllServicePlans();
		int count=servicePlans.size();
		for(int i=0;i<count;i++) {
			servicePlans = servicePlansPage.getAllServicePlans();
			count=servicePlans.size();
			String planNameFromList = servicePlans.get(i).getText();
			servicePlansPage.clickServicePlan(planNameFromList);
			servicePlansPage.waitForPageToLoad(1);
			ServicePlanSummaryPage plansummary = new ServicePlanSummaryPage(driver);
			plansummary.clickDeleteServicePlan();
			plansummary.deleteOrArchive();
			plansummary.waitForPageToLoad(1);
		}

	}
	
	public void createAccountToViewPlanFromEmail(){
		HCPClientReviewAndConfirmPlanPage clientLoginPage = new HCPClientReviewAndConfirmPlanPage(driver);
		clientLoginPage.enterSaveCardOnFilePassword(createAccountFromEmailPassword);
		clientLoginPage.createAndConfirmPasswordToViewPlan(createAccountFromEmailPassword);
		
	}
		
	public void addZeroDollarServicePlan(String planName) {
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickAddServicePlan();

		ServicePlanTemplatePage addPlan = new ServicePlanTemplatePage(driver);
		addPlan.enterPlanName(planName);
		addPlan.enterPlanDescription(planDescription);
		addPlan.clickNext();
		
		addPlan.enterVisitsPerYear(visitsPerYear);
		addPlan.clickDurationEndsAfter();
		addPlan.clickNext();
		addPlan.clickCreatePlan();
	}
	
	public String getServicePlanViewAgreementUrl()	{
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
	
		String emailText = gmailClient.searchEmailAndGetMessageBody("Your service agreement", WAIT_TIME_FOR_EMAIL,
				true);
		String startString = "href=\"";
		String endString = "\">VIEW MY AGREEMENT";
		String servicePlanUrl = StringUtils.substringBetween(emailText, startString, endString);
		return servicePlanUrl;
	}
	
	public void verifyServiceAgreementEmailReceived(String subject, boolean isEmailDelete, String bodyMsg1, String bodyMsg2) {
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
		String  emailText= gmailClient.searchEmailAndGetMessageBody(subject, WAIT_TIME_FOR_EMAIL,	isEmailDelete);
		Assert.assertTrue(emailText.contains(bodyMsg1) && emailText.contains(bodyMsg1),
				"Customer did not receive email for service plan");
	}
	
	public void acceptServicePlanForCustomerWithCC(String customerId, String planName) {
		acceptServicePlanForcustomer(customerId, planName);	
		CustomerServicePlanPaymentsWidget servicePlanPaymentPage = new CustomerServicePlanPaymentsWidget(driver);	
		servicePlanPaymentPage.enterNameOnCard("Test Credit Card");
		PaymentHelper paymentHelper = new PaymentHelper(driver);
		CreditCardInformationWidget cardInfo = paymentHelper.fillCreditCardDetailsWithPostalCode();
		cardInfo.clickChargeCard();
	}

	public void acceptServicePlanForCustomerWithCash(String customerId, String planName) {
		acceptServicePlanForcustomer(customerId, planName);	
		CustomerServicePlanPaymentsWidget servicePlanPaymentPage = new CustomerServicePlanPaymentsWidget(driver);	
		servicePlanPaymentPage.clickCashTab();
		servicePlanPaymentPage.clickMarkAsPaidCash();
	}

	public void acceptservicePlanForCustomerWithCheck(String customerId, String planName) {
		acceptServicePlanForcustomer(customerId, planName);	
		CustomerServicePlanPaymentsWidget servicePlanPaymentPage = new CustomerServicePlanPaymentsWidget(driver);	
		servicePlanPaymentPage.clickCheckTab();
		servicePlanPaymentPage.clickMarkAsPaidCheck();
	}
	
	public void addServicePlanWithVisits(String planName,String visits) {
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickAddServicePlan();

		ServicePlanTemplatePage addPlan = new ServicePlanTemplatePage(driver);
		addPlan.enterPlanName(planName);
		addPlan.enterPlanDescription(planDescription);
		addPlan.clickNext();

		addPlan.enterVisitsPerYear(visits);
		addPlan.clickDurationEndsAfter();
		addPlan.enterDuration("1");
		addPlan.enterMonthlyAmount(monthlyAmount);
		addPlan.clickEveryQuarterCheckbox();
		addPlan.enterQuarterlyAmount(quarterlyAmount);
		addPlan.togglePayableCash();
		addPlan.clickNext();

		addPlan.enterAddOnItemName(addOnItemName);
		addPlan.enterAddOnItemPrice(addOnItemPrice);
		addPlan.clickCreatePlan();
	}
    
	public String getManagePlanUrl(){
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
		String emailText = gmailClient.searchEmailAndGetMessageBody("**QA_TEST**QA_TESTYour plan with QAHero is now active", WAIT_TIME_FOR_EMAIL,true);
		String startString = "href=\"";
		String endString = "\">MANAGE MY PLAN";
		String servicePlanUrl = StringUtils.substringBetween(emailText, startString, endString);
		return servicePlanUrl;
		}

	public void addServicePlanWithDiscount(String planName, String amount) {
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickAddServicePlan();

		ServicePlanTemplatePage addPlan = new ServicePlanTemplatePage(driver);
		addPlan.enterPlanName(planName);
		addPlan.enterPlanDescription(planDescription);
		
		addPlan.toggleDiscount();
		addPlan.enterDiscountDescription();
		addPlan.enterDiscountPercentage(amount);		
		addPlan.clickNext();

		addPlan.enterVisitsPerYear(visitsPerYear);
		addPlan.clickDurationEndsAfter();
		addPlan.enterMonthlyAmount(monthlyAmount);
		addPlan.clickEveryQuarterCheckbox();
		addPlan.enterQuarterlyAmount(quarterlyAmount);
		addPlan.togglePayableCash();
		addPlan.clickNext();

		addPlan.enterAddOnItemName(addOnItemName);
		addPlan.enterAddOnItemPrice(addOnItemPrice);
		addPlan.clickCreatePlan();
	}
}
