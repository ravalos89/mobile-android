package com.hcp.qa.helpers;

import java.io.File;

public class AttachmentHelper {
	private static AttachmentHelper instance;

	PropertiesReader properties = PropertiesReader.getInstance();
	
	private AttachmentHelper()
	{}
	public static AttachmentHelper getInstance()
	{
		if (instance == null)
			instance = new AttachmentHelper();
		return instance;
	}

	public String getAttachmentPath() {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("testdata/job-attachment.jpeg").getFile());
		String absolutePath = file.getAbsolutePath();
		return absolutePath;
	}


}
