package com.hcp.qa.pages.admin;

import com.hcp.qa.common.AdminCompanyDetailsTab;
import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import static java.lang.String.format;

public class AdminTopNavigationWidget extends Page {

    public AdminTopNavigationWidget(WebDriver driver) {
        super(driver);
    }

    public void clickTab(AdminCompanyDetailsTab tabName) {
        By tabLocator = By.xpath(format("//div[@role='tablist']/a[.='%s']", tabName));
        element.click(tabLocator);
    }
}
