package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.openqa.selenium.By.xpath;

public class ScheduleWidget extends Page {

	@FindBy(xpath = "//span[@title='Schedule']")
	private WebElement editScehdule;
	
	@FindBy(xpath = "//input[@placeholder='Dispatch by name or tag']")
	private WebElement searchInput;

	public ScheduleWidget(WebDriver driver) {
		super(driver);
	}


	public void clickEditSchedule() {
		element.click(editScehdule);
		waitForPageToLoad(2);
	}


	public boolean verifyRecurrenceMsg(String string) {
		return element.isDisplayed(xpath("//p[contains(.,'"+string+"')]"));
	}
	
	public void assignEmployee(String employee) {
		element.type(searchInput, employee);
		element.click(xpath("//span[.='" + employee + "']"));
	}

}
