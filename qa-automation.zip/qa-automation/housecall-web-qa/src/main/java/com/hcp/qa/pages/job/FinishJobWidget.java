package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class FinishJobWidget extends Page {

    @FindBy(xpath = "//span[contains(.,'Notify customer')]/..//input")
    private WebElement notifyCustomerCheckbox;

    @FindBy(xpath = "//span[contains(.,'Cancel')]")
    private WebElement cancel;

    @FindBy(xpath = "//span[contains(.,'Finish')]")
    private WebElement finish;

    public FinishJobWidget(WebDriver driver) {
        super(driver);
    }

    public void clickFinish() {
        element.click(finish);
    }

    public void clickCancel() {
        element.click(cancel);
    }

    public void selectNotifyCustomer(boolean select) {
        if (select == true && !notifyCustomerCheckbox.isSelected())
            element.click(notifyCustomerCheckbox);
        else if (select == false && notifyCustomerCheckbox.isSelected())
            element.click(notifyCustomerCheckbox);
    }

}
