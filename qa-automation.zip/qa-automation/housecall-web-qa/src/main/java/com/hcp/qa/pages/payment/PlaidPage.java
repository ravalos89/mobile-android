package com.hcp.qa.pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class PlaidPage extends Page {

	@FindBy(xpath = "//span[contains(text(),'Continue')]")
	private WebElement continueBtn;

	@FindBy(id = "username")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "submit-credentials")
	private WebElement submitBtn;
	
	@FindBy(id = "submit-device")
	private WebElement submitDeviceBtn;
	
	@FindBy(id="code")
	private WebElement code;
	
	@FindBy(id = "submit-code")
	private WebElement submitCodeBtn;
	

	@FindBy(id = "checking")
	private WebElement checkingAccountCheckbox;

	@FindBy(id = "submit-accounts")
	private WebElement submitAccountsBtn;
	
	@FindBy(id = "terms")
	private WebElement terms;
	
	@FindBy(id = "submit-confirmation")
	private WebElement connectAccounts;
	
	@FindBy(xpath = "//li[contains(.,'Plaid Checking')]//input")
	private WebElement checkingAccountRadioBtn;

	@FindBy(xpath = "//li[contains(.,'Plaid Checking')]//label")
	private WebElement checkingAccountLabel;
	

	@FindBy(xpath = "//li[contains(.,'Plaid Saving')]//input")
	private WebElement savingAccountRadioBtn;

	@FindBy(xpath = "//button[@aria-label='Exit']")
	private WebElement closeBtn;

	@FindBy(xpath = "//span[contains(text(),'Yes, exit')]")
	private WebElement exitSetUpBtn;

	@FindBy(xpath = "//h1[contains(.,'Select your institution')]")
	private WebElement plaidHome;

	public PlaidPage(WebDriver driver) {
		super(driver);
	}

	public void clickContinue() {
		PageUtils.clickUsingJS(driver, continueBtn);
		// continueBtn.click();
	}

	public void clickClose() {
		waitHelper.waitForElementToBeClickable(closeBtn);
		waitForPageToLoad(4);
		PageUtils.clickUsingJS(driver, closeBtn);
	}

	public void clickExitSetUp() {
		waitHelper.waitForElementToBeClickable(exitSetUpBtn);
		exitSetUpBtn.click();
	}

	public boolean isPlaidPageVisible() {
		return plaidHome.isDisplayed();
	}

	public void selectBankName(String bankName) {
		driver.findElement(By.xpath("//h2[contains(text(),'" + bankName + "')]")).click();
	}

	public void enterUsername(String username) {
		this.username.sendKeys(username);
	}

	public void enterPassword(String password) {
		this.password.sendKeys(password);
	}

	public void clickSubmit() {
		submitBtn.click();
	}
	
	public void clickGetCode() {
		submitDeviceBtn.click();
	}
	
	public void enterCode(String code)
	{
		this.code.sendKeys(code);
	}
	
	public void clickSubmitCode() {
		submitCodeBtn.click();
	}

	public void selectCheckingSetup() {
		if (!checkingAccountCheckbox.isSelected())
			checkingAccountCheckbox.click();
	}
	
	public void submitAccounts()
	{
		submitAccountsBtn.click();
	}
	
    public void acceptTerms()
    {
    	terms.click();
    }
    
    public void connectAccounts()
    {
    	connectAccounts.click();
    }
    
	public void selectChecking() {
		checkingAccountLabel.click();
	}

	public void selectSaving() {
		if (!this.savingAccountRadioBtn.isSelected())
			savingAccountRadioBtn.click();
	}

}
