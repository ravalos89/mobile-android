package com.hcp.qa.pages.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EditTeamDialog extends Page {

	@FindBy(xpath = "//button[@data-testid='editTeamDialog__cancel']']")
	private WebElement cancelBtn;

	@FindBy(xpath = "//button[@data-testid='editTeamDialog__save']")
	private WebElement doneBtn;

	public EditTeamDialog(WebDriver driver) {
		super(driver);
	}

	public void selectEmployee(String employeeName) {
		WebElement employeeCheckbox = driver
				.findElement(By.xpath("//tr[contains(.,'" + employeeName + "')]/td[1]//input"));
		if (!employeeCheckbox.isSelected())
			element.click(employeeCheckbox);
	}

	public void clickCancel() {
		element.click(cancelBtn);
	}

	public void clickDone() {
		element.click(doneBtn);
	}

}
