package com.hcp.qa.pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.pages.common.Page;

import static java.time.Duration.ofSeconds;

public class ReceiptPage extends Page {

	public ReceiptPage(WebDriver driver) {
		super(driver);
	}

	public void waitForPaymentMessageToAppear() {
		WebDriverWait wait = new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS));
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//h5[contains(text(),'Thanks for your payment')]")));
	}

	public String getAmountDue() {
		WebElement amountDue = driver.findElement(By.xpath("//div[1]/h6/span[text() = '$0.00']"));
		return element.getText(amountDue);
	}
}
