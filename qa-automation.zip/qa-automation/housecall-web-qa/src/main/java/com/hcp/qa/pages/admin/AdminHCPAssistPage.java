package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.openqa.selenium.By.xpath;

public class AdminHCPAssistPage extends Page {

    @FindBy(xpath = "//span[.='Call Log']")
    private WebElement callLog;

    @FindBy(xpath = "//span[.='Companies']")
    private WebElement companies;

    @FindBy(xpath = "//h5[contains(.,'Admin Panel')]/preceding-sibling::button")
    private WebElement adminMenu;

    @FindBy(xpath = "//h6[contains(.,'Interaction ID')]")
    private WebElement interactionIdColumnHeader;

    @FindBy(xpath = "//tr[1]//span[@title='HCP Assist Impersonate']")
    private WebElement callLogImpersonate;

    @FindBy(xpath = "//span[contains(text(),'HCP Assist')]")
    private WebElement hcpAssist;

    public AdminHCPAssistPage(WebDriver driver) {
        super(driver);
    }

    public boolean isCompanyNameDisplayed(String name) {
        return element.isDisplayed(xpath("//span[.='" + name + "']"));
    }

    public void clickCallLogTab() {
        waitForPageToLoad(2);
        element.click(callLog);
    }

    public boolean isCallLogDisplayed() {
        return element.isDisplayed(interactionIdColumnHeader);
    }

    public void clickCompanyImpersonationIcon(String companyName) {
        element.click(xpath("//td[.='" + companyName + "']/parent::tr/td[5]//button"));
    }

    public void clickCallLogImpersonationIcon() {
        element.click(callLogImpersonate);
    }

    public void clickCompaniesTab() {
        element.click(companies);
    }

    public void clickMenu() {
        element.click(adminMenu);
    }

    public void clickHcpAssist() {
        element.click(hcpAssist);
    }
}
