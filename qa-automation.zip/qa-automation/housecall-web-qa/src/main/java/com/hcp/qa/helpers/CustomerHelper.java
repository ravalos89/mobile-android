package com.hcp.qa.helpers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.api.ApiClient;
import com.hcp.qa.models.Customer;
import com.hcp.qa.pages.common.DeleteDialog;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.customer.CustomerOptionsMenu;
import com.hcp.qa.pages.customer.CustomersListPage;

public class CustomerHelper {
	WebDriver driver;
	NavigationHelper navigationHelper;
	protected static Logger LOG = LoggerFactory.getLogger(CustomerHelper.class);

	public CustomerHelper(WebDriver driver) {
		this.driver = driver;
		this.navigationHelper = new NavigationHelper(driver);

	}

	public Customer createCustomer(String prefix) {
		Customer customer = DataGenerator.getInstance().generateCustomerData(prefix);
		return createCustomer(customer);

	}

	public Customer createCustomer(Customer customerData) {
		Customer customer = ApiHelper.getInstance().createCustomer(customerData);
		navigationHelper.goToCustomer(customer.getId());
		return customer;
	}
	
	public Customer createCustomer(Customer customerData, String apiKey) {
		ApiClient client = new ApiClient(apiKey);
		Customer customer = client.createCustomer(customerData).as(Customer.class);
		navigationHelper.goToCustomer(customer.getId());
		return customer;
	}
	
	public Customer createCustomer(String prefix, String apiKey) {
		Customer customer = DataGenerator.getInstance().generateCustomerData(prefix);
		ApiClient client = new ApiClient(apiKey);
		customer = client.createCustomer(customer).as(Customer.class);
		navigationHelper.goToCustomer(customer.getId());
		return customer;

	}

	public void deleteCustomer(Customer customer) {
		try {
			navigationHelper.goToCustomersListPage();
			CustomersListPage customerList = new CustomersListPage(driver);
			customerList.searchForCustomer(customer.getDisplayName());
			customerList.selectCheckBoxByCustomerName(customer.getDisplayName());
			customerList.clickDeleteIcon();
			customerList.clickConfirmDelete();
		} catch (Exception e) {
			LOG.info("Could not Delete customer successfully. Going to Customer Details page directly ");
			navigationHelper.goToCustomer(customer.getId());
			deleteCustomerFromDetailsPage();
		}
	}

	public void deleteCustomerFromDetailsPage() {
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		CustomerOptionsMenu customerOptionsMenu = customerDetails.clickOnDots();
		DeleteDialog deleteDialog=customerOptionsMenu.clickDeleteCustomer();
		deleteDialog.clickConfirm();
	}

	public void deleteAllCustomers(String displayName) {
		CustomersListPage customerList = new CustomersListPage(driver);
		boolean moreCustomersToDelete = true;

		while (moreCustomersToDelete) {
			navigationHelper.goToCustomersListPage();
			customerList.searchForCustomer(displayName);
			moreCustomersToDelete = driver.findElements(By.xpath("//h3[contains(.,'No customers')]")).isEmpty();

			if (moreCustomersToDelete) {
				customerList.selectAllCustomers();
				customerList.clickDeleteIcon();
				customerList.clickConfirmDelete();
				customerList.waitForPageToLoad(2);
			}
		}
		LOG.info("No More Customers to Delete");
	}

	public void searchAndSelectCustomer(Customer customer) {
		try {
			navigationHelper.goToCustomersListPage();
			CustomersListPage customerList = new CustomersListPage(driver);
			customerList.searchForCustomer(customer.getDisplayName());
			customerList.waitForPageToLoad(2);
			customerList.clickCustomerName(customer.getDisplayName());
		} catch (Exception e) {
			LOG.info("Customer search did not work .Going to Customer Details page directly");
			navigationHelper.goToCustomer(customer.getId());
		}
	}

}
