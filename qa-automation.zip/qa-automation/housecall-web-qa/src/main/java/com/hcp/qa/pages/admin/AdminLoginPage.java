package com.hcp.qa.pages.admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class AdminLoginPage extends Page {

	@FindBy(id = "email")
	private WebElement email;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "show-email")
	private WebElement showEmailLink;

	@FindBy(name = "commit")
	private WebElement submitBtn;

	public AdminLoginPage(WebDriver driver) {
		super(driver);
	}

	public void clickShowEmailLink() {
			element.click(showEmailLink);
	}

	public void setEmail(String email) {
		element.type(this.email, email);
	}

	public void setPassword(String password) {
		element.type(this.password, password);
	}

	public void clickSubmit() {
		element.click(submitBtn);
	}

}
