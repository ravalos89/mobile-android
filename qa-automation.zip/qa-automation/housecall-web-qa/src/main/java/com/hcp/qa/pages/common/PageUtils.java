package com.hcp.qa.pages.common;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.reports.ReportUtils;

import static java.time.Duration.ofSeconds;

public class PageUtils {
	
	public static final int LONG_WAIT_TIME_IN_SECS = 30;
	static ReportUtils reportUtils = new ReportUtils();

	public static void enterValueInPrefilledField(WebElement e, String value) {
		for (int i = 0; i < 4; i++) {
			e.sendKeys(Keys.ARROW_LEFT);
		}
		e.sendKeys(value);
		e.sendKeys(Keys.ARROW_RIGHT);
		e.sendKeys(Keys.BACK_SPACE);
	}

	public static void scrollAndSelectTextFromDropDown(WebDriver driver, WebElement e, String selection) {
		e.click();
		Sleep.seconds(1);

		List<WebElement> options = driver.findElements(By.xpath("//li"));
		int foundIndex = 0;
		for (int i = 0; i < options.size(); i++) {
			WebElement option = options.get(i);
			if (option.getText().equals(selection)) {
				foundIndex = i;
				break;
			}
		}
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("arguments[0].scrollIntoView(true);", options.get(foundIndex));
		options.get(foundIndex).click();
	}

	public static void provideFileUploadPath(WebDriver driver, WebElement fileInputElement, String path) {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("HTMLInputElement.prototype.click = function() {                     "
				+ "  if(this.type !== 'file') HTMLElement.prototype.click.call(this);  "
				+ "};                                                                  ");
		js.executeScript("arguments[0].style.display = 'block';", fileInputElement);
		fileInputElement.sendKeys(path);
		WebElement element = driver.findElement(By.xpath("//body"));
		element.sendKeys(Keys.ESCAPE);

	}
	
	public static void toggleButton(WebElement toggleButton, boolean isOn) {
		if (!isOn && toggleButton.isSelected())
			toggleButton.click();
		else if (isOn && !toggleButton.isSelected())
			toggleButton.click();
	}
	
	public static void waitForOverlayDisappearance(WebDriver driver) {
		new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS))
				.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@role='progressbar']")));
	}
	
	public static void scrollToTop(WebDriver driver) {
		JavascriptExecutor je = (JavascriptExecutor) driver;
		je.executeScript("window.scrollTo(0, 0);");
	}

	public static void clickUsingJS(WebDriver driver, WebElement e) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", e);
	}

	public static void scrollIntoView(WebDriver driver, WebElement e) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true)", e);
	}

	public static void scrollToBottom(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	}
	
	public static void selectOption(List<WebElement> options, String optionToClick) {

		List<String> optionsList = new ArrayList<>();

		for (WebElement option : options) {
			optionsList.add(option.getText());
		}

		if (optionsList.contains(optionToClick)) {
			for (WebElement option : options) {
				if (option.getText().equals(optionToClick)) {
					option.click();
					break;
				}
			}
		} else {
			reportUtils.fail("Option is not available");
		}

	}


}
