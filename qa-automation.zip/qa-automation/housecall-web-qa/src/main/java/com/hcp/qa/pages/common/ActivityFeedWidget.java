package com.hcp.qa.pages.common;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.openqa.selenium.By.xpath;

public class ActivityFeedWidget extends Page {

	@FindBy(xpath = "//div[starts-with(@class,'MuiExpansionPanelSummary-content')]//div[contains(@class,'MuiGrid-grid-xs-true')]/p")
	private List<WebElement> activityFeed;

	@FindBy(xpath = "(//div[starts-with(@class,'MuiExpansionPanelSummary-content')]//div[contains(@class,'MuiGrid-grid-xs-true')])[1]/p")
	private WebElement latestActivity;
	
	@FindBy(xpath ="(//div[starts-with(@class,'MuiExpansionPanelSummary-content')]//div[contains(@class,'MuiAvatar-root MuiAvatar-circle MuiChip-avatar')])[1]/following-sibling::span")
	private WebElement latestActivityUser;
	
	@FindBy(xpath ="(//div[starts-with(@class,'MuiExpansionPanelSummary-content')]//div[contains(@class,'MuiGrid-grid-xs-true')])[2]/p")
	private WebElement failedPaymentActivity;
	
	public ActivityFeedWidget(WebDriver driver) {
		super(driver);
	}

	public List<String> getAllActivities() {
		return activityFeed.stream().map(WebElement::getText).collect(Collectors.toList());
	}

	public String getLatestActivity() {
		PageUtils.scrollIntoView(driver, latestActivity);
		waitForPageToLoad(1);

		return element.getText(latestActivity);
	}
	
	public String getLatestActivityUser() {
		PageUtils.scrollIntoView(driver, latestActivity);
		waitForPageToLoad(1);

		return element.getText(latestActivityUser);
	}
	
	public String getFailedPaymentActivity() {
		PageUtils.scrollIntoView(driver, latestActivity);
		waitForPageToLoad(1);

		return element.getText(failedPaymentActivity);
	}
	
	public boolean searchForActivity(String activity) {
		return element.isDisplayed(xpath("//div/p[contains(.,'"+activity+"')]"));
	}

}
