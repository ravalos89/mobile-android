package com.hcp.qa.pages.navigation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ProfileWidget extends Page {

	@FindBy(xpath = "//p[contains(.,'Account settings')]")
	private WebElement accountSettings;

	@FindBy(xpath = "//p[contains(.,'Share the love')]")
	private WebElement shareTheLove;
	
	@FindBy(xpath = "//p[contains(.,'Sign out')]")
	private WebElement signOut;

	public ProfileWidget(WebDriver driver) {
		super(driver);
	}

	public void clickSignOut() {
		element.click(signOut);
	}

	public void clickAccountSettings() {
		waitHelper.waitForElementToBeClickable(accountSettings);
		accountSettings.click();
	}
	
	public void clickShareTheLove() {
		shareTheLove.click();
	}
	
	public boolean isAcccountSettingsVisible()
	{
	 return element.isDisplayed(accountSettings);
	}
	
	
	
	

}
