package com.hcp.qa.pages.pricebook;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.pages.common.PageUtils;
import com.hcp.qa.pages.common.PagewithNavigation;

import static java.lang.String.format;
import static org.openqa.selenium.By.xpath;

public class PriceBookPage extends PagewithNavigation {

	@FindBy(xpath = "//span[contains(text(),'add industry')]")
	WebElement addIndustryBtn;

	@FindBy(xpath = "//li[contains(.,'Delete')]")
	WebElement deleteBtn;

	@FindBy(xpath = "//span[contains(text(),'Materials')]")
	WebElement materialsMenu;

	@FindBy(xpath = "//button[@name='search']")
	WebElement searchIcon;

	@FindBy(xpath = "//button[@name='search']/following-sibling::button")
	WebElement optionsGearIcon;

	@FindBy(xpath = "//button[.='Okay']")
	private WebElement okayBtn;

	@FindBy(xpath = "//span[contains(text(),'Services')]")
	WebElement servicesMenu;

	@FindBys(@FindBy(css = ".MuiTypography-body1.MuiTypography-displayBlock"))
	List<WebElement> priceBookList;

	@FindBys(@FindBy(css = ".card.MuiPaper-elevation1.MuiPaper-rounded p>span"))
	List<WebElement> categoryNamesList;

	public PriceBookPage(WebDriver driver) {
		super(driver);
	}

	public void clickAddIndustry() {
		addIndustryBtn.click();
	}

	public void clickDelete(String industryName) {
		clickIndustrySibling(industryName);
		element.click(xpath("//li[contains(.,'Delete')]"));
	}

	public void clickReorder(String industryName) {
		clickIndustrySibling(industryName);
		element.click(xpath("//li[contains(.,'Reorder')]"));
	}

	private void clickIndustrySibling(String industryName) {
		String industryButtonTemplate = "//p[contains(.,'%s')]/following-sibling::button";
		element.click(xpath(format(industryButtonTemplate, industryName)));
	}

	public void reorderIndustries(String fromIndustryName, String toIndustryName)	{
		WebElement from=driver.findElement(xpath("//div[contains(@class,'MuiPaper-rounded') and contains(.,'"+fromIndustryName+"')]"));
		WebElement to=driver.findElement(xpath("//div[contains(@class,'MuiPaper-rounded') and contains(.,'"+toIndustryName+"')]"));

		Actions builder=new Actions(driver);
		builder.dragAndDrop(from, to);
	}

	public void clickSaveOrderButton()	{
		element.click(xpath("//span[contains(.,'Save Order')]"));
	}

	public boolean  isReorderMessageDisplayed() {
		return element.isDisplayed(xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'successfully reordered')]"));
	}

	public void clickMaterials() {
		waitForPageToLoad(1);
		element.click(materialsMenu);
		waitForPageToLoad(1);
	}

	public void clickSearchIcon() {
		element.click(searchIcon);
	}

	public void clickOptionsGearIcon() {
		waitForPageToLoad(1);
		element.click(optionsGearIcon);
		waitForPageToLoad(1);
	}

	public boolean isPriceBookBreadCrumbVisible()
	{
		By homePriceBookBreadcrumbLocator = xpath("//a[text()='Price book' and @href='/app/price_book']");
		return element.isDisplayed(homePriceBookBreadcrumbLocator);
	}

	public void clickOkay() {
		element.click(okayBtn);
	}
	public void clickServices() {
		waitForPageToLoad(1);
		servicesMenu.click();
		waitForPageToLoad(1);
	}

	public List<String> getCategories() {
		List<String> categories=new ArrayList<>();
		for(WebElement e: priceBookList) {
			e.click();
			if(e.getText().equals("Materials")) {
				break;
			}
			for(WebElement category: categoryNamesList) {
				categories.add(category.getText());
			}
		}
		return categories;
	}

	public void waitForIndustryToLoad(String industry) {
		int waitTimes = 0;
		int retries = 6;
		By industryButton = getIndustryButtonBy(industry);
		while(driver.findElements(industryButton).isEmpty() && waitTimes++ < retries ) {
			Sleep.seconds(5);
			driver.navigate().refresh();
		}
		if(waitTimes >= retries ) {
			throw new RuntimeException("Given industry did not loaded. Industry name: " + industry);
		}
	}

	private By getIndustryButtonBy(String industryName) {
		String industryButtonTemplate = "//span[contains(.,'%s')]/../../../button";
		return xpath(format(industryButtonTemplate, industryName));
	}
	
	public void clickIndustryCard(String industryName) {
		element.isDisplayed(xpath("//span[@title='" + industryName + "']/../../../button"));
		WebElement e=driver.findElement(xpath("//span[@title='" + industryName + "']/../../../button"));
        PageUtils.clickUsingJS(driver, e);
	}
}
