package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ServicePlanTemplatePage extends Page {

	@FindBy(css = ".MuiInputBase-formControl input")
	protected WebElement planName;

	@FindBy(css = ".MuiInputBase-formControl textarea")
	protected WebElement planDescription;

	@FindBy(xpath = "//span[.='Next']")
	protected WebElement nextBtn;

	@FindBy(name = "included_visits")
	protected WebElement visitNumber;

	@FindBy(xpath = "//input[@name='indefinite'][@value='false']")
	protected WebElement endAfterRadioBtn;

	@FindBy(name = "service_agreement_payment_options_attributes[0].amount")
	protected WebElement everyMonthlyAmount;

	@FindBy(xpath = "//span[.='Every quarter']")
	protected WebElement everyQuarterCheckbox;

	@FindBy(name = "service_agreement_payment_options_attributes[1].amount")
	protected WebElement everyQuarterAmount;

	@FindBy(name = "add_ons_attributes[0].name")
	protected WebElement addOnsItemName;

	@FindBy(name = "add_ons_attributes[0].price")
	protected WebElement addOnsItemPrice;

	@FindBy(xpath = "//span[.='Create plan']")
	protected WebElement createPlanBtn;

	@FindBy(xpath = "//span[@class='MuiSwitch-root']//input[@type='checkbox']")
	private WebElement toggleButton;

	@FindBy(name = "duration_time")
	private WebElement duration;

	@FindBy(name = "discount_name")
	private WebElement discountDescription;

	@FindBy(name = "discount_amount")
	private WebElement discountPercentage;
	
	@FindBy(xpath = "//span[.='Save plan']")
	private WebElement savePlanBtn;

	public ServicePlanTemplatePage(WebDriver driver) {
		super(driver);
	}

	public void enterPlanName(String name) {
		waitForPageToLoad(2);
		planName.sendKeys(name);
	}

	public void enterPlanDescription(String string) {
		planDescription.sendKeys(string);
	}

	public void clickNext() {
		nextBtn.click();
	}

	public void enterVisitsPerYear(String visitsPerYear) {
		visitNumber.clear();
		waitForPageToLoad(1);
		visitNumber.sendKeys(visitsPerYear);
	}

	public void clickDurationEndsAfter() {
		if (!endAfterRadioBtn.isSelected())
			endAfterRadioBtn.click();
	}

	public void enterMonthlyAmount(String monthlyAmount) {
		PageUtils.enterValueInPrefilledField(everyMonthlyAmount, monthlyAmount);
	}

	public void clickEveryQuarterCheckbox() {
		everyQuarterCheckbox.click();
	}

	public void enterQuarterlyAmount(String quarterlyAmount) {
		PageUtils.enterValueInPrefilledField(everyQuarterAmount, quarterlyAmount);
	}

	public void enterAddOnItemName(String addOnItemName) {
		addOnsItemName.clear();
		waitForPageToLoad(1);
		addOnsItemName.sendKeys(addOnItemName);
	}

	public void enterAddOnItemPrice(String addOnItemPrice) {
		PageUtils.enterValueInPrefilledField(addOnsItemPrice, addOnItemPrice);
	}

	public void clickCreatePlan() {
		createPlanBtn.click();
	}

	public void togglePayableCash() {
		PageUtils.toggleButton(toggleButton, true);
	}

	public void enterDuration(String durationVal) {
		PageUtils.enterValueInPrefilledField(duration, durationVal);
    }
    
	public void toggleDiscount() {
		PageUtils.toggleButton(toggleButton, true);
	}

	public void enterDiscountDescription() {
		discountDescription.sendKeys("Discount");
	}

	public void enterDiscountPercentage(String amount) {
		discountPercentage.sendKeys(amount);
	}
	
	public void clickSavePlan() {
		savePlanBtn.click();
	}

}
