package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class SaveReportModalPage extends Page{

	@FindBy(xpath="//input[@data-testid='save-a-report-text-field']")
	WebElement reportNameTxt;
	
	@FindBy(xpath="//button//span[contains(text(),'Save')]")
	WebElement saveBtn;
	
	@FindBy(xpath="//button//span[contains(text(),'Cancel')]")
	WebElement cancelBtn;

	public SaveReportModalPage(WebDriver driver) { super(driver); }
	
	public void setReportName(String reportName) { element.type(reportNameTxt, reportName); }
	
	public void clickSave() {
		element.click(saveBtn);
	}

}
