package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class CategoryPage extends Page {

	@FindBy(xpath = "//button[contains(.,'add item')]")
	private WebElement addItemBtn;

	@FindBy(xpath = "//button[contains(.,'add service')]")
	private WebElement addServiceBtn;
	
	@FindBy(xpath = "//button[contains(.,'SERVICE')]")
	private WebElement addFirstServiceBtn;
	
	@FindBy(xpath = "//button[contains(.,'Move')][contains(.,'Material')]")
	private WebElement moveMaterial;
	
	@FindBy(xpath = "(//input[@type=\"checkbox\"])[1]")
	private WebElement selectAllcheckbox;
	
	@FindBy(xpath = "//button[contains(.,'add item')]")
	private WebElement addItemPricebookBtn;
	
	@FindBy(xpath = "//button[@data-testid='filter']")
	private WebElement filterBtn;

	@FindBy(xpath = "//button[.='Apply']")
	private WebElement applyBtn;

	@FindBy(css = "tr.MuiTableRow-hover td:nth-child(2) p")
	private WebElement serviceItemName;

	@FindBy(css = "tr.MuiTableRow-hover td:nth-child(2)")
	private WebElement materialItemName;	

	public CategoryPage(WebDriver driver) {
		super(driver);
	}

	public void clickAddService() {
		try {
			addServiceBtn.click();
		} catch (NoSuchElementException e) {
			addFirstServiceBtn.click();
		}
	}
	
	//FIXME: PLAT - 2712 Save button need to be clicked twice. Remove this once this bug fixed
	public boolean isAddService() {
		return addServiceBtn.isDisplayed();
	}

	public void clickService(String serviceName) {
		WebElement e=driver.findElement(By.xpath("//tr[contains(.,'" + serviceName + "')]"));
		PageUtils.clickUsingJS(driver, e);
	}

	public void clickEdit(String serviceName) {
		clickServiceOptionsIcon(serviceName);
		driver.findElement(By.xpath("//li[contains(.,'Edit')]")).click();
	}

	public void clickServiceOptionsIcon(String serviceName) {
		driver.findElement(By.xpath("//tr[contains(.,'" + serviceName + "')]/td[last()]//button")).click();
	}

	public void clickMoveServiceLocationIcon(String serviceName) {
		clickServiceOptionsIcon(serviceName);
		driver.findElement(By.xpath("//li[contains(.,'Move Location')]")).click();
		driver.findElement(By.xpath("//span[contains(.,'Move 1 Service')]")).click();
	}

	public void clickReorderServiceIcon(String serviceName) {
		clickServiceOptionsIcon(serviceName);
		driver.findElement(By.xpath("//li[contains(.,'Reorder')]")).click();
	}

	public void reorder(String fromName, String toName) {
		WebElement from = driver.findElement(By.xpath("//tr[contains(.,'" + fromName + "')]"));
		WebElement to = driver.findElement(By.xpath("//tr[contains(.,'" + toName + "')]"));

		Actions builder = new Actions(driver);
		builder.dragAndDrop(from, to);

	}

	public void clickSaveOrderButton() {
		driver.findElement(By.xpath("//span[contains(.,'Save Order')]")).click();
	}

	public void clickDeleteServiceItem(String serviceName) {
		driver.findElement(By.xpath("//tr[contains(.,'" + serviceName + "')]/td[last()]//button")).click();
		driver.findElement(By.xpath("//li[contains(.,'Delete')]")).click();
	}

	public void clickAddItem() {
		waitHelper.waitForElementToBeClickable(addItemBtn, WAIT_TIME_IN_SECS);
		addItemBtn.click();
		waitForPageToLoad(1);
	}

	public void clickItemOptionsIcon(String itemName) {
		waitForPageToLoad(1);
		driver.findElement(By.xpath("//tr[contains(.,'" + itemName + "')]/td[8]//button")).click();
		waitForPageToLoad(1);
	}

	public void clickEditItemIcon(String itemName) {
		clickItemOptionsIcon(itemName);
		element.click(By.xpath("//li[contains(.,'Edit')]"));
		waitHelper.waitForElementToBeVisible(By.xpath("//h5[contains(.,'Edit materials item')]"));
	}

	public void clickReorderItemIcon(String itemName) {
		clickItemOptionsIcon(itemName);
		driver.findElement(By.xpath("//li[contains(.,'Reorder')]")).click();
	}

	public void clickMoveItemLocationIcon(String itemName) {
		clickItemOptionsIcon(itemName);
		driver.findElement(By.xpath("//li[contains(.,'Move Location')]")).click();
		waitForPageToLoad(1);
	}

	public void clickDeleteItemIcon(String itemName) {
		clickItemOptionsIcon(itemName);
		driver.findElement(By.xpath("//li[contains(.,'Delete')]")).click();
	}

	public void waitForDeletedMessageToClear() {
		waitHelper.waitForElementToBeNotVisible(By.xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'deleted')]"));
	}

	public boolean isReorderMessageDisplayed() {
		By reorderMsg = By.xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'successfully reordered')]");
		return element.isDisplayed(reorderMsg);
	}

	public void clickMoveMaterial() {
		moveMaterial.click();
	}

	public void selectAll() {
		selectAllcheckbox.click();
	}
	
	public void clickFirstServiceItem() {
		serviceItemName.click();
	}

	public void selectIndustry(String itemName) {
		WebElement e=driver.findElement(By.xpath("//span[text()='"+itemName+"']/ancestor::div/button"));
		PageUtils.clickUsingJS(driver, e);
	}

	public void selectCategory(String itemName) {
		WebElement e=driver.findElement(By.xpath("//span[text()='"+itemName+"']/ancestor::div/button"));
		PageUtils.clickUsingJS(driver, e);
	}

	public void clickAddItemFromPricebook() {
		waitHelper.waitForElementToBeClickable(addItemPricebookBtn, WAIT_TIME_IN_SECS);
		addItemPricebookBtn.click();
		waitForPageToLoad(1);
	}
	
	public void setFilter(String filterName) {
		filterBtn.click();
		driver.findElement(By.xpath("//span[@class='MuiButton-label'][text()='"+filterName+"']")).click();
		applyBtn.click();
	}

	public void clickFirstMaterialItem() {
		materialItemName.click();
	}

	public boolean isItemPrice(String price) {
		return searchForText("$"+price+".00");
	}
		
}
