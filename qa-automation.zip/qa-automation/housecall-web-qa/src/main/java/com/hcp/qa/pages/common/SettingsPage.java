package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.billing.pages.MyPlanPage;

public class SettingsPage extends Page {

	@FindBy(xpath = "//div[contains(text(),'Employees')]")
	private WebElement employeesIcon;

	@FindBy(xpath = "//div[contains(text(),'Company profile')]")
	private WebElement companyProfileIcon;

	@FindBy(xpath = "//div[contains(text(),'Tags')]")
	private WebElement tagsIcon;

	@FindBy(xpath = "//header//button")
	private WebElement closeBtn;

	@FindBy(xpath = "//h5[contains(.,'Settings')]")
	private WebElement title;

	@FindBy(xpath = "//div[contains(text(),'Billing')]")
	private WebElement billingIcon;

	@FindBy(xpath = "//div[contains(text(),'Job details')]")
	private WebElement jobFields;

	@FindBy(xpath = "//div[contains(text(),'Lead sources')]")
	private WebElement leadSources;

	@FindBy(xpath = "//div[contains(text(),'Communications')]")
	private WebElement communications;

	public SettingsPage(WebDriver driver) {
		super(driver);
	}

	public void clickEmployeesIcon() {
		element.click(employeesIcon);
	}

	public void clickTagsIcon() {
		element.click(tagsIcon);
	}

	public void clickCompanyProfileIcon() {
		element.click(companyProfileIcon);
	}

	public void clickClose() {
		element.click(closeBtn);
	}

	public boolean isTitleVisible() {
		return element.isDisplayed(title);
	}

	public boolean isCompanyProfileVisible() {
		return element.isDisplayed(companyProfileIcon);
	}

	public MyPlanPage clickBillingIcon() {
		element.click(billingIcon);
		waitHelper.waitForPageLoaded();

		return new MyPlanPage(driver);
	}

	public void clickJobFieldsIcon() {
		element.click(jobFields);
	}

	public void clickLeadSourcesIcon() {
		element.click(leadSources);
	}
	
	public void clickCommunications() {
		element.click(communications);
	}
}
