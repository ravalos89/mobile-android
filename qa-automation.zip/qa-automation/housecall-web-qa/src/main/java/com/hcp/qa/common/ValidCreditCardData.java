package com.hcp.qa.common;

public class ValidCreditCardData {
    public static final String CREDIT_CARD_NUMBER = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.number");
    public static final String EXPIRATION_DATE = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.expirationDate");
    public static final String CVC = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.cvc");
    public static final String POSTAL_CODE = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.postalCode");
}
