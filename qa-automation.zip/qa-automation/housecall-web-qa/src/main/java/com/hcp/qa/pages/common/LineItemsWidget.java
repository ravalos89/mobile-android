package com.hcp.qa.pages.common;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.models.LineItem;

import static org.openqa.selenium.By.xpath;

public class LineItemsWidget extends Page {

	@FindBy(xpath = "//button[@title='Edit team']")
	private WebElement editTeamIcon;

	@FindBy(xpath = "//label[contains(.,'Item name')]/following-sibling::div/input")
	private WebElement itemName;

	@FindBy(id = "taxable")
	private WebElement taxable;

	@FindBy(xpath = "//label[contains(.,'Description (optional)')]/following-sibling::div/textarea")
	private WebElement description;

	@FindBy(xpath = "//label[contains(.,'Qty')]/following-sibling::div/input")
	private WebElement qty;

	@FindBy(xpath = "//label[contains(.,'Unit price')]/following-sibling::div/input")
	private WebElement unitPrice;

	@FindBy(xpath = "//span[contains(.,'+ Services item')]")
	private WebElement servicesItem;

	@FindBy(xpath = "//span[contains(.,'+ Materials item') or contains(.,'+ materials item')]")
	private WebElement materialItem;

	@FindBy(xpath = "//span[contains(.,'+ Message')]")
	private WebElement messageOnInvoice;

	@FindBy()
	private WebElement subtotal;

	@FindBy()
	private WebElement total;

	@FindBy(xpath = "//label[contains(.,'Tax rate')]/..")
	private WebElement taxRate;

	@FindBy(xpath = "//span[contains(.,'Service Price Book')]")
	private WebElement servicePricebookBtn;

	@FindBy(xpath = "//span[contains(.,'Material Price Book')]")
	private WebElement materialPricebookBtn;

	@FindBy(xpath = "//span[contains(.,'+ services item') or contains(.,'+ Services item')]")
	private WebElement addServiceItem;

	@FindBy(xpath = "(//label[contains(.,'Item name')]/following-sibling::div/input)[2]")
	private WebElement serviceItemName;

	@FindBy(xpath = "(//label[contains(.,'Item name')]/following-sibling::div/input)[3]")
	private WebElement materialItemName;

	@FindBy(xpath = "//button[contains(.,'add item')]")
	private WebElement addItemBtn;

	@FindBy(css = "button[data-testid='visual-price-book-close-button']")
	private WebElement close;
	
	@FindBy(xpath = "//span[contains(.,'+ materials item') or contains(.,'+ Materials item')]")
	private WebElement materialPricebookJobBtn;
	
	@FindBy(xpath = "//h6[.='Materials']/ancestor::div/div[5]//label[contains(.,'Item name')]/following-sibling::div/input")
	private WebElement materialLineItemName;
	
	@FindBy(xpath = "(//input[@id='unit-price'])[1]")
	private WebElement serviceItemPrice;

	@FindBy(xpath = "(//input[@id='unit-price'])[2]")
	private WebElement materialItemPrice;
	
	public LineItemsWidget(WebDriver driver) {
		super(driver);
	}

	public void clickEditTeam() {
		element.click(editTeamIcon);
	}

	public void enterServiceLineItem(String itemName) { element.type(this.itemName, itemName); }

	public void enterMaterialLineItem(String itemName) { element.type(this.materialLineItemName, itemName); }

	public void enterDescription(String description) {
		element.type(this.description, description);
	}

	public void enterQuantity(String qty) {
		PageUtils.enterValueInPrefilledField(this.qty, qty);
	}

	public void enterUnitPrice(String unitPrice) {
		PageUtils.enterValueInPrefilledField(this.unitPrice, unitPrice);
	}
  
	public void clickTaxRate() {
		element.click(taxRate);
	}

	public void clickMaterialPricebook() {
		element.click(materialPricebookBtn);
	}

	public void selectItemFromDropDown(String profitRhinoLineItem) {
		element.click(xpath("//p[contains(text(),'"+profitRhinoLineItem+"')]"));
	}

	public void clickAddServiceItem() {
		element.click(addServiceItem);
	}

	public void clickServicePricebook() {
		element.click(servicePricebookBtn);
	}

	public void clickAddServiceItemFromEstimate() {
		element.click(servicesItem);
	}

	public void clickAddMaterialItem() {
		element.click(materialItem);
	}

	public void closePricebook() {
		element.click(close);
	}

	public void clickAddMaterialPricebookJob() {
		element.click(materialPricebookJobBtn);
	}

	public void addLineItem(LineItem lineItem) {
		enterServiceLineItem(lineItem.getName());
		enterDescription(lineItem.getDescription());
		if (lineItem.getQuantity() != 0)
			enterQuantity(String.valueOf(lineItem.getQuantity()));
		enterUnitPrice(String.valueOf(lineItem.getUnitPrice()));
	}

	public void updateLineItem(String updateLineItem) {
		element.click(itemName);
		waitForPageToLoad(1);
		if(!element.getAttributeValue(itemName).isEmpty()){
			element.type(itemName, Keys.ENTER.toString());
		}
		waitForPageLoaded();
		element.type(itemName, updateLineItem);
		waitForPageToLoad(5);
	}

	public void checkTaxable(boolean check) {
		if (check && !taxable.isSelected()) {
			element.click(taxable);
		} else if (!check && taxable.isSelected()) {
			element.click(taxable);
		}
	}

	public void addProfitRhinoServiceItem(String profitRhinoServiceLineItem) {
		element.type(serviceItemName, profitRhinoServiceLineItem);
		selectItemFromDropDown(profitRhinoServiceLineItem);
	}

	public void addProfitRhinoMaterialItem(String profitRhinoMaterialLineItem) {
		element.type(materialItemName, profitRhinoMaterialLineItem);
		selectItemFromDropDown(profitRhinoMaterialLineItem);
	}

	public boolean verifyCategoryNameInDropdown(String category) {
		return element.isDisplayed(xpath("//li[.='"+category+"']"));
	}

	public boolean verifyItemInDropdown(String itemName) {
		return element.isDisplayed(xpath("//p[.='"+itemName+"']"));
	}

	public String getServicePriceOnLineItem() {
		return element.getAttributeValue(serviceItemPrice);
	}

	public void setServicePriceOnLineItem(String price) {
		element.type(serviceItemPrice, price);
	}
	
	public String getMaterialPriceOnLineItem() {
		return element.getAttributeValue(materialItemPrice);
	}

	public void setMaterialPriceOnLineItem(String price) {
		element.type(materialItemPrice, price);
	}
	
}