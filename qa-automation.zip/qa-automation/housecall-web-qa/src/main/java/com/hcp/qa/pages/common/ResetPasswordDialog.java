package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ResetPasswordDialog extends Page {
	
	@FindBy(id="email")
	private WebElement email;
	
	@FindBy(xpath="//h2[contains(text(),'Reset Password')]")
	private WebElement title;
	
	@FindBy (xpath="//span[contains(.,'Cancel')]")
	private WebElement cancelBtn;
	
	@FindBy (xpath="//span[contains(.,'Send')]")
	private WebElement sendBtn;

	public ResetPasswordDialog(WebDriver driver) {
		super(driver);
	}
	
	public boolean isResetPasswordDisplayed() { return element.isDisplayed(title); }
	
	public void clickSend()
	{
		element.click(sendBtn);
	}
	
	public void clickCancel()
	{
		element.click(cancelBtn);
	}

}
