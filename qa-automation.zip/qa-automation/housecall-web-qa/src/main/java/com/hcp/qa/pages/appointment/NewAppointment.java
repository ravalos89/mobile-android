package com.hcp.qa.pages.appointment;

import com.hcp.qa.pages.schedule.AppointmentTimeReader;

public interface NewAppointment<T>  extends AppointmentTimeReader {

	void save();

	void waitForSaveButtonEnabled();

	String getStartDate();

	String getStartTime();

	T typeStartTime(String time);

	T enterStartTime(String time);

	String getEndDate();

	String getEndTime();

	boolean isDispatchByDisplayed();

	String getTimeZone();
}
