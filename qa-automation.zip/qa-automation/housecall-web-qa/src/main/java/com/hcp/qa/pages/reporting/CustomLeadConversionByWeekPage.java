package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CustomLeadConversionByWeekPage extends ReportChartPage{
	
	
	
	@FindBy(xpath="//div[contains(text(),'Quarter to date')]")
	WebElement quarterDateBtn;

	@FindBy(xpath="//div[contains(text(),'Created date')]")
	WebElement createdDateBtn;
	

	public CustomLeadConversionByWeekPage(WebDriver driver) {
		super(driver);
		
	}

	public void clickDateRange() {
		element.click(quarterDateBtn);
	}

	public void clickActionDate() {
		element.click(createdDateBtn);
	}
	
}
