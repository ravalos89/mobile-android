package com.hcp.qa.pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class BankInformationPage extends Page {

	@FindBy(xpath = "//button[contains(.,'Connect bank')]")
	private WebElement connectBank;

	@FindBy(xpath = "//span[contains(.,'Continue')]")
	private WebElement continueBtn;

	@FindBy(xpath = "//iframe[@title='Plaid Link']")
	private WebElement plaidLink;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement payBtn;

	public BankInformationPage(WebDriver driver) {
		super(driver);
	}

	public void clickConnectBank() { element.click(connectBank); }

	public void clickContinue() {
		driver.switchTo().frame(this.plaidLink);
		element.click(continueBtn);
	}


	public void clickPayBtn() {
		driver.switchTo().defaultContent();
		PageUtils.clickUsingJS(driver, payBtn);
	}

	public void waitForPaymentProcessingMessageToDisappear() {
		waitHelper.waitForElementToBeNotVisible(By.xpath("//h5[contains(text(),'Payment processing')]"));
	}
}
