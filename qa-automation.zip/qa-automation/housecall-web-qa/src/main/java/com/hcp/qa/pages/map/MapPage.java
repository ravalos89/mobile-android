package com.hcp.qa.pages.map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class MapPage extends Page {
	@FindBy(xpath = "//button[contains(.,'HCP Map')]")
	WebElement hcpMapBtn;

	public MapPage(WebDriver driver) {
		super(driver);
	}

	public boolean isHcpMapVisible() {
		return hcpMapBtn.isDisplayed();
	}

}
