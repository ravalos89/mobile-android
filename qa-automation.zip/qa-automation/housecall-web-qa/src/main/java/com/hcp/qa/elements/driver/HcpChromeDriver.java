package com.hcp.qa.elements.driver;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.hcp.qa.elements.Element;
import com.hcp.qa.elements.HcpWebElement;

public class HcpChromeDriver extends ChromeDriver{
	
	public HcpChromeDriver(ChromeOptions options)
	{
		super(options);
	}
	
	@Override
	public WebElement findElement(By by)
	{
		WebElement element=super.findElement(by);
		Element customElement= new HcpWebElement(element);
		return customElement;
	}
	
	@Override
	public List<WebElement> findElements(By by)
	{
		List<WebElement> elements=super.findElements(by);
		List<WebElement> customElements=new ArrayList<WebElement>();
		for(WebElement e: elements)
		{
		Element customElement= new HcpWebElement(e);
		customElements.add(customElement);
		}
		return customElements;
	}

}
