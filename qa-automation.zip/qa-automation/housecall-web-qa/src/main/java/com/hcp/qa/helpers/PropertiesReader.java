package com.hcp.qa.helpers;

import com.hcp.qa.common.ConfigHandler;

public class PropertiesReader {
	private static PropertiesReader instance = null;

	private String apiKey = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key");

	private String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");

	private String proUser = System.getProperty("proUser",
			ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user"));

	private String proPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.password");

	private String qboUser =ConfigHandler.getStringPropertyValueFromKey("hcp.web.qbo.user");
	
	private String pricebookUser=ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.pricebook.user");

	String email = ConfigHandler.getStringPropertyValueFromKey("hcp.web.email");

	String gmailPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.gmail.password");

	String phone = ConfigHandler.getStringPropertyValueFromKey("hcp.web.mobile.number");

	
	private PropertiesReader() {
	}

	public static PropertiesReader getInstance() {
		if (instance == null)
			instance = new PropertiesReader();
		return instance;
	}

	public String getProUser() {
		return proUser;
	}

	public String getPassword() {
		return proPassword;
	}

	public String getMobileNumber() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

	public String getApiKey() {
		return apiKey;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public String getQBOUser() {
		return qboUser;
	}

	public String getPriceBookUser() {
		return pricebookUser;
	}
}
