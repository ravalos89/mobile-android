package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class SaveDialog extends Page{
	@FindBy(xpath = "//span[contains(text(),'Cancel')]")
	private WebElement cancelBtn;
	
	@FindBy(xpath = "//span[contains(text(),'Save')]")
	private WebElement saveBtn;
	
	public SaveDialog(WebDriver driver) {
		super(driver);
	}
	public void clickCancel() {
		cancelBtn.click();
	}
	
	public void clickSave() {
		saveBtn.click();
	}
}
