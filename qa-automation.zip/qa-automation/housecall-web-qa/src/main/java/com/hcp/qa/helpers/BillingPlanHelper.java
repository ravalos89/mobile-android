package com.hcp.qa.helpers;

import com.hcp.qa.helpers.billing.plans.AddonsList;
import com.hcp.qa.pages.billing.dialogs.PlanUpdatedSuccessfullyDialog;
import com.hcp.qa.pages.billing.enums.BillingPlanName;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.ConfigureYourPlanModal;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.PickYourPlanModal;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.ReviewAndPayModal;
import com.hcp.qa.pages.billing.pages.MyPlanPage;
import com.hcp.qa.pages.payment.CreditCardInformationWidget;
import org.openqa.selenium.WebDriver;

import static com.hcp.qa.common.ValidCreditCardData.CREDIT_CARD_NUMBER;
import static com.hcp.qa.common.ValidCreditCardData.CVC;
import static com.hcp.qa.common.ValidCreditCardData.EXPIRATION_DATE;
import static com.hcp.qa.common.ValidCreditCardData.POSTAL_CODE;

public class BillingPlanHelper {

    private final WebDriver driver;
    private final NavigationHelper navigationHelper;

    public BillingPlanHelper(WebDriver driver) {
        this.driver = driver;
        this.navigationHelper = new NavigationHelper(driver);
    }

    public void enrollToBillingPlan(BillingPlanName planName, Boolean isBilledAnnually, AddonsList addons) {
        MyPlanPage myPlanPage = navigationHelper.goToBillingPage();

        PickYourPlanModal pickYourPlanModal = myPlanPage.chooseToChangePlan();
        pickYourPlanModal.selectPlan(planName);
        pickYourPlanModal.setPlanBilledAnnually(isBilledAnnually);

        ConfigureYourPlanModal configureYourPlanModal = pickYourPlanModal.proceedToConfigureYourPlanModal();

        // for now only additional logins are supported, will be extended in future
        if (addons != null) {
            configureYourPlanModal.setAdditionalLoginsNumber(addons.additionalLogins);
        }

        ReviewAndPayModal reviewAndPayModal = configureYourPlanModal.proceedToReviewAndPayPage();
        enterCardDetails();

        PlanUpdatedSuccessfullyDialog planUpdatedSuccessfullyDialog = reviewAndPayModal.payNow();
        planUpdatedSuccessfullyDialog.clickCloseDialog();
    }

    public void enrollToBillingPlan(BillingPlanName planName, Boolean isBilledAnnually) {
        enrollToBillingPlan(planName, isBilledAnnually, null);
    }

    public void enterCardDetails() {
        new ReviewAndPayModal(driver).enterNameOnCard("hcpPro");
        CreditCardInformationWidget creditCard = new CreditCardInformationWidget(driver);
        creditCard.enterCardNumber(CREDIT_CARD_NUMBER);
        creditCard.enterExpirationDate(EXPIRATION_DATE);
        creditCard.enterCvcCode(CVC);
        creditCard.enterPostalCode(POSTAL_CODE);
    }
}
