package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DeleteDialog extends Page {

	@FindBy(xpath = "//span[text()='Delete']")
	private WebElement deleteBtn;

	@FindBy(xpath = "//span[contains(.,'Cancel')]")
	private WebElement cancelBtn;

	@FindBy(xpath = "//span[contains(.,'Confirm')]") // Delete Customer should probably get Devs to standardize it to

	private WebElement confirmBtn;

	public DeleteDialog(WebDriver driver) {
		super(driver);
	}

	public void clickDelete() {
		element.click(deleteBtn);
	}

	public void clickCancel() {
		element.click(cancelBtn);
	}

	public void clickConfirm() {
		element.click(confirmBtn);
	}
}
