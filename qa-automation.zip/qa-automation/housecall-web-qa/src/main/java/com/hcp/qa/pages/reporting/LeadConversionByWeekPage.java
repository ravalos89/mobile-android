package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeadConversionByWeekPage extends CustomLeadConversionByWeekPage {

	@FindBy(xpath = "//div[contains(text(),'Quarter to date')]")
	private WebElement quarterDateBtn;

	@FindBy(xpath = "//div[contains(text(),'Created date')]")
	private WebElement createdDateBtn;

	public LeadConversionByWeekPage(WebDriver driver) {
		super(driver);
	}

	public void clickDateRange() {
		element.click(quarterDateBtn);
	}

	public void clickActionDate() {
		element.click(createdDateBtn);
	}

}
