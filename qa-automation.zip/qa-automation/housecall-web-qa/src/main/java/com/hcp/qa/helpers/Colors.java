package com.hcp.qa.helpers;

public enum Colors {

        //TODO remove onboarding button color after ticket ONB-1382 is fixed
        ONBOARDING_BUTTON_BLUE("rgba(33, 150, 243, 1)"),
        BUTTON_BLUE("rgba(15, 119, 204, 1)"),
        OWNERS_ORANGE("rgba(239, 145, 89, 1)");

        private final String value;

        Colors(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
}
