
package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AverageJobSizePage extends ReportChartPage {


	
	@FindBy(xpath="//div[contains(text(),'Year to date')]")
	WebElement yearToDateBtn;

	@FindBy(xpath="//div[contains(text(),'Scheduled date')]")
	WebElement scheduledBtn;

	@FindBy(xpath="//button//span[contains(text(),'EXPORT')]/parent::*/parent::*")
	WebElement exportBtn;
	
	@FindBy(xpath="//button//span[contains(text(),'Manage Filters')]")
	WebElement manageFiltersBtn;
	
	@FindBy(xpath="//button//span[contains(text(),'Edit columns')]")
	WebElement editColumnBtn;
	
	@FindBy(xpath="//table//span[contains(text(),'Month')]")
	WebElement monthColumn;
	
	@FindBy(xpath="//table//h6[contains(text(),'Avg job size')]")
	WebElement averageJobSizeColumn;

	
	public AverageJobSizePage(WebDriver driver) {
		super(driver);
	}

	public void clickDateRange() { element.click(yearToDateBtn); }
	
	public void clickActionDate() { element.click(scheduledBtn); }
	
	
	public boolean isAverageJobSizeColumnDisplayed() { return element.isDisplayed(averageJobSizeColumn); }
	
	public boolean isMonthColumnDisplayed() { return element.isDisplayed(monthColumn); }

}