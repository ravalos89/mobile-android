package com.hcp.qa.pages.schedule;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.schedule.calendar.full.dialog.CalendarSettingsDialog;

public class SchedulePage extends Page {

	private static final Logger LOG = LoggerFactory.getLogger(SchedulePage.class);

	private final TeamCalendars teamCalendars;
	@FindBy(xpath = "//div[contains(@class,'rbc-current')]")
	private WebElement currentDate;

	@FindBy(xpath = "//button[contains(.,'Today')]")
	private WebElement todayBtn;

	@FindBy(xpath = "//a[contains(.,'Today')]")
	private WebElement oldCalTodayBtn;

	@FindBy(xpath = "//div[@data-testid='fc-calendar-view-container']//span[@title='Settings']/button")
	private WebElement cogwheelButton;

	@FindBy(xpath = "//span[text()='Job Updated']")
	private WebElement JobUpdatedNotification;

	@FindBy(xpath = "//div[@id='beta-feature-active-banner']//input[@type='checkbox']")
	private WebElement oldCalendarToggle;

	@FindBy(xpath = "//p/following-sibling::div//input[@type='checkbox']")
	private WebElement newCalendarToggle;

	@FindBy(xpath = "//button[@data-testId='calendar-menu-button']")
	private WebElement hamburgerButton;

	@FindBy(xpath = "//*[contains(text(),'Today')]")
	private WebElement calendarTypeIdentifier;

	private NewMenuWidget newMenu;

	public SchedulePage(WebDriver driver) {
		super(driver);
		teamCalendars = new TeamCalendars(driver);
	}

	public void clickCurrentDate() {
		element.click(currentDate);
	}

	public void clickNewJob() {
		newMenu = new NewMenuWidget(driver);
		newMenu.clickNewJob();
	}

	public void clickNewEstimate() {
		newMenu.clickNewEstimate();
	}

	public boolean isTodayButtonVisible()
	{
		try {
			return todayBtn.isDisplayed();
		}
		catch(NoSuchElementException e)
		{
			LOG.info(" Old Calendar ");
			return oldCalTodayBtn.isDisplayed();
		}
	}

	public CalendarSettingsDialog clickCogwheelButton() {
		element.click(cogwheelButton);
		return new CalendarSettingsDialog(driver);
	}

	public boolean isNewCalendarOn() {
		return !waitHelper.waitForElementToBeVisible(calendarTypeIdentifier).getAttribute("class").contains("k-link");
	}

	public void clickToggleOnOldCalendar() {
		element.click(oldCalendarToggle);
	}

	public void clickToggleOnNewCalendar() {
		element.click(newCalendarToggle);
	}

	public void switchToOldCalendar() {
		if(isNewCalendarOn()) {
			clickToggleOnNewCalendar();
		}
	}

	public void switchToNewCalendar() {
		if(!isNewCalendarOn()) {
			clickToggleOnOldCalendar();
		}
	}

	public void openMenu() {
		if(!teamCalendars.isTeamCalendarVisible()) {
			clickMenu();
		}
	}

	public void clickMenu() {
		element.click(hamburgerButton);
	}

	public void waitForJobUpdatedNotification() {
		waitHelper.waitForElementToBeVisible(JobUpdatedNotification);
	}
}
