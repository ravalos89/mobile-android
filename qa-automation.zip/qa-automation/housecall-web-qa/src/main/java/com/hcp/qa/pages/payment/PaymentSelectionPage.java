package com.hcp.qa.pages.payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class PaymentSelectionPage extends Page {

	public PaymentSelectionPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//span[contains(.,'Credit card')]/..//input")
	private WebElement ccRadioBtn;

	@FindBy(xpath = "//span[contains(.,'Bank account')]/..//input")
	private WebElement achRadioBtn;

	@FindBy(xpath = "//input[@value='consumerLending']")
	private WebElement lendingRadioBtn;

	@FindBy(xpath = "//span[contains(.,'View Details')]")
	private WebElement viewDetailsBtn;
	
	@FindBy(xpath = "//div[contains(text(),'Deposit Due')]")
	private WebElement depositDueTitle;

	@FindBy(xpath = "//span[contains(.,'SEE MY OPTIONS')]")
	private WebElement seeMyOptionsBtn;

	@FindBy(xpath = "//span[contains(.,'SEE MY OPTIONS)'/parent::a]")
	private WebElement wisetackLink;
	
	@FindBy(xpath = "//span[contains(.,'Job Summary')]")
	private WebElement jobSummaryTitle;

	public void selectCreditCard() {
		if(element.isDisplayed(ccRadioBtn) && !ccRadioBtn.isSelected())
			PageUtils.clickUsingJS(driver, ccRadioBtn);
		
	}

	public void selectACH() {
		if (!achRadioBtn.isSelected())
			PageUtils.clickUsingJS(driver, achRadioBtn);
	}

	public void selectLending() {
		if (!lendingRadioBtn.isSelected())
			element.click(lendingRadioBtn);
	}

	public void clickSeeMyOptions() {
		element.click(seeMyOptionsBtn, 30);
	}

	public AddTipWidget addTip() {
		return new AddTipWidget(driver);
	}
	
	public boolean isDepositDueDisplayed()  { return element.isDisplayed(depositDueTitle); }

}
