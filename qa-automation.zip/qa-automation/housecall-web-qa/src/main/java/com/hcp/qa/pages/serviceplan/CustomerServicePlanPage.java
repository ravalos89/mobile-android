package com.hcp.qa.pages.serviceplan;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class CustomerServicePlanPage extends Page {

	@FindBy(css = "[aria-label='close']")
	private WebElement close;

	@FindBy(xpath = "//button[contains(@class,'MuiIconButton-colorInherit')]")
	private WebElement back;
	
	@FindBy(xpath = "//div[contains(@class,'MuiGrid-justify-xs-space-between')]/div[2]//div[last()]/button")
	private WebElement threeDots;	

	@FindBy(xpath = "//span[.='Cancel service plan']")
	private WebElement cancelServicePlan;

	@FindBy(xpath = "//button[.='Cancel plan']")
	private WebElement cancelPlan;
	
	@FindBy(xpath = "//p[contains(.,'to confirm')]/..//input")
	private WebElement deleteOrCancel;	

	@FindBy(xpath = "(//button[@aria-label='schedule visit'])[1]")
	private WebElement scheduleVisit;

	@FindBy(xpath = "//span[.='Visits']/ancestor::div//tbody/tr[1]/td[2]//span")
	private WebElement invoiceNumber;
		
	@FindBy(xpath = "(//span[@title='Pay']/button)[1]")
	private WebElement pay;	
	
	@FindBy(xpath = "(//h5)[2]")
	private WebElement servicePlanName;
	
	@FindBy(xpath = "//div[@data-testid='service-agreement-discount']//h4")
	private WebElement discountPercent;
	
	public CustomerServicePlanPage(WebDriver driver) {
		super(driver);
	}

	public void clickThreeDots() {
		threeDots.click();
	}

	public void clickCancelServicePlan() {
		cancelServicePlan.click();
	}

	public void cancelServicePlan() {
		deleteOrCancel.sendKeys("Cancel");
		cancelPlan.click();
	}
	
	public void clickClose() {
		element.click(close,50);
		waitForPageLoaded();
	}

	public void clickBack() {
		back.click();
		waitForPageToLoad(2);
	}
	
	public void clickScheduleVisit() {
		waitForPageToLoad(1);
		element.click(scheduleVisit);
	}
	
	public String getInvoiceNumber() {
		return StringUtils.substringAfter(invoiceNumber.getText(), "#").trim();
	}
	
	public void clickPay() {
		PageUtils.scrollIntoView(driver, pay);
		PageUtils.clickUsingJS(driver, pay);
	}
	
	public boolean isServicePlanPaymentFailedDisplayed() {
		return driver.findElement(By.xpath("//h6[.='Payment failure']")).isDisplayed()
				&& driver.findElement(By.xpath("//p[.='Your card was declined.']")).isDisplayed();
	}

	public String getServicePlanName() {
		return servicePlanName.getText();
	}

	public String getDiscountPercentage() {
		if(element.isDisplayed(discountPercent))
			return element.getText(discountPercent);
		else 
			return "No Discount";
		
	}
	
}