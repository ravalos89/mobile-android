package com.hcp.qa.pages.dashboard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class UpcomingJobsWidget extends Page {

	@FindBy(xpath = "//span[@title='Add job']")
	private WebElement jobIcon;

	public UpcomingJobsWidget(WebDriver driver) {
		super(driver);
	}

	public void clickAddJobIcon() {
		jobIcon.click();
	}

}
