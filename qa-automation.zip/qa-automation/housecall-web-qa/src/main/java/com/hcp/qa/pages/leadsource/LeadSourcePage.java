package com.hcp.qa.pages.leadsource;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class LeadSourcePage extends Page {

	@FindBy(xpath = "//span[.='LEAD SOURCE']")
	WebElement addLeadSource;

	@FindBy(css = "[data-testid='create-lead-source-field']")
	WebElement leadSourceInput;
	
	@FindBy(xpath = "//span[.='CREATE']")
	WebElement create;
	
	@FindBy(css = "[placeholder='Search...']")
	WebElement searchLeadSource;

	@FindBy(xpath = "//span[.='DELETE']")
	private WebElement delete;
	
	@FindBy(xpath = "//span[.='Delete']")
	private WebElement confirmDelete;

	@FindBy(xpath = "//span[.='Save']")
	private WebElement save;
	
	@FindBy(css = "[data-testid='edit-lead-source-field']")
	WebElement editLeadSource;

	@FindBy(xpath = "//span[.='Cancel']")
	private WebElement cancel;

	public LeadSourcePage(WebDriver driver) {
		super(driver);
	}

	public void clickAddLeadSource() {
		addLeadSource.click();
	}

	public void enterLeadSourceName(String leadSource) {
		leadSourceInput.sendKeys(leadSource);
	}

	public void clickCreateBtn() {
		create.click();
	}
	
	public void delete() {
		delete.click();
	}
	
	public void confirmDelete() {
		confirmDelete.click();
	}

	public void clickSaveBtn() {
		save.click();
	}
	
	public void clickCancel() {
		cancel.click();
	}

	public void enterLeadSourceInSearch(String leadSourceName) {
		waitHelper.waitForElementToBeClickable(searchLeadSource);
		searchLeadSource.click();
		searchLeadSource.sendKeys(leadSourceName);
		waitForPageToLoad(2);
	}

	public void clickLeadSource(String leadSource) {
		driver.findElement(By.xpath("//div[.='"+leadSource+"']")).click();
		waitForPageToLoad(1);
	}

	public void editLeadSourceName(String leadSourceUpdated) {
		editLeadSource.clear();
		editLeadSource.sendKeys(leadSourceUpdated);		
	}

	public boolean isErrorMessageDisplayed() {
		return driver.findElement(By.xpath("//p[contains(.,'Name has already been taken')]")).isDisplayed();
	}
	
}
