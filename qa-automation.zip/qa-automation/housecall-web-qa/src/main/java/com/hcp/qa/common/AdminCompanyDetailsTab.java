package com.hcp.qa.common;

public enum AdminCompanyDetailsTab {

    SAAS_PLAN("Saas plan"),
    PAYMENTS_PLAN("Payments plan"),
    BUSINESS_INFO("Business info"),
    SOURCE("Source"),
    ACTIVITY_FEED("Activity feed"),
    WEBSITE_BUILDER("Website builder"),
    APPS("Apps"),
    FRANCHISES("Franchises"),
    RISK_SUPPORT("Risk support"),
    SUPPORT("Support");

    private final String value;

    AdminCompanyDetailsTab(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
