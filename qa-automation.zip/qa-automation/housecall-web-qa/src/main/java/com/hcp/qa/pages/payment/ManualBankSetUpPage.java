package com.hcp.qa.pages.payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ManualBankSetUpPage extends Page {

	@FindBy(xpath = "//h2[contains(.,'Having trouble connecting your bank?')]")
	private WebElement manualSetUpTitle;

	@FindBy(id = "account_number")
	private WebElement accountNumber;

	@FindBy(id = "account_number_confirmation")
	private WebElement accountNumberConfirmation;

	@FindBy(id = "routing_number")
	private WebElement routingNumber;

	public ManualBankSetUpPage(WebDriver driver) {
		super(driver);
	}

	public boolean isManualSetUpTitlePresent() {
		return element.isDisplayed(manualSetUpTitle);
	}

	public boolean isAccountNumberPresent() { return element.isDisplayed(accountNumber); }

	public boolean isAccountNumberConfirmationPresent() { return element.isDisplayed(accountNumberConfirmation); }

	public boolean isRoutingNumberPresent() {
		return element.isDisplayed(routingNumber);
	}
}
