package com.hcp.qa.pages.serviceplan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.pages.common.Page;

public class ServicePlanSummaryPage extends Page{
	
	@FindBy(xpath = "(//h4)[1]")
	private WebElement servicePlanName;

	@FindBy(xpath = "(//h4)[2]")
	private WebElement visitPerYear;

	@FindBy(xpath = "(//h4)[3]")
	private WebElement yearsInDuration;

	@FindBy(xpath = "(//h4)[4]")
	private WebElement monthlyCost;

	@FindBy(xpath = "//span[.='Add-ons']/ancestor::div//div[contains(@class,'MuiGrid-spacing-xs-2')]/div/div[1]/div[1]//p")
	private WebElement addOnName;

	@FindBy(xpath = "//span[.='Add-ons']/ancestor::div//div[contains(@class,'MuiGrid-spacing-xs-2')]/div/div[1]/div[2]//p")
	private WebElement addOnPrice;
	
	@FindBy(xpath = "//span[.='Confirm plan']")
	private WebElement confirmPlanBtn;
	
	@FindBy(xpath = "//p[contains(.,'to confirm')]/..//input")
	private WebElement deleteOrCancel;
	
	@FindBy(xpath = "//span[.='Archive']")
	private WebElement archive;

	@FindBy(xpath = "//span[.='Delete']")
	private WebElement deleteConfirm;	

	@FindBys(@FindBy(css = ".MuiListItem-gutters.MuiListItem-divider h6"))
	List<WebElement> plansList;

	@FindBy(xpath = "//div[@data-testid='service-agreement-discount']//h4")
	private WebElement discountPercent;
	
	@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root']")
	private WebElement threeDotsIcon;

	@FindBy(xpath = "//span[.='Edit service plan']")
	private WebElement editServicePlanBtn;

	@FindBy(xpath = "//span[.='Delete service plan']")
	private WebElement deleteServicePlanBtn;
	
	public void editServicePlan() {
		threeDotsIcon.click();
		editServicePlanBtn.click();
	}

	public void clickDeleteServicePlan() {
		threeDotsIcon.click();
		deleteServicePlanBtn.click();
	}
	
	public List<WebElement> getAllServicePlans() {
		return plansList;
	}
	
	public void enterDeleteToConfirmDelete() {
		deleteOrCancel.sendKeys("DELETE");
	}
	
	public ServicePlanSummaryPage(WebDriver driver) {
		super(driver);
	}
	public String getServicePlanName() {
		return servicePlanName.getText();
	}

	public String getVisitPerYearCount() {
		return visitPerYear.getText();
	}

	public String getMonthlyAmount() {
		return monthlyCost.getText();
	}

	public String getAddOnItemName() {
		return addOnName.getText();
	}

	public String getAddOnItemPrice() {
		return addOnPrice.getText();
	}

	public boolean isServicePlanActivatedMessage() {
		return element.isDisplayed(By.xpath("//p[.='Service plan is now active']"));
	}
	
	public boolean isEmailSentMessage() {
		return driver.findElement(By.xpath("//*[.='Email has been sent']")).isDisplayed();
	}

	public void deleteOrArchive() {
		if (searchForText("This plan has been added to")) {
			deleteOrCancel.sendKeys("DELETE");
			archive.click();
		}
		else {
			deleteConfirm.click();
		}
	}
	
	public void clickArchive() {
		archive.click();
	}
	
	public void clickDeleteConfirm() {
		deleteConfirm.click();
	}
	public boolean isPlanDisplayedOnServicePlans(String planName) {
		for (WebElement plan : plansList) {
			if (plan.getText().equalsIgnoreCase(planName)) {
				return true;
			}
		}
		return false;
	}
}
