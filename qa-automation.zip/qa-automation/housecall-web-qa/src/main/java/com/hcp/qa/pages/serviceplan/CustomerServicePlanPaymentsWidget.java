package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.helpers.WaitHelper;
import com.hcp.qa.pages.common.Page;

public class CustomerServicePlanPaymentsWidget extends Page {

	@FindBy(xpath = "//label[.='Name on card']/..//input")
	private WebElement nameOnCard;

	@FindBy(xpath = "//button[.='save']")
	private WebElement saveBtn;

	@FindBy(xpath = "//button[.='CASH']")
	private WebElement cashTab;

	@FindBy(xpath = "//button[.='Mark as paid - cash']")
	private WebElement markAsPaidCash;	

	@FindBy(xpath = "//button[.='Update credit card']")
	private WebElement updateCreditCard;

	@FindBy(xpath = "//div[@data-testid='credit-card-layout']//div[2]/p")
	private WebElement creditCard4Digit;

	@FindBy(css = "[data-testid='credit-card-layout']+table>tbody>tr:nth-child(1)>td:nth-child(3) p")
	private WebElement paymentStatus;

	@FindBy(xpath = "//button[.='CHECK']")
	private WebElement checkTab;

	@FindBy(xpath = "//button[.='Mark as paid - check']")
	private WebElement markAsPaidCheck;
	
	@FindBy(css = "header div>button:nth-child(2)[tabindex='0']")
	private WebElement threeDots;
	
	public CustomerServicePlanPaymentsWidget(WebDriver driver) {
		super(driver);
	}
		public void enterNameOnCard(String name)	{
		nameOnCard.sendKeys(name);
	}
  	public void clickSave() {
		saveBtn.click();
	}
	public void clickCashTab() {
		cashTab.click();
	}
	public void clickMarkAsPaidCash() {
		markAsPaidCash.click();
	}
	
	public void clickUpdateCreditCard() {
		updateCreditCard.click();
	}

	public boolean isUpdateCreditCardDisplayed() {
		return updateCreditCard.isDisplayed();
	}

	public String getCardNumberAndExpiryDate() {
		return creditCard4Digit.getText();
	}

	public boolean isPaymentStatusDisplayed(String status) {
		WaitHelper waitHelper = new WaitHelper(driver);
		waitHelper.waitForAnyTextToBePresent(paymentStatus);
		return paymentStatus.getText().equals(status);
	}
	public void clickCheckTab() {
		checkTab.click();
	}
	public void clickMarkAsPaidCheck() {
		markAsPaidCheck.click();
	}
	
	public void clickThreeDots() {
		threeDots.click();
	}


}