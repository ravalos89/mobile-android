package com.hcp.qa.elements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.WrapsElement;
import org.openqa.selenium.interactions.Locatable;

@ImplementedBy(HcpWebElement.class)
public interface Element extends WebElement, WrapsElement, Locatable {

	String getLocator();

}