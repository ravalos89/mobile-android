package com.hcp.qa.pages.serviceplan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ServicePlansDashboardPage extends Page {

	@FindBy(xpath = "//span[contains(text(),'Service plan')] | //span[contains(text(),'Service Plan')]")
	private WebElement addServicePlan;
	@FindBy(xpath = "//h5[.='Help']/../button/span")
	private WebElement closeHelp;

	@FindBy(xpath = "//header[contains(@class,'MuiAppBar-positionFixed MuiAppBar-colorPrimary')]//span[@title='Settings']/button")
	private WebElement settings;

	@FindBy(xpath = "//span[@title='Schedule visit']/button")
	private WebElement calendarIcon;

	@FindBy(xpath = "//div[@role=\"none presentation\"]//header[1]//div[2]//div/div[2]//button")
	private WebElement threeDots;

	@FindBy(xpath = "//span[.='Cancel service plan']")
	private WebElement cancelServicePlan;

	@FindBy(xpath = "//button[.='Cancel plan']")
	private WebElement cancelPlanBtn;

	@FindBy(xpath = "//button[.='Update credit card']")
	private WebElement updateCreditCardBtn;

	@FindBy(xpath = "//div[@data-testid='credit-card-layout']//div[2]/p")
	private WebElement creditCard4Digit;

	@FindBy(css = "[data-testid='credit-card-layout']+table>tbody>tr:nth-child(1)>td:nth-child(3) p")
	private WebElement paymentStatus;

	private void clickCloseHelp() {
		closeHelp.click();
	}

	public void clickAddServicePlan() {
		PageUtils.clickUsingJS(driver, addServicePlan);
	}

	public void clickSettings() {
		settings.click();
	}
	
	@FindBys(@FindBy(css = ".MuiListItem-gutters.MuiListItem-divider h6"))
	List<WebElement> plansList;

	public List<WebElement> getAllServicePlans() {
		return plansList;
	}

	public ServicePlansDashboardPage(WebDriver driver) {
		super(driver);
		waitForPageToLoad(2);
		if (searchForText("Want to grow? Join the club.")) {
			clickCloseHelp();
			waitForPageToLoad(1);
		}
	}

	public boolean validatePlanDisplayedOnServicePlans(String planName) {
		for (WebElement plan : plansList) {
			if (plan.getText().equalsIgnoreCase(planName)) {
				return true;
			}
		}
		return false;
	}

	public void clickServicePlan(String planName) {
		for (WebElement plan : plansList) {
			if (plan.getText().equalsIgnoreCase(planName)) {
				plan.click();
				return;
			}
		}
	}

	public boolean isAddServicePlanDisplayed() {
		return addServicePlan.isDisplayed();
	}

	public boolean isServicePlansTitleVisible() {
		return driver.findElement(By.xpath("//h5[contains(.,'Service plans')]")).isDisplayed();
	}
}
