package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeadConversionByMonthPage extends CustomLeadConversionByWeekPage {

	@FindBy(xpath = "//div[contains(text(),'Year to date')]")
	private WebElement yearToDateBtn;

	@FindBy(xpath = "//div[contains(text(),'Created date')]")
	private WebElement createdDateBtn;

	public LeadConversionByMonthPage(WebDriver driver) {
		super(driver);
	}

	public void clickDateRange() {
		element.click(yearToDateBtn);
	}

	public void clickActionDate() {
		element.click(createdDateBtn);
	}

}
