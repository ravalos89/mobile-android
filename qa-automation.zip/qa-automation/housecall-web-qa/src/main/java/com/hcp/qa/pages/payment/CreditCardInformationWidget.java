package com.hcp.qa.pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class CreditCardInformationWidget extends Page {

	@FindBy(xpath = "//iframe[@title='Secure card number input frame']")
	private WebElement cardNumber;

	@FindBy(xpath = "//iframe[@title='Secure expiration date input frame']")
	private WebElement expirationDate;

	@FindBy(xpath = "//iframe[@title='Secure CVC input frame']")
	private WebElement cvc;

	@FindBy(xpath = "//iframe[@title='Secure postal code input frame']")
	private WebElement postalCode;
	
	@FindBy(name = "zip")
	private WebElement zip;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement payBtn;

	@FindBy(xpath="//input[@type='checkbox']")
	private WebElement saveCardOnFileCheckBox;

	@FindBy(xpath="//input[@name='passwordText']")
	private WebElement passwordForSaveCardOnFile;

	@FindBy(xpath = "//span[contains(.,'Charge card')]")
	private WebElement chargeCard;
	
	public CreditCardInformationWidget(WebDriver driver) {
		super(driver);
	}


	public void enterCardNumber(String cardNumber) {
		element.click(this.cardNumber);
		driver.switchTo().frame(this.cardNumber);
		element.type(By.xpath("//div[@class='CardNumberField-input-wrapper']//input"), cardNumber);
		driver.switchTo().defaultContent();
	}

	public void enterExpirationDate(String expirationDate) {
		element.click(this.expirationDate);
		driver.switchTo().frame(this.expirationDate);
		element.type(By.xpath("//input[@name='exp-date']"), expirationDate);
		driver.switchTo().defaultContent();
	}

	public void enterCvcCode(String cvc) {
		element.click(this.cvc);
		driver.switchTo().frame(this.cvc);
		element.type(By.xpath("//input[@name='cvc']"), cvc);
		driver.switchTo().defaultContent();
	}
	public void enterZip(String zip) {
		element.click(this.zip);
		element.type(this.zip, zip);
	}

	public void checkSaveCreditCardOnFile(){
		element.click(saveCardOnFileCheckBox);
	}

	public void enterSaveCardOnFilePassword(String password){
		element.click(passwordForSaveCardOnFile);
		element.type(passwordForSaveCardOnFile, password);
	}

	public void enterPostalCode(String postalCode) {
		element.click(this.postalCode);
		driver.switchTo().frame(this.postalCode);
		element.type(By.xpath("//input[@data-elements-stable-field-name='postalCode']"), postalCode);
		driver.switchTo().defaultContent();
	}

	public void clickPayButton() {
		PageUtils.clickUsingJS(driver, payBtn);
	}

	public void clickChargeCard(){
		element.click(chargeCard);
		waitForPageToLoad(4);
	}
	
}
