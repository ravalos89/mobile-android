package com.hcp.qa.pages.jobfields;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

import static org.openqa.selenium.By.xpath;

public class JobFieldsPage extends Page {
	@FindBy(xpath = "//span[.='job type']")
	WebElement addJobType;

	@FindBy(xpath = "//span[.='business unit']")
	WebElement addBusinessUnit;
	
	@FindBy(css = "[data-testid='create-job-field-value']")
	WebElement enterJobFieldType;

	@FindBy(xpath = "//span[.='Create']")
	WebElement create;

	@FindBy(xpath = "//span[.='Delete']")
	private WebElement delete;	

	@FindBy(css = "[data-testid='edit-job-field-value']")
	WebElement jobField;
	
	@FindBy(xpath = "//span[.='Save']")
	private WebElement save;

	@FindBy(xpath = "//span[.='Cancel']")
	private WebElement cancel;

	@FindBy(css = "[data-testid='create-job-field-value']")
	private WebElement typeInput;


	public JobFieldsPage(WebDriver driver) {
		super(driver);
	}

	public void clickAddJobType() {
		element.click(addJobType);
	}

	public void clickAddBusinessUnit() {
		element.click(addBusinessUnit);
	}
	
	public void enterJobFieldType(String jobField) {
		element.type(enterJobFieldType, jobField);
	}

	public void clickCreate() {
		element.click(create);
		waitForPageLoaded();
	}

	public void clickDelete() {
		element.click(delete);
		waitForPageLoaded();
	}

	public void confirmDelete() {
		element.click(delete);
		waitForPageLoaded();
	}

	public void clickSave() {
		element.click(save);
	}

	public void clickCancel() {
		element.click(cancel);
		waitForPageLoaded();
	}

	public void clickJobType(String jobType) {
		element.click(xpath("//div[.='"+jobType+"']"));
		waitForPageLoaded();
	}

	public void clickBusinessUnit(String jobType) {
		element.click(xpath("//div[.='"+jobType+"']"));
		waitForPageLoaded();
	}
	public void editJobField(String jobFieldUpdated) { element.type(jobField, jobFieldUpdated); }

	public boolean isErrorMessageDisplayedForDuplicateJobType() {
		return element.isDisplayed(xpath("//p[contains(.,'Job types name has already been taken')]"));
	}
	
	public boolean isErrorMessageDisplayedForDuplicateBusinessUnit() {
		return element.isDisplayed(xpath("//p[contains(.,'Business units name has already been taken')]"));
	}

	public void enterFieldType(String jobFields) {
		element.click(typeInput);
		element.type(typeInput, jobFields);
		waitForPageToLoad(2);
	}

}
