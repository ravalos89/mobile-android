package com.hcp.qa.pages.pricebook;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class CategoryListPage extends Page {

	@FindBy(xpath = "//span[contains(.,'Start from scratch')]/preceding-sibling::span")
	WebElement startFromScratch;

	@FindBy(xpath = "//span[contains(.,'Next')]")
	WebElement nextBtn;

	@FindBy(xpath = "//button[contains(.,'add category')]")
	WebElement addCategoryBtn;

	public CategoryListPage(WebDriver driver) {
		super(driver);
	}

	public void selectStartFromScratch() {
		if (!startFromScratch.isSelected())
			startFromScratch.click();
	}

	public void clickNext() {
		nextBtn.click();
	}

	public void clickAddCategory() {
		waitHelper.waitForElementToBeClickable(addCategoryBtn);
		addCategoryBtn.click();
	}

	public void clickDelete(String categoryName) {
		waitForPageToLoad(2);
		PageUtils.scrollToBottom(driver);
		waitForPageToLoad(5);
		PageUtils.clickUsingJS(driver, driver.findElement(By.xpath("//p[contains(.,'" + categoryName + "')]/following-sibling::button")));
		PageUtils.clickUsingJS(driver, driver.findElement(By.xpath("//li[contains(.,'Delete')]")));
		waitForPageToLoad(5);
		PageUtils.scrollToTop(driver);
	}

	public void clickEdit(String categoryName) {
		PageUtils.scrollToBottom(driver);
		driver.findElement(By.xpath("//p[contains(.,'" + categoryName + "')]/"
				+ "following-sibling::button")).click();
		driver.findElement(By.xpath("//li[contains(.,'Edit')]")).click();
		PageUtils.scrollToTop(driver);
	}

	public void clickReorder(String categoryName) {
		PageUtils.scrollToBottom(driver);
		driver.findElement(By.xpath("//p[contains(.,'" + categoryName + "')]/following-sibling::button")).click();
		driver.findElement(By.xpath("//li[contains(.,'Reorder')]")).click();
		PageUtils.scrollToTop(driver);
	}

	public void reorderCategories(String fromCategoryName, String toCategoryName) {
		WebElement from = driver.findElement(
				By.xpath("//div[contains(@class,'MuiPaper-rounded') and contains(.,'" + fromCategoryName + "')]"));
		WebElement to = driver.findElement(
				By.xpath("//div[contains(@class,'MuiPaper-rounded') and contains(.,'" + toCategoryName + "')]"));

		Actions builder = new Actions(driver);
		builder.dragAndDrop(from, to);
	}

	public void clickSaveOrderButton() {
		driver.findElement(By.xpath("//span[contains(.,'Save Order')]")).click();
	}

	public boolean isReorderMessageDisplayed() {
		By by = By.xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'successfully reordered')]");
		return element.isDisplayed(by);
	}

	public void waitForSuccessMessage() {
		waitHelper.waitForElementToBeVisible(By.xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'successfully moved!')]"));
	}
	
	public List<WebElement> getAllCategoriesNames() {
		return driver.findElements(
					By.xpath("//p[contains(@class,'MuiTypography-body1')]"));
	}

	public void clickServiceItem(String serviceItem) {
		driver.findElement(By.xpath("//p[.='"+serviceItem+"']")).click();
	}

	public void clickViewDetails(String serviceItem) {
		driver.findElement(By.xpath("//p[.='"+serviceItem+"']/..//button[.='view details']")).click();
	}
	
	public void clickCategoryCard(String categoryName) {
		WebElement e = driver.findElement(
				By.xpath("//span[contains(text(),'" + categoryName + "')]/../../preceding-sibling::button"));
		PageUtils.clickUsingJS(driver, e);
	}

}
