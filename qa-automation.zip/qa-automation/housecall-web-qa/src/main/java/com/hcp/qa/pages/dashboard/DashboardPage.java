package com.hcp.qa.pages.dashboard;

import com.hcp.qa.pages.common.PagewithNavigation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.assertj.core.api.Assertions.assertThat;

public class DashboardPage extends PagewithNavigation {

	private UpcomingJobsWidget upcomingJobs;
	private OpenEstimatesWidget openEstimates;

	@FindBy(xpath = "//div[@role='alert']/div")
	private WebElement alert;

	public DashboardPage(WebDriver driver) {
		super(driver);
		upcomingJobs = new UpcomingJobsWidget(driver);
		openEstimates = new OpenEstimatesWidget(driver);
	}

	public UpcomingJobsWidget getUpcomingJobsWidget() {
		return upcomingJobs;
	}

	public OpenEstimatesWidget getOpenEstimatesWidget() {
		return openEstimates;
	}

	public void isAlertAtTheBottomDisplayed(String expectedDescription) {
		String actualDescription = element.getText(alert);
		assertThat(actualDescription).isEqualTo(expectedDescription);
	}

}
