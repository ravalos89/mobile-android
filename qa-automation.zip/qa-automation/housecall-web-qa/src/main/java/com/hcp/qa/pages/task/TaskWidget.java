package com.hcp.qa.pages.task;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.helpers.StringHelper;
import com.hcp.qa.pages.common.Page;

import static java.lang.String.format;

public class TaskWidget extends Page {

    public TaskWidget(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//input[@id = 'title']")
    private WebElement title;

    @FindBy(xpath = "//div/textarea[@id='description']")
    private WebElement description;

    @FindBy(xpath = "//p[contains(.,'Add date')]")
    private WebElement addDate;

    @FindBy(xpath = "//p[contains(.,'Add employee')]")
    private WebElement addEmployee;

    @FindBy(xpath = "//div//input[@placeholder='Add customer']")
    private WebElement addCustomer;

    @FindBy(xpath = "(//*[@id='title-label']/../../../preceding-sibling::*//button)[3]")
    private WebElement closeIcon;

    @FindBy(xpath = "(//*[@id='title-label']/../../../preceding-sibling::*//button)[2]")
    private WebElement deleteTaskButton;

    @FindBy(xpath = "//p[text()='Saved']")
    private WebElement savedLabel;
    
    @FindBy(xpath = "(//div[contains(@class,'MuiDrawer-paper')]//button[contains(@class,'MuiIconButton-root')])[4]")
    private WebElement closeIconOnEditTask;


    public void addTitle(String taskTitle){
        title.sendKeys(taskTitle);
    }

    public void addDescription(String taskDescription){
        description.click();
        description.sendKeys(taskDescription);
    }

    public void addDateToTask(){
        addDate.click();
    }

    public void addEmployeeToTask(String employeeName){
        addEmployee.click();
        waitForPageToLoad(1);
        String employeeNameTemplate = "//h6[contains(.,'%s')]";
        element.click(By.xpath(format(employeeNameTemplate, StringHelper.capitalizeEachWord(employeeName))));
    }

    public void addCustomerToTask(String customerName){
        element.click(addCustomer);
        element.type(addCustomer, customerName);
        waitHelper.waitForElementToBeNotVisible(By.xpath("//input[@placeholder='Add customer']/following-sibling::div"));
        element.click(addCustomer);
        By by = By.xpath("//h6[contains(.,'" + customerName + "')]");
        element.click(by);
    }

    public void clickCloseIcon(){
        element.click(closeIcon);
    }
    
    public void clickCloseOnEditTask(){
        element.click(closeIconOnEditTask);
    }

    public void clickDeleteTaskIcon(){
        element.click(deleteTaskButton);
    }

    public void waitForSavedLabel() {
        waitHelper.waitForElementToBeVisible(savedLabel, LONG_WAIT_TIME_IN_SECS);
    }
}
