package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeadConversionByDayPage extends CustomLeadConversionByWeekPage {

	@FindBy(xpath = "//div[contains(text(),'Week to date')]")
	private WebElement weekToDateBtn;

	@FindBy(xpath = "//div[contains(text(),'Created date')]")
	private WebElement createdDateBtn;

	public LeadConversionByDayPage(WebDriver driver) {
		super(driver);
	}

	public void clickDateRange() {
		element.click(weekToDateBtn);
	}

	public void clickActionDate() {
		element.click(createdDateBtn);
	}

}
