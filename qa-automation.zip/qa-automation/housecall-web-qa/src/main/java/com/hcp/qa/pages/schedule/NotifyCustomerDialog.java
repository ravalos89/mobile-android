package com.hcp.qa.pages.schedule;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NotifyCustomerDialog extends Page {

    public NotifyCustomerDialog(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//button//span[text()=\"DON'T NOTIFY CUSTOMER\"]")
    private WebElement dontNotifyCustomerButton;

    @FindBy(xpath = "//button//span[text()='NOTIFY CUSTOMER']")
    private WebElement notifyCustomerButton;

    public void clickDontNotifyCustomer() {
        element.click(dontNotifyCustomerButton);
    }

    public void clickNotifyCustomer() {
        element.click(notifyCustomerButton);
    }

}
