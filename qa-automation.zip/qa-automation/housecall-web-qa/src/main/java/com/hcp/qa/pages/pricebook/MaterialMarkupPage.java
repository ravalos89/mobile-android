package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class MaterialMarkupPage extends Page {
	
	@FindBy(xpath = "//button[.='Edit']")
	private WebElement editMaterialMarkups;
	
	@FindBy(xpath = "//button[.='Markup']")
	private WebElement addMarkup;
		
	@FindBy(xpath = "(//input[contains(@name,'materialMarkups') and contains(@name,'markup_percentage')])[last()]")
	private WebElement markupPercentInput;
	
	@FindBy(xpath = "(//input[contains(@name,'materialMarkups') and contains(@name,'profit_percentage')])[last()]")
	private WebElement profitPercentInput;
	
	@FindBy(xpath = "//button[.='Save']")
	private WebElement saveBtn;

	@FindBy(xpath = "(//span[@class='MuiIconButton-label'])[last()]/..")
	private WebElement threeDots;

	@FindBy(xpath = "//li[text()='Merge above']")
	private WebElement mergeBtn;

	@FindBy(xpath = "//tbody/tr[last()]/td[4]/div/span")
	private WebElement addedMarkupPercent;

	@FindBy(xpath = "//tbody/tr[last()]/td[5]/div")
	private WebElement addedProfitPercent;
	
	public MaterialMarkupPage(WebDriver driver) {
		super(driver);
	}
		
	public void clickEditMaterialMarkups()	{
		PageUtils.scrollToTop(driver);
		editMaterialMarkups.click();
	}
	
	public void clickAddMarkups()	{
		addMarkup.click();
		waitForPageToLoad(2);
	}

	public void addNewMaterialMarkup(String markUpPercent, String profitPercent) {		
		markupPercentInput.clear();
		markupPercentInput.sendKeys(markUpPercent);
		profitPercentInput.clear();
		profitPercentInput.sendKeys(profitPercent);
	}


	public void mergeMaterialMarkup() {
		threeDots.click();
		mergeBtn.click();
		waitForPageToLoad(2);
	}
	
	public void clickSave()	{
		saveBtn.click();
		waitForPageToLoad(1);
	}

	public boolean isMarkUpAddedMessage() {
		return driver.findElement(By.xpath("//*[text()='Material markups successfully saved, an email will be sent when services and materials using these material markups are updated']")).isDisplayed();
	}


	public boolean validateMarkupPercent(String markupPercent) {
		return addedMarkupPercent.getText().equals(markupPercent+".00%");
	}


	public boolean validateProfitPercent(String profitPercent) {
		return addedProfitPercent.getText().equals(profitPercent+".00%");
	}
	
}
