package com.hcp.qa.helpers;

import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebElement;

public class ElementCoordinatesHelper {

    public static int getCenterXCoordinateOfElement(WebElement element) {
        return getCenterXCoordinateOfElement(element.getRect());
    }

    public static int getCenterXCoordinateOfElement(Rectangle element) {
        return element.getX() + element.getWidth()/2;
    }

    public static int getCenterYCoordinateOfElement(WebElement element) {
        return getCenterYCoordinateOfElement(element.getRect());
    }

    public static int getCenterYCoordinateOfElement(Rectangle element) {
        return element.getY() + element.getHeight()/2;
    }
}
