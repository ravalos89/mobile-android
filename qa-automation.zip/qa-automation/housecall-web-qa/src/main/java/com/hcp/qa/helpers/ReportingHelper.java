package com.hcp.qa.helpers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.hcp.qa.reports.ReportUtils;

public class ReportingHelper {
	ReportUtils reportUtils = new ReportUtils();
	
	public List<String> getOptions(List<WebElement> applicationOptions) {
		List<String> options = new ArrayList<>();

		for (WebElement value : applicationOptions) {
			options.add(value.getText());
		}
		options.removeIf(String::isEmpty);
		Collections.sort(options);
		return options;

	}
	
	public void verifyOptions(List<String> actualOptions, List<String> expectedOptions) {
		if (actualOptions.equals(expectedOptions)) {
			reportUtils.reporter("Actual Elements  :", actualOptions.toString());
			reportUtils.reporter("Expected Elements  :", expectedOptions.toString());
		} else {

			reportUtils.fail("Expecting " + expectedOptions.toString() + "but found " + actualOptions.toString());
		}
}	
	
	
	public List<String> getExpectedDateRangeOptionsLeads(){
		List<String> expectedOptions = new ArrayList<>();
		expectedOptions.add("Custom range");
		expectedOptions.add("Date range");
		expectedOptions.add("Last month");
		expectedOptions.add("Last week");
		expectedOptions.add("Month to date");
		expectedOptions.add("Quarter to date");
		expectedOptions.add("Today");
		expectedOptions.add("Week to date");
		expectedOptions.add("Year to date");
		Collections.sort(expectedOptions);
		return expectedOptions;
	}
	
	public List<String> getExpectedActionDateOptionsLeads(){
		List<String> expectedOptions = new ArrayList<>();
		expectedOptions.add("Action date");
		expectedOptions.add("Created date");
		Collections.sort(expectedOptions);
		return expectedOptions;
	}
	
	public List<String> getExpectedEmployeeOptionsLeads() {
		List<String> options = new ArrayList<>();
		options.add("Lead conversion by employee");
		options.add("Open leads by employee");
		Collections.sort(options);
		return options;
	}
	
	public List<String> getExpectedDateOptionsLeads() {
		List<String> options = new ArrayList<>();
		options.add("Lead conversion by day");
		options.add("Lead conversion by week");
		options.add("Lead conversion by month");
		Collections.sort(options);
		return options;
	}
	
	public List<String> getExpectedDateRangeOptionsJobs(){
		List<String> expectedOptions = new ArrayList<>();
		expectedOptions.add("Today");
		expectedOptions.add("Week to date");
		expectedOptions.add("Month to date");
		expectedOptions.add("Year to date");
		expectedOptions.add("Quarter to date");
		expectedOptions.add("Last week");
		expectedOptions.add("Last month");
		expectedOptions.add("Date range");
		expectedOptions.add("Custom range");
		Collections.sort(expectedOptions);
		return expectedOptions;
	}
		
	public List<String> getExpectedActionDateOptionsJobs(){
		List<String> expectedOptions = new ArrayList<>();
		expectedOptions.add("Action date");
		expectedOptions.add("Created date");
		expectedOptions.add("Scheduled date");
		expectedOptions.add("Completed date");
		Collections.sort(expectedOptions);
		return expectedOptions;
	}
	
	
	public List<String> getExpectedDateOptionsJobs() {
		List<String> options = new ArrayList<>();
		options.add("Revenue earned");
		options.add("Average job size");
		options.add("Job count");
		options.add("Daily");
		options.add("Weekly");
		options.add("Monthly");
		Collections.sort(options);
		return options;
	}

	public List<String> getExpectedTypeOptionsJobs() {
		List<String> options = new ArrayList<>();
		options.add("Job tags");
		options.add("Job lead source");
		options.add("Business unit");
		options.add("Job type");
		Collections.sort(options);
		return options;
	}

	public List<String> getExpectedEmployeeOptionsJobs() {
		List<String> options = new ArrayList<>();
		options.add("Tech leaderboard");
		Collections.sort(options);
		return options;
	}

	public List<String> getExpectedCustomerOptionsJobs() {
		List<String> options = new ArrayList<>();
		options.add("Customer lead source");
		options.add("Customer name");
		options.add("Rating and reviews");
		Collections.sort(options);
		return options;
	}

	public List<String> getExpectedTimeTrackingOptionsJobs() {
		List<String> options = new ArrayList<>();
		options.add("Job time tracking by employee");
		options.add("Overall job time tracking");
		Collections.sort(options);
		return options;
	}
	
	public String generateTimeStamp() {
		Date date = new Date();
		DateFormat hourDateFormat = new SimpleDateFormat("HHmmssddMMyyyy");
		String timeStamp = hourDateFormat.format(date);
		return timeStamp;
	}
	
}
