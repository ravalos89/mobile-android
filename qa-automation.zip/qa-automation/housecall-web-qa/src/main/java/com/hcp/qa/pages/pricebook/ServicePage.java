package com.hcp.qa.pages.pricebook;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ServicePage extends Page {

	@FindBy(name = "name")
	private WebElement serviceName;

	@FindBy(name = "description")
	private WebElement description;

	@FindBy(name = "cost")
	private WebElement cost;

	@FindBy(name = "price")
	private WebElement price;

	@FindBy(name = "unit_of_measure")
	private WebElement unit;
	
	@FindBy(xpath = "//button[.='Labor rate item']")
	private WebElement addLaborRate;

	@FindBy(xpath = "//button[.='Materials item']")
	private WebElement addMaterialItem;

	@FindBy(xpath = "//p[contains(text(),'Add materials to this service')]/following-sibling::button")
	private WebElement addMaterialsBtn;

	@FindBy(name = "service_materials[0].material.name")
	private WebElement materialItem;

	@FindBy(name = "service_materials[0].quantity")
	private WebElement serviceMaterialQty;

	@FindBy(xpath = "//span[contains(text(),'Save')]")
	private WebElement saveBtn;
	
	@FindBy(xpath="//span[contains(.,'add item')]")
	private WebElement addItemBtn;
	
	@FindBy(xpath="//button[@data-testid='visual-price-book-close-button']")
	private WebElement closePriceBookBtn;
	
	@FindBy(xpath="//span[contains(.,'Add Image')]")
	private WebElement addImageBtn;
	
	@FindBy(xpath="//span[contains(.,'Upload Image')]")
	private WebElement uploadImageBtn;

	@FindBy(xpath="//span[.='Calculate flat rate price']/parent::label//input")
	private WebElement flatRateToggle;

	@FindBy(xpath="//span[contains(.,'Change to pro-managed')]")
	private WebElement changeToProManageBtn;

	@FindBy(xpath="//span[contains(.,'Profit Rhino')]")
	private WebElement profitRhinoCategory;
	
	@FindBy(xpath = "(//span[contains(text(),'Cancel')])[2]")
	private WebElement cancelPopupBtn;

	@FindBy(id = "mui-component-select-Category/Subcategory")
	private WebElement locationDD;

	@FindBys(@FindBy(xpath = "//div[@id='menu-Category/Subcategory']//ul/li"))
	private List<WebElement> locationCategories;

	@FindBy(xpath = "(//input[contains(@name,'.labor_rate.name')])[last()]")
	private WebElement laborRateInput;
	
	@FindBy(xpath = "//p[.='Add labor rates to this service']/../button")
	private WebElement addLaborRateBtn;

	@FindBy(xpath = "//table/tbody/tr[3]/td[2]//span")
	private WebElement serviceCost;
	
	@FindBy(xpath = "//table/tbody/tr[3]/td[3]//span")
	private WebElement servicePrice;
	
	@FindBy(xpath = "//label[contains(.,'Service price')]/following-sibling::div/input")
	private WebElement flatRateServicePrice;

	@FindBy(xpath = "//div[@class=\"MuiGrid-root MuiGrid-container MuiGrid-item\"]/div[1]/p[2]")
	private WebElement markUpPercent;

	@FindBy(name = "task_number")
	private WebElement taskCode;
	
	@FindBy(xpath = "//label[.='Item cost']/parent::div//input")
	private WebElement itemCostOnService;
	
	@FindBy(xpath = "//label[.='Item price']/parent::div//input")
	private WebElement itemPriceOnService;
	
	@FindBy(xpath = "//button[.='Create']")
	private WebElement create;
	
	@FindBy(xpath = "(//input[contains(@name,'.material.name')])[last()]")
	private WebElement newMaterialItem;
	
	@FindBy(xpath = "//button[.='CREATE']")
	private WebElement createMaterial;
	
	@FindBy(xpath = "//label[.='Hourly cost']/parent::div//input")
	private WebElement laborRateHourlyCostOnService;
	
	@FindBy(xpath = "//label[.='Hourly price']/parent::div//input")
	private WebElement laborRateHourlyPriceOnService;
	
	@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-container MuiGrid-item']/div[2]/p[2]")
	private WebElement grossMarginPercent;
	
	@FindBy(xpath = "//p[text()='Labor total']/../../div[2]/p")
	private WebElement laborRateTotalCost;
	
	@FindBy(xpath = "//p[text()='Labor total']/../../div[3]/p")
	private WebElement laborRateTotalPrice;
	
	@FindBy(xpath = "//p[text()='Materials total']/../../div[2]/p")
	private WebElement materialTotalCost;
	
	@FindBy(xpath = "//p[text()='Materials total']/../../div[3]/p")
	private WebElement materialTotalPrice;

	public ServicePage(WebDriver driver) {
		super(driver);
	}

	public void enterServiceName(String name) {
		serviceName.sendKeys(name);
	}

	public void enterDescription(String description) {
		this.description.sendKeys(description);
	}
	
	public void enterPriceInFlatRateService(String price) {
		serviceMaterialQty.clear();
		serviceMaterialQty.sendKeys(price);
	}
	
	public void enterPrice(String price) {
		PageUtils.enterValueInPrefilledField(this.price, price);
	}

	public void addImage(String path) {
		addImageBtn.click();
		AddImageDialog imageDialog = new AddImageDialog(driver);
		imageDialog.addImage(path);
	}

	public void enterUnit(String unit) {
		this.unit.sendKeys(unit);
	}

	public void selectMaterialItem(String profitRhinoMaterialItem) {
		materialItem.clear();
		waitForPageToLoad(1);
		materialItem.sendKeys(profitRhinoMaterialItem);
		driver.findElement(By.xpath("//*[contains(text(),'" + profitRhinoMaterialItem + "')]")).click();
	}

	public void setMaterialQty(String qty) {
		serviceMaterialQty.clear();
		serviceMaterialQty.sendKeys(qty);
	}

	public void clickAddMaterials() {
		PageUtils.scrollIntoView(driver, addMaterialsBtn);
		waitForPageToLoad(1);
		addMaterialsBtn.click();
	}

	public void clickSave() {
		saveBtn.click();
		waitForPageToLoad(2);
		CategoryPage category=new CategoryPage(driver);
		if(!category.isAddService()) {
			saveBtn.click();
		}
	}

	public void clickAddItem() {
		PageUtils.clickUsingJS(driver, addItemBtn);
	}
	
	public void clickAddItem(String itemName) {
		element.click(By.xpath("//table/tbody/tr/td//p[.='"+itemName+"']/ancestor::tr//span[contains(.,'add item')]"));
	}
	
	public void clickClosePricebook() {
		waitForPageToLoad(1);
		PageUtils.clickUsingJS(driver, closePriceBookBtn);
	}

	public void clickFlatPriceToggle(boolean status) {
		PageUtils.toggleButton(flatRateToggle, status);
	}
	
	public boolean isAddLaborRatePresent() {
		return addLaborRate.isDisplayed();
	}

	public boolean isAddMaterialRatePresent() {
		return addMaterialItem.isDisplayed();
	}

	public boolean verifyChangeToProManagedPresent() {
		return changeToProManageBtn.isDisplayed();
	}
	
	public void clickAddMaterialItem() {
		element.click(addMaterialItem);
	}
	
	public void clickAddLaborRate() {
		if(element.isDisplayed(addLaborRateBtn))
			addLaborRateBtn.click();
		else
			addLaborRate.click();
	}

	public void enterLaborRate(String laborRateName) {
		laborRateInput.clear();
		laborRateInput.sendKeys(laborRateName);
		driver.findElement(By.xpath("//*[text()='" + laborRateName + "']")).click();
	}

	public String getServiceCost() {
		return StringUtils.substringBetween(serviceCost.getText(),"$", ".00");
	}

	public String getServicePrice() {
		return StringUtils.substringBetween(servicePrice.getText(),"$", ".00");
	}

	public int getMarkUpPercent() {
		return Integer.parseInt(markUpPercent.getText().replace("%",""));		
	}

	public int calculateMarkUpPercent(String serviceCost, String servicePrice) {
		int actualDiff = Integer.parseInt(servicePrice) - Integer.parseInt(serviceCost);
		int percent = actualDiff*100/Integer.parseInt(serviceCost);
		return percent;
	}

	public void enterTaskCode(String code) {
		taskCode.clear();
		taskCode.sendKeys(code);
	}
	
	public boolean isTaskCodeDisplayed(String TaskCode){
		return driver.findElement(By.xpath("//div/p[contains(.,'"+TaskCode+"')]")).isDisplayed();
	}

	public void clickRemoveLaborRate(String laborRateUpdatedName) {
		driver.findElement(By.xpath("//input[@value='"+laborRateUpdatedName+"']/ancestor::div/button[2]")).click();
		waitForPageToLoad(2);
	}

	public void enterNewLaborRate(String laborRateName) {
		laborRateInput.clear();
		laborRateInput.sendKeys(laborRateName);
		driver.findElement(By.xpath("//*[contains(text(),'" + laborRateName + "')]")).click();
	}
	
	public void addNewLaborRateOnService(String laborRateHourlyCost, String laborRateHourlyPrice) {		
		laborRateHourlyCostOnService.clear();
		laborRateHourlyCostOnService.sendKeys(laborRateHourlyCost);
		laborRateHourlyPriceOnService.clear();
		laborRateHourlyPriceOnService.sendKeys(laborRateHourlyPrice);
		create.click();
	}
	
	public void addNewMaterialItemOnService(String profitRhinoMaterialItem, String itemHourlyCost, String itemHourlyPrice) {
		waitForPageToLoad(1);
		newMaterialItem.sendKeys(profitRhinoMaterialItem);
		driver.findElement(By.xpath("//*[contains(text(),'" + profitRhinoMaterialItem + "')]")).click();
		
		locationDD.click();
		locationCategories.get(0).click();
		itemCostOnService.clear();
		itemCostOnService.sendKeys(itemHourlyCost);
		itemPriceOnService.clear();
		itemPriceOnService.sendKeys(itemHourlyPrice);
		createMaterial.click();
	}

	public int calculateGrossMarginPercent(String serviceCost, String servicePrice) {
		int actualDiff = Integer.parseInt(servicePrice) - Integer.parseInt(serviceCost);
		int percent = actualDiff*100/Integer.parseInt(servicePrice);
		return percent;
	}

	public int getGrossMarginPercent() {
		return Integer.parseInt(StringUtils.substringBetween(grossMarginPercent.getText(), "(",")"));		
	}

	public String getTotalLaborCost() {
		return StringUtils.substringBetween(laborRateTotalCost.getText(),"$", ".00");
	}

	public String getTotalLaborPrice() {
		return StringUtils.substringBetween(laborRateTotalPrice.getText(),"$", ".00");
	}

	public String getTotalMaterialCost() {
		return StringUtils.substringBetween(materialTotalCost.getText(),"$", ".00");
	}

	public String getTotalMaterialPrice() {
		return StringUtils.substringBetween(materialTotalPrice.getText(),"$", ".00");
	}

	public int calculateServiceCost(String totalLaborCost, String totalMaterialCost) {
		return Integer.parseInt(totalLaborCost) + Integer.parseInt(totalMaterialCost);
	}

	public int calculateServicePrice(String totalLaborPrice, String totalMaterialPrice) {
		return Integer.parseInt(totalLaborPrice) + Integer.parseInt(totalMaterialPrice);
	}

}
