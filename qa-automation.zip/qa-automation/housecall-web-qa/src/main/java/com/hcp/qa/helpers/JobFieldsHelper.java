package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.pages.common.PageUtils;
import com.hcp.qa.pages.jobfields.JobFieldsPage;

public class JobFieldsHelper {

	WebDriver driver;
	protected static Logger LOG = LoggerFactory.getLogger(JobFieldsHelper.class);

	public JobFieldsHelper(WebDriver driver) {
		this.driver = driver;
	}

	public void createJobType(String jobType) {
		JobFieldsPage jobFieldsPage = new JobFieldsPage(driver);
		PageUtils.scrollToTop(driver);
		jobFieldsPage.clickAddJobType();
		jobFieldsPage.enterFieldType(jobType);
		jobFieldsPage.clickCreate();
	}
	
	public void createBusinessUnit(String businessUnit) {
		JobFieldsPage jobFieldsPage = new JobFieldsPage(driver);
		jobFieldsPage.clickAddBusinessUnit();
		jobFieldsPage.enterFieldType(businessUnit);
		jobFieldsPage.clickCreate();
	}

	public void deleteJobFields(String jobFields) {
		JobFieldsPage jobFieldsPage = new JobFieldsPage(driver);
		jobFieldsPage.waitForPageToLoad(1);
		PageUtils.scrollToTop(driver);
		jobFieldsPage.clickJobType(jobFields);
		jobFieldsPage.clickDelete();
		jobFieldsPage.confirmDelete();		
	}

	public void editJobFields(String jobFiledsName, String jobFieldsUpdated) {
		JobFieldsPage jobFieldsPage = new JobFieldsPage(driver);
		PageUtils.scrollToTop(driver);
		jobFieldsPage.clickJobType(jobFiledsName);
		jobFieldsPage.editJobField(jobFieldsUpdated);
		jobFieldsPage.clickSave();		
	}

}
