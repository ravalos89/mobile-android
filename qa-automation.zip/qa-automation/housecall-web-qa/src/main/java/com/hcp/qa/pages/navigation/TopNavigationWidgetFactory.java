package com.hcp.qa.pages.navigation;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.navigation.h2o.H2oTopNavigationWidget;

public class TopNavigationWidgetFactory {

	public static TopNavigationWidget createTopNavigationWidget(WebDriver driver) {
		return new H2oTopNavigationWidget(driver);
	}
}
