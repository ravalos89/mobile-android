package com.hcp.qa.helpers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.pages.billing.pages.MyPlanPage;
import com.hcp.qa.pages.event.EditEventPage;

import static java.lang.String.format;
import static java.time.Duration.ofSeconds;

public class NavigationHelper {

	private final WebDriver driver;

	private final WaitHelper waitHelper;

	private final String baseUrl = PropertiesReader.getInstance().getBaseUrl();

	private final String getStartedUrl = baseUrl + "/app/get_started";

	private final String loginUrl = baseUrl + "/pro/log_in";

	private final String customersUrl = baseUrl + "/pro/customers";

	private final String dashboardUrl = baseUrl + "/pro/dashboard";

	private final String estimateUrl = baseUrl + "/pro/estimates/new";

	private final String NEW_JOB_URL = baseUrl + "/pro/jobs/new";

	private final String priceBookUrl = baseUrl + "/app/price_book";

	private final String newCalendarUrl = baseUrl + "/pro/calendar_new";

	private final String oldCalendarUrl = baseUrl + "/pro/calendar";

	private final String marketingEmailNavigationUrl = baseUrl + "/pro/marketing/email";

	private final String marketingPostcardsNavigationUrl = baseUrl + "/pro/marketing/postcards";

	private final String jobPagePartialUrl = baseUrl + "/pro/jobs/job_";
	private final String estimatePage  = baseUrl + "/pro/estimates/";

	private final String accountUrl = baseUrl + "/pro/account";

	private final String billingPageUrl = accountUrl + "/billing";

	private final String salesOnboardingUrl = baseUrl + "/pro/sign_up";

	private final String EMPLOYEES_PAGE_URL = baseUrl + "/pro/account/employees";

	private final String EVENTS_URL = baseUrl + "/pro/events/%s";

	public NavigationHelper(WebDriver driver) {
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
	}

	public void goToLoginPage() {
		driver.get(loginUrl);
	}

	public void goToGetStartedPage() {
		driver.get(getStartedUrl);
	}

	public String getLoginUrl() {
		return loginUrl;
	}

	public void goToDashboardPage() {
		waitHelper.waitForPageLoaded();
		driver.navigate().to(dashboardUrl);
	}

	public void goToCustomersListPage() {
		driver.navigate().to(customersUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToNewEstimatesPage() {
		driver.navigate().to(estimateUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToPriceBookPage() {
		driver.navigate().to(priceBookUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToNewCalendar() {
		driver.navigate().to(newCalendarUrl);
	}

	public void goToOldCalendar() {
		driver.navigate().to(oldCalendarUrl);
		waitHelper.waitForPageLoaded();
		new WebDriverWait(driver, ofSeconds(20)).until(ExpectedConditions.invisibilityOfElementLocated(By.id("modal-spinner")));
	}

	//TODO check if id replacement is needed, or partial Url should be modified to not include "job_"
	public void goToJob(String id) {
		driver.navigate().to(jobPagePartialUrl + id.replace("job_", ""));
	}

	public void goToEstimate(String longId) {
		driver.navigate().to(estimatePage + longId);
	}

	public void goToCustomer(String id) {
		String url = customersUrl + "/" + id;
		driver.navigate().to(url);
	}

	public void goToMarketingEmail() {
		driver.navigate().to(marketingEmailNavigationUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToMarketingPostcards() {
		driver.navigate().to(marketingPostcardsNavigationUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToSettingsPage() {
		driver.navigate().to(accountUrl);
		waitHelper.waitForPageLoaded();
	}

	public MyPlanPage goToBillingPage() {
		driver.navigate().to(billingPageUrl);
		waitHelper.waitForPageLoaded();

		return new MyPlanPage(driver);
	}

	public void goToSalesOnboardingPage() {
		driver.navigate().to(salesOnboardingUrl);
		waitHelper.waitForPageLoaded();
	}

	public void goToEmployeesListPage() {
		driver.navigate().to(EMPLOYEES_PAGE_URL);
		waitHelper.waitForPageLoaded();
	}

	public void goToNewJobPage() {
		driver.navigate().to(NEW_JOB_URL);
		waitHelper.waitForPageLoaded();
	}

	public EditEventPage goToEventPage(int id) {
		driver.navigate().to(format(EVENTS_URL, id));
		waitHelper.waitForPageLoaded();
		return new EditEventPage(driver);
	}

	public void waitForJobPageUrl() {
		waitForUrlToContain(jobPagePartialUrl);
	}

	public void waitForDashboardUrl() {
		waitForUrlToContain(dashboardUrl);
	}

	public void waitForUrlToContain(String urlPart) {
		waitForUrlToContain(urlPart, 10);
	}

	public void waitForUrlToContain(String urlPart, int timeout) {
		int timeElapsed = 0;
		boolean isPartOfUrl;
		while (!(isPartOfUrl = driver.getCurrentUrl().contains(urlPart)) && timeElapsed++ < timeout) {
			Sleep.seconds(1);
		}
		if (!isPartOfUrl) {
			throw new RuntimeException("Url: '" + driver.getCurrentUrl() + "' does not contain part: '" + urlPart + "'");
		}
	}

}
