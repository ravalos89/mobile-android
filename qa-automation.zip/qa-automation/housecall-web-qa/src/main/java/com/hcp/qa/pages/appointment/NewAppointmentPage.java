package com.hcp.qa.pages.appointment;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.schedule.appointment.ScheduleCardWidget;

public abstract class NewAppointmentPage<T> extends Page implements NewAppointment<T>{

	protected ScheduleCardWidget scheduleCard;
	public NewAppointmentPage(WebDriver driver) {
		super(driver);
		scheduleCard = new ScheduleCardWidget(driver);
	}

	public abstract void save();

	public String getStartDate() {
		return scheduleCard.getStartDate();}

	public String getStartTime() {
		return scheduleCard.getStartTime();
	}

	public T typeStartTime(String time) {
		scheduleCard.typeStartTime(time);
		return (T) this;
	}

	public T enterStartTime(String time) {
		scheduleCard.enterStartTime(time);
		return (T) this;
	}

	public String getEndDate() {
		return scheduleCard.getEndDate();
	}

	public String getEndTime() {
		return scheduleCard.getEndTime();
	}

	public boolean isDispatchByDisplayed() {
		return scheduleCard.isDispatchByDisplayed();
	}

	public String getTimeZone() {
		return scheduleCard.getTimeZone();
	}
}
