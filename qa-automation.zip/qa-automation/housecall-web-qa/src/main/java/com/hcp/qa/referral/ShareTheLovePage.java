package com.hcp.qa.referral;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ShareTheLovePage extends Page {

	@FindBy(xpath = "//h5[contains(.,'Refer a friend')]")
	WebElement title;

	@FindBy(xpath = "//h5[contains(.,'Refer a friend')]/preceding-sibling::button")
	WebElement closeBtn;

	public ShareTheLovePage(WebDriver driver) {
		super(driver);
	}

	public boolean isTitleVisible() {
		return title.isDisplayed();
	}

	public void clickClose() {
		closeBtn.click();
	}

}
