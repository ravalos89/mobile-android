package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdminPage extends Page {

    @FindBy(xpath = "//div[.='Admin Panel']/button")
    private WebElement hamburgerMenu;

    @FindBy(xpath = "//span[.='HCP Assist']")
    private WebElement hcpAssist;

    @FindBy(xpath = "//header/div/div[2]//button")
    private WebElement profileIcon;

    @FindBy(xpath = "//li[contains(.,'Logout')]")
    private WebElement logout;

    public AdminPage(WebDriver driver) {
        super(driver);
    }

    public void clickHamburgerMenu() {
        element.click(hamburgerMenu);
    }

    public void clickHCPAssist() {
        element.click(hcpAssist);
    }

    public void clickProfileIcon() {
        element.click(profileIcon);
    }

    public void clickLogout() {
        element.click(logout);
    }
}
