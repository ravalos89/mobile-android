package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.hcp.qa.common.ActivityFeedKey;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.pages.common.CustomerSearchWidget;
import com.hcp.qa.pages.common.ScheduleWidget;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.NewJobPage;

public class JobHelper {
	WebDriver driver;
	NavigationHelper navigationHelper;

	public JobHelper(WebDriver driver) {
		this.driver = driver;
		this.navigationHelper = new NavigationHelper(driver);
	}

	public Job createJob(Customer customer) {
		Job job = ApiHelper.getInstance().createJob(customer);
		navigationHelper.goToJob(job.getId());
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(1);
		return job;
	}
	
	public Job createJob(double unitPrice, String prefix) {
		CustomerHelper customerHelper = new CustomerHelper(driver);
		Customer customer = customerHelper.createCustomer(prefix);
		LineItem lineItem = DataGenerator.getInstance().generateLineItem();
		lineItem.setUnitPrice(unitPrice);
		Job job = ApiHelper.getInstance().createJob(lineItem, customer);
		navigationHelper.goToJob(job.getId());
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(1);
		return job;
	}
	
	public Job createJob(double unitPrice, Customer customer,String apiKey ) {
		LineItem lineItem = DataGenerator.getInstance().generateLineItem();
		lineItem.setUnitPrice(unitPrice);
		ApiHelper apiHelper=new ApiHelper(apiKey);
		Job job = apiHelper.createJob(lineItem, customer);
		navigationHelper.goToJob(job.getId());
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(1);
		return job;
	}

	public void deleteJob() {
		EditJobPage editJob = new EditJobPage(driver);
		editJob.clickJobOptions();
		editJob.clickDeleteFromJobOptions();
		editJob.confirmDelete();
		editJob.waitForDeletedMessageToClear();
	}

	
	
	public void verifyActivityFeed(String latestActivity, ActivityFeedKey activity) {
		Assert.assertTrue(latestActivity.contains(activity.getMessage()), "Check Activity Feed that it contains ' "
				+ activity.getMessage() + "' But found '" + latestActivity + "'");
	}
	
	public void createNewJob(Customer customer) {
		NewJobPage newJob = new NewJobPage(driver);
		CustomerSearchWidget customerWidget = new CustomerSearchWidget(driver);
		customerWidget.searchAndSelectExistingCustomer(customer.getDisplayName());
		newJob.addPrivateNotes("Private notes");
		newJob.addLineItem(DataGenerator.getInstance().generateLineItem());			
	}

	public void assignEmployeeToJob(String employee) {
		ScheduleWidget scheduleWidget = new ScheduleWidget(driver);
		scheduleWidget.assignEmployee(employee);
	}
	
	

}
