package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobOptionsWidget extends Page {

    @FindBy(xpath = "//li[contains(.,'Delete job')]")
    private WebElement deleteJob;

    @FindBy(xpath = "//p[contains(.,'Add segment')]")
    private WebElement addSegment;

    public JobOptionsWidget(WebDriver driver) {
        super(driver);
    }

    public void clickDeleteJob() {
        waitHelper.waitForElementToBeClickable(deleteJob);
        waitForPageLoaded();
        element.click(deleteJob);
    }

    public void clickAddSegment() {
        element.click(addSegment);
    }
}
