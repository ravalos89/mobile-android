package com.hcp.qa.pages.quickbooks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class QBOImportPage extends Page {

	@FindBy(xpath = "//button[contains(.,'Import Data')]")
	private WebElement importDataBtn;

	@FindBy(xpath = "//h5[contains(.,'App details')]/preceding-sibling::button")
	private WebElement backBtn;

	@FindBy(xpath = "//span[contains(.,'Customers in QBO')]/following-sibling::span")
	private WebElement qboCustomers;

	@FindBy(xpath = "//span[contains(.,'Linked Customers in HCP')]/following-sibling::span")
	private WebElement hcpCustomers;

	@FindBy(xpath = "//div[contains(@class,'MuiDialogActions-root')]//span[contains(.,'Import')]")
	private WebElement importBtn;
	
	@FindBy(xpath="//button[contains(.,'Disconnect From QuickBooks')]")
	private WebElement disconnectQuickBooks;
	
	@FindBy(xpath="//button[contains(.,'Connect to QuickBooks')])")
	private WebElement connectToQuickBooks;

	public QBOImportPage(WebDriver driver) {
		super(driver);
	}

	public void clickImportData() {
		importDataBtn.click();
	}

	public void clickBack() {
		backBtn.click();
	}

	public void clickImport() {
		importBtn.click();
	}

	public String getQBOCustomerCount() {
		return qboCustomers.getText();
	}

	public String getHCPCustomerCount() {
		return hcpCustomers.getText();
	}
	
	public void clickDisconnectQuickBooks()
	{
		disconnectQuickBooks.click();
	}
	
	public boolean isConnectToQuickBooksDisplayed()
	{
		waitForPageToLoad(1);
		return connectToQuickBooks.isDisplayed();
	}
	
	
	public boolean isDisconnectFromQuickBooksDisplayed()
	{
		waitForPageToLoad(1);
		return disconnectQuickBooks.isDisplayed();
	}

}
