package com.hcp.qa.pages.quickbooks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class QBOOnboardingPage extends Page{
	
	@FindBy(xpath="//button[contains(.,'Skip')]")
	WebElement skipBtn;
	
	@FindBy(xpath="//button[contains(.,'Import')]")
	WebElement importBtn;
	
	@FindBy(xpath="//button[contains(.,'Finish')]")
	WebElement finishBtn;

	public QBOOnboardingPage(WebDriver driver) {
		super(driver);
	}
	
	public void clickSkip()
	{
		skipBtn.click();
	}
	
	public void clickFinish()
	{
		finishBtn.click();
	}

}
