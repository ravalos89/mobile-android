package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddJobSegmentToInvoice extends Page {

    @FindBy(xpath = "//span[contains(text(),'Segment #1 -')]/..//input")
    private WebElement segment1Checkbox;

    @FindBy(xpath = "//span[contains(text(),'Segment #2 -')]/..//input")
    private WebElement segment2Checkbox;

    @FindBy(xpath = "//div[starts-with(@class,'MuiDialogActions')]//span[contains(text(),'Ok')]")
    private WebElement okButton;


    public AddJobSegmentToInvoice(WebDriver driver) {
        super(driver);
    }

    public void clickOkButton() {
        element.click(okButton);
    }

    public void clickSegment1CheckBox(boolean selectSegment1) {
        if (selectSegment1 == false && segment1Checkbox.isSelected())
            element.click(segment1Checkbox);
        else if (selectSegment1 == true && !segment1Checkbox.isSelected())
            element.click(segment1Checkbox);
    }

    public void clickSegment2CheckBox(boolean selectSegment2) {
        if (selectSegment2 == false && segment2Checkbox.isSelected())
            element.click(segment2Checkbox);
        else if (selectSegment2 == true && !segment2Checkbox.isSelected())
            element.click(segment2Checkbox);
    }
}
