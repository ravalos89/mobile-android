package com.hcp.qa.common;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcp.qa.models.growth.SignUp;
import lombok.Data;

@Data
public class ProDto {

    public ProDto(){}

    public ProDto(SignUp signUp) {
        firstName = signUp.getFirstName();
        email = signUp.getEmail();
        companyName = signUp.getCompanyName();
        password = signUp.getPassword();
        lastName = signUp.getLastName();
    }

    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    private String email;
    private String password;
    @JsonProperty("company_name")
    private String companyName;
    private String orgId;

    public String getDisplayName() { return firstName + " " + lastName; }

}
