package com.hcp.qa.pages.reporting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.common.Page;

public class ReportPage extends Page {

	public ReportPage(WebDriver driver) {
		super(driver);
	}
	
	public boolean isBuildReportVisible() {
		return element.isDisplayed(By.xpath("//button[contains(.,'Create report')]"));
	}
}
