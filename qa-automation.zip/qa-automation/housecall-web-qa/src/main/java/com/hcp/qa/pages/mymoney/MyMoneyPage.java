package com.hcp.qa.pages.mymoney;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class MyMoneyPage extends Page {
	
	@FindBy(xpath="//h5[contains(text(),'Payouts')]")
	WebElement payoutsTitle;

	
	@FindBy(xpath = "//span[contains(text(),'Expense Cards')]")
	private WebElement expenseCards;

	@FindBy(xpath = "//h6[contains(text(),'Available balance')]")
	private WebElement currentBalance;

	@FindBy(xpath = "//span[contains(text(),'Card Reader')]")
	private WebElement cardReader;

	@FindBy(xpath = "//h5[contains(text(),'Card reader')]/preceding-sibling::button")
	private WebElement closeCardReaderBtn;

	@FindBy(xpath = "//span[contains(text(),'Buy Now')]")
	private WebElement buyNowBtn;

	@FindBy(xpath = "//span[contains(text(),'Business Financing')]")
	private WebElement businessFinancing;

	@FindBy(xpath = "//h5[contains(text(),'Business Financing')]")
	private WebElement businessFinancingTitle;
	
	
	@FindBy(xpath="//p[contains(text(),'Housecall Pro has partnered with Fundbox to provide an effortless lending experience to our Pros. Find out how much you qualify for, risk free.')]")
	private WebElement fundboxText;
	
	@FindBy(xpath="//span[contains(text(),'CONNECT MY BANK')]")
	private WebElement connectMyBank;

	public MyMoneyPage(WebDriver driver) {
		super(driver);
	}

	public boolean isMyMoneyTitleVisible() {
		return driver.findElement(By.xpath("//h5[contains(text(),'My Money')]")).isDisplayed();
	}
	
	public boolean isPayoutsPageTitleVisible()
	{
		return payoutsTitle.isDisplayed();
	}
	

	public void clickExpenseCards() {
		expenseCards.click();
	}

	public void clickCardReader() {
		cardReader.click();
	}

	public void closeCardReader() {
		waitHelper.waitForElementToBeClickable(closeCardReaderBtn).click();
	}

	public void clickBusinessFinancing() {
		businessFinancing.click();
	}

	public boolean isBusinessFinancingTitleDisplayed() {
		return businessFinancingTitle.isDisplayed();
	}
	
	public boolean isBusinessFinancingTextDisplayed() {
		return fundboxText.isDisplayed();
	}

	public boolean isBuyNowBtnDisplayed() {
		return buyNowBtn.isDisplayed();
	}

	public boolean isCurrentBalanceDisplayed() {
		return currentBalance.isDisplayed();
	}
	
	public void clickConnectMyBank()
	{
		connectMyBank.click();
	}
}
