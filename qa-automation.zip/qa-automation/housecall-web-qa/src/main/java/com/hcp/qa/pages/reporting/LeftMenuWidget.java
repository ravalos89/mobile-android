package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class LeftMenuWidget extends Page{

	@FindBy(xpath="//button//span[contains(text(),'Jobs')]")
	WebElement jobsBtn;
	
	@FindBy(xpath="//button//span[contains(text(),'Leads')]")
	WebElement leadsBtn;
	
	@FindBy(xpath="//button//span[contains(text(),'Custom')]")
	WebElement customBtn;
	
	
	public LeftMenuWidget(WebDriver driver) {
		super(driver);
	}

	public void clickJobs() {
		element.click(jobsBtn);
	}
	
	public void clickLeads() {
		element.click(leadsBtn);
	}
	
	public void clickCustom() {
		customBtn.click();
	}
}
