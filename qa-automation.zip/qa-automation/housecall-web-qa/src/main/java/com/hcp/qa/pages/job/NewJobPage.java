package com.hcp.qa.pages.job;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.models.LineItem;
import com.hcp.qa.pages.appointment.NewAppointmentPage;
import com.hcp.qa.pages.common.LineItemsWidget;
import com.hcp.qa.pages.common.PageUtils;
import com.hcp.qa.pages.schedule.appointment.ScheduleCardWidget;

import static com.hcp.qa.helpers.Colors.BUTTON_BLUE;
import static org.openqa.selenium.By.xpath;

public class NewJobPage extends NewAppointmentPage<NewJobPage> {

    @FindBy(xpath = "//p[contains(.,'Private notes')]")
    private WebElement privateNotes;


    @FindBy(xpath = "//h5[contains(.,'New job')]/preceding-sibling::button")
    private WebElement closeButton;

    @FindBy(xpath = "//input[@type = 'checkbox']")
    private WebElement proModeOn;

    @FindBy(xpath = "//div[@class='MuiCardHeader-content']//h6[span[text()='Customer']]")
    private WebElement customerCardWidgetHeader;

    private final By saveJobButtonLocator = xpath("//button[span[text()='Save job']]");

    public NewJobPage(WebDriver driver) {
        super(driver);
        scheduleCard = new ScheduleCardWidget(driver);
    }

    public void addPrivateNotes(String notes) {
        element.click(privateNotes);
        element.type(xpath("//textarea"), notes);
    }

    public void addLineItem(LineItem lineItem) {
        LineItemsWidget lineItemWidget = new LineItemsWidget(driver);
        lineItemWidget.addLineItem(lineItem);
    }

    public void save() {
        waitForSaveButtonEnabled();
        element.click(saveJobButtonLocator);
    }

    public void waitForSaveButtonEnabled() {
        waitHelper.waitForBackgroundColor(saveJobButtonLocator, BUTTON_BLUE);
    }

    public boolean isNewJobTitleVisible() {
        return element.isDisplayed(xpath("//h5[contains(.,'New job')]"));
    }

    public void waitForCustomerCardToLoad() {
        waitHelper.waitForElementToBeVisible(customerCardWidgetHeader);
    }

    public void clickClose() {
        element.click(closeButton);
    }

    public void clickProModeOn() {
        element.click(proModeOn);
    }

    public NewJobPage turnProModeOn() {
        PageUtils.toggleButton(proModeOn, true);
        return this;
    }
}