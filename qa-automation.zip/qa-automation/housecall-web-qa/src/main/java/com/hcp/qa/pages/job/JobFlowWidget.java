package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobFlowWidget extends Page {

    @FindBy(xpath = "//p[contains(.,'Schedule')]")
    private WebElement scheduleIcon;

    @FindBy(xpath = "//p[contains(.,'OMW')]")
    private WebElement omwIcon;

    @FindBy(xpath = "//p[contains(.,'Start')]")
    private WebElement startIcon;

    @FindBy(xpath = "//p[contains(.,'Finish')]")
    private WebElement finishIcon;

    @FindBy(xpath = "//p[contains(.,'Invoice')]")
    private WebElement invoiceIcon;

    @FindBy(xpath = "//p[contains(.,'Pay')]")
    private WebElement payIcon;

    @FindBy(xpath = "//div[@data-intercom-target and descendant::p[text()='Schedule']]/following-sibling::div/div[1]")
    private WebElement scheduleDate;

    @FindBy(xpath = "//div[@data-intercom-target and descendant::p[text()='Schedule']]/following-sibling::div/div[2]")
    private WebElement scheduleTime;

    @FindBy(xpath = "//div[@data-intercom-target and descendant::p[text()='Schedule']]/following-sibling::div/div[3]")
    private WebElement scheduleTimezone;

    @FindBy(xpath = "//div[@data-appcues-id='schedule_modal_edit_step']")
    private WebElement scheduleText;

    public JobFlowWidget(WebDriver driver) {
        super(driver);
    }

    public void clickSchedule() {
        element.click(scheduleIcon);
        waitForPageToLoad(2);
    }

    public void clickOmw() {
        element.click(omwIcon);
    }

    public void clickStart() {
        element.click(startIcon);
    }

    public void clickFinish() {
        element.click(finishIcon);
    }

    public void clickInvoice() {
        element.click(invoiceIcon);
    }

    public void clickPay() {
        element.click(payIcon);
    }

    public String getScheduleDate() {
        return element.getText(scheduleDate);
    }

    public String getScheduleTime() {
        return element.getText(scheduleTime);
    }

    public String getEndTime() {
        return getScheduleTime().split("-")[1];
    }

    public String getStartTime() {
        return getScheduleTime().split("-")[0];
    }

    public String getScheduleText() {
        return element.getText(scheduleText);
    }

    public String getScheduleTimezone() {
        return element.getText(scheduleTimezone);
    }

	public JobFlowWidget waitForPayIcon() {
		waitHelper.waitForElementToBeVisible(payIcon, LONG_WAIT_TIME_IN_SECS);
		return this;
	}

}
