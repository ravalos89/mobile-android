package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class LaborRatePage extends Page {
	
	@FindBy(xpath = "//button[.='Edit']")
	private WebElement editLaborRate;
	
	@FindBy(xpath = "//button[.='Labor Rate']")
	private WebElement addLaborRate;
	
	@FindBy(xpath = "(//input[contains(@name,'laborRates') and contains(@name,'name')])[last()]")
	private WebElement laborRateNameInput;
	
	@FindBy(xpath = "(//input[contains(@name,'laborRates') and contains(@name,'hourly_cost')])[last()]")
	private WebElement laborRateHourlyCostInput;
	
	@FindBy(xpath = "(//input[contains(@name,'laborRates') and contains(@name,'hourly_price')])[last()]")
	private WebElement laborRateHourlyPriceInput;
	
	@FindBy(xpath = "//button[.='Save']")
	private WebElement saveBtn;
	
	@FindBy(xpath = "//tbody/tr[last()]/td[2]/div")
	private WebElement addedLaborRateHourlyCostInput;
	
	@FindBy(xpath = "//tbody/tr[last()]/td[3]/div")
	private WebElement addedLaborRateHourlyPriceInput;

	@FindBy(xpath = "//button[.='Create']")
	private WebElement create;
	
	public LaborRatePage(WebDriver driver) {
		super(driver);
	}
		
	public void clickEditLaborRates()	{
		waitForPageToLoad(2);
		PageUtils.scrollToTop(driver);
		editLaborRate.click();
		PageUtils.scrollToBottom(driver);
		waitForPageToLoad(2);
	}
	
	public void clickAddLaborRate() {
		addLaborRate.click();	
	}

	public void addNewLaborRate(String laborRateName, String laborRateHourlyCost, String laborRateHourlyPrice) {		
		laborRateNameInput.sendKeys(laborRateName);
		laborRateHourlyCostInput.clear();
		laborRateHourlyCostInput.sendKeys(laborRateHourlyCost);
		laborRateHourlyPriceInput.clear();
		laborRateHourlyPriceInput.sendKeys(laborRateHourlyPrice);
	}

	public void editNewLaborRate(String laborRateUpdatedName, String laborRateUpdatedHourlyCost, String laborRateUpdatedHourlyPrice) {		
		laborRateNameInput.clear();
		laborRateNameInput.sendKeys(laborRateUpdatedName);
		laborRateHourlyCostInput.clear();
		laborRateHourlyCostInput.sendKeys(laborRateUpdatedHourlyCost);
		laborRateHourlyPriceInput.clear();
		laborRateHourlyPriceInput.sendKeys(laborRateUpdatedHourlyPrice);
	}
	
	public void removeLaborRate(String laborRateUpdatedName) {
		driver.findElement(By.xpath("//input[@value='"+laborRateUpdatedName+"']/ancestor::div/div[5]/button")).click();
		waitForPageToLoad(2);
	}
	
	public void clickSave()	{
		saveBtn.click();
		waitForPageToLoad(1);
	}

	public boolean isLaborRateDisplayed(String laborRateName) {
		return	element.isDisplayed(By.xpath("//div[text()='"+laborRateName+"']"));
	}

	public boolean validateLaborRateCost(String laborRateUpdatedHourlyCost) {
		return addedLaborRateHourlyCostInput.getText().equals("$"+laborRateUpdatedHourlyCost+".00");
	}

	public boolean validateLaborRateHourlyPrice(String laborRateUpdatedHourlyPrice) {
		return addedLaborRateHourlyPriceInput.getText().equals("$"+laborRateUpdatedHourlyPrice+".00");
	}
	
}
