package com.hcp.qa.pages.navigation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class HelpPage extends Page {

	@FindBy(xpath = "//h1[contains(.,'Advice and answers from the Housecall Pro Team')]")
	WebElement helpPageTitle;

	public HelpPage(WebDriver driver) {
		super(driver);
	}

	public boolean isHelpTitleVisible() {

		return helpPageTitle.isDisplayed();
	}

}
