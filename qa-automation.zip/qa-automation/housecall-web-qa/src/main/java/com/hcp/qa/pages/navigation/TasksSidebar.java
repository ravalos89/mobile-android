package com.hcp.qa.pages.navigation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

import static java.lang.String.format;

public class TasksSidebar extends Page {

	@FindBy(xpath = "//h5[contains(.,'All tasks')]")
	WebElement title;

	@FindBy(xpath = "//h5[contains(.,'All tasks')]/../preceding-sibling::div/button")
	WebElement closeBtn;

	@FindBy(xpath = "//h6[contains(.,'New task')]")
	private WebElement newTaskLink;

	@FindBy(xpath = "//div/h6[contains(.,'Completed')]")
	private WebElement completedTaskSectionHeader;

	@FindBy(xpath = "//div[h5[contains(text(), 'All tasks')]]/preceding-sibling::div//button")
	private WebElement closeIcon;

	private final String taskMessageTemplate = "//span[@id='message-id' and text()='%s']";
	private final By taskDeletedMessage = By.xpath(format(taskMessageTemplate, "Task deleted"));
	private final By taskCompleteMessage = By.xpath(format(taskMessageTemplate, "Task complete"));
	private final By taskIncompleteMessage = By.xpath(format(taskMessageTemplate, "Task incomplete"));
	private final String taskTitleTemplate = "//p[text()='%s']";

	public TasksSidebar(WebDriver driver) {
		super(driver);
	}

	public boolean isTitleVisible() {
		return element.isDisplayed(title);
	}

	public void clickClose() {
		element.click(closeBtn);
	}

	public void clickNewTaskLink() {
		element.click(newTaskLink);
	}

	public void clickEditTaskIcon(String taskName) {
		clickTaskActionButton(taskName);
	}

	public void deleteCompletedTask(String taskName) {
		clickTaskActionButton(taskName);
	}

	public boolean isCompletedTasksPresent() {
		return element.isDisplayed(taskCompleteMessage);
	}

	public void clickCompletedTasksSectionHeader() {
		element.click(completedTaskSectionHeader);
	}

	private void clickTaskActionButton(String taskName) {
		WebElement taskTitle =  driver.findElement(By.xpath(format(taskTitleTemplate, taskName)));
		taskTitle.click();
		Actions action = new Actions(driver);
		action.moveToElement(taskTitle);
		String taskActionButtonTemplate = "//p[contains(.,'%s')]//..//following-sibling::div";
		driver.findElement(By.xpath(format(taskActionButtonTemplate, taskName))).click();}


	public void markTaskAsComplete(String taskName) {
		clickOnMarkTaskCheckbox(taskName);
	}

	public void markTaskAsIncomplete(String taskName) {
		clickOnMarkTaskCheckbox(taskName);
	}

	public void clickCloseIcon() {
		element.click(closeIcon);
	}

	public void waitForTaskDeletedMessage(){
		waitHelper.waitForElementToBeVisible(taskDeletedMessage);
	}

	public void waitForTaskIncompleteMessage(){
		waitHelper.waitForElementToBeVisible(taskIncompleteMessage);
	}

	public void waitForTaskDeletedMessageToDisappear() {
		waitHelper.waitForElementToBeNotVisible(taskDeletedMessage);
	}

	public void waitForTaskCompletedMessage() {
		waitHelper.waitForElementToBeVisible(taskCompleteMessage);
	}

	public boolean isTaskVisible(String taskTitle) {
		return element.isDisplayed(By.xpath(format(taskTitleTemplate, taskTitle)));
	}

	public boolean isTaskInCompletedTab(String title) {
		String xpathTemplate = "//h6[text()='Completed']/../../following-sibling::div//p[text()='%s']";
		By by = By.xpath(format(xpathTemplate, title));
		return element.isDisplayed(by);
	}

	private void clickOnMarkTaskCheckbox(String taskName) {
		String markTaskTemplate = "//p[text()='%s']/../..//input";
		By by = By.xpath(format(markTaskTemplate, taskName));
		element.click(by, 5);
	}
}
