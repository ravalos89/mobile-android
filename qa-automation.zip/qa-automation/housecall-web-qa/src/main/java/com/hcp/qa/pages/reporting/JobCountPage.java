package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobCountPage extends ReportChartPage{
	
	@FindBy(xpath="//div[contains(text(),'Last 45 days')]")
	WebElement last45DaysBtn;

	@FindBy(xpath="//div[contains(text(),'Created date')]")
	WebElement createdDateBtn;

	public JobCountPage(WebDriver driver) {super(driver);}
	
	public void clickDateRange() { element.click(last45DaysBtn); }

	public void clickActionDate() { element.click(createdDateBtn); }
	

}
