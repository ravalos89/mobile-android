package com.hcp.qa.common;

public enum ActivityFeedKey {
	// @formatter:off
	ATTACHMENT_ADDED("1 attachment added"), 
	DISPATCHED("Dispatched to "),
	JOB_CREATED_AS_INVOICE("Job created as Invoice #"),
	JOB_SCHEDULED_SMS_SENT("Job scheduled SMS sent to"),
	JOB_SCHEDULED("Job scheduled"),
	ESTIMATE_CREATED("Estimate #"),
	ESTIMATE_LINE_ITEM_UPDATED("Line items updated: total = $"),
	LINEITEM_UPDATED("Line items updated: total = $"),
	ESTIMATE_SCHEDULED("Estimate scheduled"),
	ESTIMATE_APPROVED("marked as approved by"),
	ESTIMATE_DECLINED("marked as declined by"),
	CUSTOMER_RECEIPT_SENT("Customer payment receipt email sent to"),
	PLAID_PAYMENT("Payment of $"),
	REFUNDED_PAYMENT("Refunded payment of $"),
	CREDITCARD_UPDATED("Credit card updated on service plan"),
	CC_PAYMENT_FAILURE("Payment failure by customer");

	// @formatter:on

	private final String msg;

	ActivityFeedKey(String msg) {
		this.msg = msg;
	}

	public String getMessage() {
		return msg;
	}
}
