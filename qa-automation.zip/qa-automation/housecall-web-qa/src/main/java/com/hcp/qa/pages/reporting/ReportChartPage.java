package com.hcp.qa.pages.reporting;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public abstract class ReportChartPage extends Page {

	ReportingHelper reportingHelper = new ReportingHelper();

	@FindBy(xpath="//*[@aria-label='Report Title']")
	WebElement reportTitle;

	@FindBy(xpath="//*[@id='menu-']/div[1]")
	WebElement page;

	@FindBy(xpath="//ul[contains(@class,'MuiMenu-list MuiList-padding')]/li")
	List<WebElement> dateRangeDropDown;

	@FindBy(xpath="//ul[contains(@class,'MuiMenu-list MuiList-paddin')]/li")
	List<WebElement> actionDateDropDown;

	@FindBy(xpath="//button//span[contains(text(),'EXPORT')]/parent::*/parent::*")
	WebElement exportBtn;

	@FindBy(xpath="//button//span[contains(text(),'Manage Filters')]")
	WebElement manageFiltersBtn;

	@FindBy(xpath="//button//span[contains(text(),'Edit columns')]")
	WebElement editColumnBtn;
	
	@FindBy(xpath="//*[contains(text(),'SAVE REPORT')]/parent::*")
	WebElement saveReport;

	public ReportChartPage(WebDriver driver) {
		super(driver);
	}

	public void clickOnPage() {
		element.click(page);
	}
	
	public void clickSaveReport() {
		element.click(saveReport);
	}


	public boolean isExportButtonDisplayed() { return element.isDisplayed(exportBtn); }

	public void clickExportCSV() {
		Sleep.seconds(5);
		isExportButtonDisplayed();
		element.click(exportBtn);
	}

	public boolean isManageFilterDisplayed() { return element.isDisplayed(manageFiltersBtn); }

	public boolean isEditColumnDisplayed() { return element.isDisplayed(editColumnBtn); }

	public String getTitle() {
		return element.getText(reportTitle);
	}

	public List<String> getDateRangeOptions() {
		return reportingHelper.getOptions(dateRangeDropDown);
	}

	public List<String> getActionDateOptions() {
		return reportingHelper.getOptions(actionDateDropDown);
	}

	public void selectDateRangeByVisibleText(String option) {
		PageUtils.selectOption(dateRangeDropDown, option);
	}

	public void selectActionByVisibleText(String option) {
		PageUtils.selectOption(actionDateDropDown, option);	
	}

}
