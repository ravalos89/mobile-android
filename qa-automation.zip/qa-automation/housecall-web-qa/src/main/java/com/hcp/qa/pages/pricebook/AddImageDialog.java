package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class AddImageDialog extends Page {

	public AddImageDialog(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//span[contains(text(),'Add Image')]")
	private WebElement addImageBtn;

	@FindBy(xpath = "//span[contains(text(),'Cancel')]")
	private WebElement cancelBtn;

	@FindBy(xpath = "//span[contains(text(),'Save')]")
	private WebElement saveBtn;

	@FindBy(xpath = "//button[contains(@class,'MuiButton-text')]/span[contains(text(),'Save')]")
	private WebElement imageSaveBtn;

	public void addImage(String path) {
		WebElement fileInputElement = driver.findElement(By.xpath("//div[@class='_react-file-reader-input']/input"));
		PageUtils.provideFileUploadPath(driver, fileInputElement, path);
		imageSaveBtn.click();
		waitForPageToLoad(2);
	}

	public void clickSave() {
		saveBtn.click();
		waitForPageToLoad(2);
	}

}
