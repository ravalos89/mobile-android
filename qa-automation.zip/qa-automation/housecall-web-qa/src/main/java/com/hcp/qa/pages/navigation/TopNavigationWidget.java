package com.hcp.qa.pages.navigation;

public interface TopNavigationWidget {
	
	boolean isDisplayed();
	
    void clickSignOutFromProfile();

    void clickMyApps();

    void clickPriceBook();

    boolean isGetStartedDiplayed();

    void clickEventFromNew();

    void clickAccountSettingsFromProfile();

    void clickReporting();

    void clickJobFromNew();

    void clickTasks();

    void clickSchedule();

    String getProfileText();

    void clickOnProfileIcon();

    void clickEstimateFromNew();

    void clickDash();

    void clickMyMoney();

    void clickActivityFeed();

    void clickReferFromProfile();

    void waitForGetStartedIcon();

    void clickCustomers();

    void clickMap();

    void clickCustomerFromNew();

    void clickHelp();

    void clickInbox();

    void clickProposalFromNew();

    void waitForPageToLoad(int sleepTime);

    boolean isHcpLogoutDisplayed();

    boolean isMyMoneyVisible();

    void clickGetStarted();

	void closeProfileWidget();

	void clickPhone();
}
