package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class HCPClientReviewAndConfirmPlanPage extends Page{
	
	@FindBy(xpath="//input[@name='passwordText']")
	private WebElement passwordForSaveCardOnFile;
	
	@FindBy(xpath="//input[@name='passwordConfirmation']")
	private WebElement confirmPasswordToViewPaln;
	
	@FindBy(xpath = "//span[.='Confirm plan']")
	private WebElement confirmPlan;

	public HCPClientReviewAndConfirmPlanPage(WebDriver driver) {
		super(driver);
	}

	public void enterSaveCardOnFilePassword(String password){
		this.passwordForSaveCardOnFile.click();
		this.passwordForSaveCardOnFile.sendKeys(password);
	}
	
	public void clickConfirmPlan() {
		confirmPlan.click();
	}
	
	public void createAndConfirmPasswordToViewPlan(String saveCardOnFilePassword) {
			this.confirmPasswordToViewPaln.click();
			this.confirmPasswordToViewPaln.sendKeys(saveCardOnFilePassword);
	}

}
