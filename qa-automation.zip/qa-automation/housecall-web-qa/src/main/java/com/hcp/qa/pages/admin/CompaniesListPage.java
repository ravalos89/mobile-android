package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.billing.pages.MyPlanPage;
import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static java.lang.String.format;
import static java.time.Duration.ofSeconds;
import static org.openqa.selenium.By.xpath;

public class CompaniesListPage extends Page {

    @FindBy(xpath = "//h5[contains(.,'Companies')]")
    private WebElement title;

    @FindBy(xpath = "//input[@placeholder='Search']")
    private WebElement searchTextbox;

    @FindBy(xpath = "//table/tbody/tr[1]/td[1]//button")
    private WebElement expandIcon;

    @FindBy(xpath = "(//table)[2]/tbody//td[4]//span")
    private WebElement emailInTable;

    @FindBy(xpath = "(//table)[2]/tbody//td[3]//span")
    private WebElement empNameInTable;

    public CompaniesListPage(WebDriver driver) {
        super(driver);
    }

    public boolean isTitleDisplayed() {
        return element.isDisplayed(title);
    }

    public void searchForCompany(String searchTerm) {
        element.type(searchTextbox, searchTerm + Keys.ENTER);
        waitForPageLoaded();
    }

    public MyPlanPage clickDetailsOnRowWith(String rowText) {
        element.click(xpath(format("//tr[td[.='%s']]//button[.='DETAILS']", rowText)));

        return new MyPlanPage(driver);
    }

    public void waitForLoadingToFinish() {
        new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS))
                .until(ExpectedConditions.invisibilityOfElementLocated(xpath("//div[@role='progressbar']")));
    }

    public void searchForEmployee(String email) {
    	waitForLoadingToFinish();
        element.type(searchTextbox, email );
        searchTextbox.sendKeys(Keys.ENTER);
        waitForLoadingToFinish();
    }

    public String getEmployeeEmail() {
        return element.getText(emailInTable);
    }

    public String getEmployeeName() {
        return element.getText(empNameInTable);
    }

    public void clickExpandIcon() {
        element.click(expandIcon);
    }

    public void clickImpersonateEmployee(String email) {
        element.click(xpath("//tr[contains(.,'" + email + "')]/td[8]//button"));
    }

}
