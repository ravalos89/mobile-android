package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;

public class EmployeesListPage extends Page {

    public EmployeesListPage(WebDriver driver) {
        super(driver);
    }

}
