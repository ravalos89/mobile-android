package com.hcp.qa.pages.job;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static org.openqa.selenium.By.xpath;

public class ServicePlanTileWidget extends Page {

    @FindBy(xpath = "//p[.='Service plan']")
    private WebElement servicePlan;

    @FindBy(xpath = "//div[contains(@class,'MuiFilledInput-input')]")
    private WebElement selectPlanListBox;

    @FindBy(xpath = "//p[contains(text(),'Visit #1')]")
    private WebElement visitOneOption;

    @FindBy(xpath = "//span[.='+ SERVICE PLAN VISIT']")
    private WebElement addServicePlanVisit;

    @FindBy(xpath = "//p[.='Visit #1']")
    private WebElement visit1;

    @FindBy(xpath = "//span[contains(@class,'MuiChip-label')][.='Active']")
    private WebElement servicePlanActive;

    @FindBy(xpath = "//span[.='Save']")
    private WebElement save;

    public ServicePlanTileWidget(WebDriver driver) {
        super(driver);
    }

    public void clickServicePlan() {
        element.click(servicePlan);
    }

    public void clickServicePlanVisit() {
    	waitForPageLoaded();
        element.click(addServicePlanVisit);
    }

    public void selectVisit1() {
        element.click(visit1);
    }

    public boolean isNoVisitsMessagePresent() {
        return searchForText("No visits");
    }

    public void clickSave() {
        element.click(save);
        waitForPageLoaded();
    }

    public void selectPlanName(String planName) {
        element.click(selectPlanListBox);
        element.click(xpath("//p[contains(text(),'" + planName + "')]"));
        visitOneOption.click();
    }

    public void clickActivatedServicePlan(String planName) {
        element.click(xpath("//p[text()='" + planName + "']"));
    }

    public boolean isServicePlanActivated() {
        return element.isDisplayed(servicePlanActive);
    }

    public boolean isServicePlanPresent(String planName) {
        return element.isDisplayed(xpath("//span[text()='" + planName + "']"));
    }

    public boolean isVisitAddedPresent() {
        return element.isDisplayed(driver.findElement(xpath("//p[text()='Visit #1 added to job']")));
    }

    public boolean isVisitDueMessagePresent() {
        return element.isDisplayed(driver.findElement(xpath("//p[contains(text(),'Visit #1 of ') and contains(text(),'due')]")));
    }

    public boolean isTaxRateNoneVisible() {
        return element.isDisplayed(driver.findElement(xpath("//div[@aria-labelledby='select-tax'][.='none']")));
    }

    public boolean isVisitsCompletedMessagePresent() {
        return element.isDisplayed(driver.findElement(xpath("//p[contains(text(),'All') and contains(text(),'visits have been completed')]")));
    }

}
