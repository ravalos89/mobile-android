package com.hcp.qa.common;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.testng.Assert;

public class TabManager {

	WebDriver driver;

	public TabManager(WebDriver driver) {
		this.driver = driver;
	}

	public String switchToNewTab(String url) {
		String mainWindow = driver.getWindowHandle();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.open();");
		Set<String> tabs = driver.getWindowHandles();
		Iterator<String> tabsIterator = tabs.iterator();
		while (tabsIterator.hasNext()) {
			String child_window = tabsIterator.next();
			if (!mainWindow.equals(child_window)) {
				driver.switchTo().window(child_window);
				driver.get(url);
			}
		}
		return driver.getWindowHandle();
	}

	public void switchToNewEmptyTab() { driver.switchTo().newWindow(WindowType.TAB); }

	public void closeTabAndSwitchtoAnother(String tabToClose, String tabToSwitchTo) {
		driver.switchTo().window(tabToClose);
		driver.close();
		driver.switchTo().window(tabToSwitchTo);
	}

	public String switchToNewTabByTitle(String title) {
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			driver.switchTo().window(handle);
			if (driver.getTitle().equals(title)) {
				return handle;
			}
		}
		Assert.fail("Could not find the tab by title  " + title);
		return null;
	}

	public String switchToLatestTab(String mainWindow) {
		Set<String> tabs = driver.getWindowHandles();
		Iterator<String> tabsIterator = tabs.iterator();
		while (tabsIterator.hasNext()) {
			String child_window = tabsIterator.next();
			if (!mainWindow.equals(child_window)) {
				driver.switchTo().window(child_window);
			}
		}
		return driver.getWindowHandle();

	}
}
