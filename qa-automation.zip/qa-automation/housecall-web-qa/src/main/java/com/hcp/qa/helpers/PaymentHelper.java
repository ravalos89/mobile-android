package com.hcp.qa.helpers;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.hcp.qa.common.ActivityFeedKey;
import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.TabManager;
import com.hcp.qa.gmail.GmailMessageClient;
import com.hcp.qa.pages.invoice.InvoiceSettingsPage;
import com.hcp.qa.pages.invoice.PaymentOptionsWidget;
import com.hcp.qa.pages.invoice.SendInvoiceDialog;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.payment.BankInformationPage;
import com.hcp.qa.pages.payment.CreditCardInformationWidget;
import com.hcp.qa.pages.payment.PaymentSelectionPage;
import com.hcp.qa.pages.payment.ReceiptPage;

import static com.hcp.qa.common.ValidCreditCardData.CREDIT_CARD_NUMBER;
import static com.hcp.qa.common.ValidCreditCardData.CVC;
import static com.hcp.qa.common.ValidCreditCardData.EXPIRATION_DATE;
import static com.hcp.qa.common.ValidCreditCardData.POSTAL_CODE;

public class PaymentHelper {

	String saveCardOnFilePassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.gmail.password");

	TabManager tabManager;
	String paymentTab;
	public String mainHcpWindow;
	WebDriver driver;
	
	private final int WAIT_TIME_FOR_EMAIL=20;
	

	public PaymentHelper(WebDriver driver) {
		this.driver=driver;
		tabManager = new TabManager(driver);
		mainHcpWindow = driver.getWindowHandle();
	}

	public void sendInvoice(boolean acceptCreditCard, boolean acceptACH, boolean saveCardOnFile,
			boolean rememberOption) {
		EditJobPage editJob = new EditJobPage(driver);
		editJob.clickSendInvoice();

		InvoiceSettingsPage invoiceSettings = new InvoiceSettingsPage(driver);

		PaymentOptionsWidget paymentOptions = new PaymentOptionsWidget(driver);
		paymentOptions.acceptCreditCard(acceptCreditCard);
		paymentOptions.acceptACH(acceptACH);
		paymentOptions.saveCardOnFile(saveCardOnFile);
		
		invoiceSettings.clickNext();
  
		SendInvoiceDialog sendInvoice=new SendInvoiceDialog(driver);
		sendInvoice.clickSend();
	}

	public void getPaymentLinkFromEmailAndOpenNewTab(String invoiceNumber) {

		String payOnlineLink = getPayOnlineLinkFromEmail(invoiceNumber);
		if(payOnlineLink==null)
		{
		Assert.fail("Payment link is null ");
		}
		paymentTab = tabManager.switchToNewTab(payOnlineLink);
	}

	private String getPayOnlineLinkFromEmail(String invoiceNumber) {
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
		String emailText = gmailClient.searchEmailAndGetMessageBody("invoice " + invoiceNumber, WAIT_TIME_FOR_EMAIL, false);
		String startString = "Due";
		String endString = "\">PAY ONLINE";
		String url = StringUtils.substringBetween(emailText, startString, endString);
		startString = "class=\"pay-online-link\" href=\"";
		return StringUtils.substringAfter(url, startString);
	}
	
	public void payInvoiceAndSaveCardOnFile() {
		makePaymentWithCreditCardAsCustomer(true);
	}

	public void chargeCreditCardForCustomer() {
		CreditCardInformationWidget cardInfo = new CreditCardInformationWidget(driver);
		fillCreditCardDetailsWithPostalCode();
		cardInfo.clickChargeCard();
	}

	public void payInvoiceWithCreditCard() {
		makePaymentWithCreditCardAsCustomer(false);
	}

	private void makePaymentWithCreditCardAsCustomer(boolean saveCardOnFile) {		
		CreditCardInformationWidget cardInfo = new CreditCardInformationWidget(driver);
		fillCreditCardDetailsWithZip();
		if (saveCardOnFile) {
			cardInfo.checkSaveCreditCardOnFile();
			cardInfo.enterSaveCardOnFilePassword(saveCardOnFilePassword);
		}	

		cardInfo.clickPayButton();
		cardInfo.waitForPageToLoad(1);
	}

	public void payInvoiceWithACH() {
		BankInformationPage bankInfo = new BankInformationPage(driver);
		try {
			bankInfo.clickConnectBank();
		}catch(NoSuchElementException e){
			PaymentSelectionPage selectPayment=new PaymentSelectionPage(driver);
					selectPayment.selectACH();
					bankInfo.clickConnectBank();
		}
	
		new PlaidHelper(driver).connectChaseCheckingAccount();
		
		bankInfo = new BankInformationPage(driver);
		bankInfo.clickPayBtn();
		
		bankInfo.waitForPaymentProcessingMessageToDisappear();

	}

	public void checkReceiptPageAndCloseTab() {
		ReceiptPage receipt = new ReceiptPage(driver);
		receipt.waitForPaymentMessageToAppear();
		Assert.assertTrue(receipt.getAmountDue().contains("$0.00"));
		tabManager.closeTabAndSwitchtoAnother(paymentTab, mainHcpWindow);
	}

	public String checkReceiptEmail(String invoiceNumber) {
		
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
	
		String emailTxt = gmailClient.searchEmailAndGetMessageBody("Receipt " + invoiceNumber, WAIT_TIME_FOR_EMAIL, true);
		Assert.assertNotNull(emailTxt,"Receipt email not found");
		return emailTxt;
	}

	public void closePaymentTab() {
		tabManager.closeTabAndSwitchtoAnother(paymentTab, mainHcpWindow);
	}

	public void checkReceiptSentInActivityFeed() {
		driver.navigate().refresh();
		EditJobPage editJob = new EditJobPage(driver);
		JobHelper jobHelper=new JobHelper(driver);
		jobHelper.verifyActivityFeed(editJob.getLatestActivity(), ActivityFeedKey.CUSTOMER_RECEIPT_SENT);
	}

	public void checkPaidViaEmail()	{
		EditJobPage editJob = new EditJobPage(driver);
		JobHelper jobHelper=new JobHelper(driver);
		jobHelper.verifyActivityFeed(editJob.getLatestActivity(), ActivityFeedKey.PLAID_PAYMENT);
	}
	private CreditCardInformationWidget enterCCDetails()
	{
		CreditCardInformationWidget cardInfo = new CreditCardInformationWidget(driver);
		cardInfo.enterCardNumber(CREDIT_CARD_NUMBER);
		cardInfo.enterExpirationDate(EXPIRATION_DATE);
		cardInfo.enterCvcCode(CVC);
		return cardInfo;
	}
	
	public CreditCardInformationWidget fillCreditCardDetailsWithPostalCode() {
		CreditCardInformationWidget cardInfo = enterCCDetails();
		cardInfo.enterPostalCode(POSTAL_CODE);
		return cardInfo;
	}
	
	public CreditCardInformationWidget fillCreditCardDetailsWithZip() {
		CreditCardInformationWidget cardInfo = enterCCDetails();
		cardInfo.enterZip(POSTAL_CODE);
		return cardInfo;
	}
	
	public CreditCardInformationWidget enterDeclinedCCDetails(String declinedCCNumber) {
		CreditCardInformationWidget cardInfo = new CreditCardInformationWidget(driver);
		cardInfo.enterCardNumber(declinedCCNumber);
		cardInfo.enterExpirationDate(EXPIRATION_DATE);
		cardInfo.enterCvcCode(CVC);
		return cardInfo;
	}
	
	public CreditCardInformationWidget fillDeclinedCreditCardDetailsWithPostalCode(String declinedCCNumber) {
		CreditCardInformationWidget cardInfo = enterDeclinedCCDetails(declinedCCNumber);
		cardInfo.enterPostalCode(POSTAL_CODE);
		return cardInfo;
	}

	
}
