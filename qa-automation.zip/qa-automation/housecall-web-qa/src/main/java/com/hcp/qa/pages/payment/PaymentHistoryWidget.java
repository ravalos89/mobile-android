package com.hcp.qa.pages.payment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class PaymentHistoryWidget extends Page {

	@FindBy(xpath = "//h6/span[contains(.,'Payment history')]")
	private WebElement paymentHistoryTitle;

	@FindBy(xpath = "//span[contains(text(),'Refund')]")
	private WebElement refundBtn;

	public PaymentHistoryWidget(WebDriver driver) {
		super(driver);
	}

	public void scrollToPaymentHistory() {
		PageUtils.scrollIntoView(driver, paymentHistoryTitle);
	}

	public ProcessRefundDialog clickRefund() {
		PageUtils.scrollIntoView(driver, refundBtn);
		element.click(refundBtn);
		return new ProcessRefundDialog(driver);
	}

	public boolean isRefundPendingPresentInPaymentHistory() {
		return element.isDisplayed(By.xpath("//div[contains(text(),'Refund pending')]"));
	}

	public boolean isRefundedPresentInPaymentHistory() {
		return element.isDisplayed(By.xpath("//div[contains(text(),'Refunded)']"));
	}

}
