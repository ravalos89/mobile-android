package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OldAdminPage extends Page {

    @FindBy(xpath = "//h1[contains(.,'Service Pros')]")
    WebElement title;

    public OldAdminPage(WebDriver driver) {
        super(driver);
    }

    public boolean isTitleDisplayed() {
        return element.isDisplayed(title);
    }
}
