package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class SettingsPage extends Page {

	@FindBy(xpath = "//button[contains(.,'Import and export services')]")
	private WebElement importAndExportServices;
	
	@FindBy(xpath = "//button[contains(.,'Tax rates')]")
	private WebElement manageTaxRates;
	
	@FindBy(xpath = "//button[contains(.,'Labor rates')]")
	private WebElement manageLaborRates;
	
	@FindBy(xpath = "//button[contains(.,'Material markups')]")
	private WebElement manageMaterialMarkup;

	@FindBy(xpath = "//button[contains(.,'Import and export materials')]")
	private WebElement importAndExportMaterials;
	
	public SettingsPage(WebDriver driver) {
		super(driver);
	}
	
	public void clickManageTaxRates()
	{
		manageTaxRates.click();
	}
	
	public void clickManageLaborRates()
	{
		manageLaborRates.click();
	}

	public void clickManageMaterialMarkups() {
		waitForPageToLoad(1);
		manageMaterialMarkup.click();
	}

	public void clickImportAndExportServicesPriceBook() {
		importAndExportServices.click();
		waitForPageToLoad(1);
	}
	
	public void clickImportAndExportMaterialsPriceBook() {
		waitForPageToLoad(1);
		importAndExportMaterials.click();
		waitForPageToLoad(1);
	}	

}
