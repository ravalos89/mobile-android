package com.hcp.qa.pages.schedule;

public interface AppointmentTimeReader {

	String getStartTime();
	String getEndTime();
	String getTimeZone();
}
