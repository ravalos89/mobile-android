package com.hcp.qa.pages.quickbooks;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;


public class DisconnectQuickBooksDialog extends Page{

	@FindBy(xpath="//input[@value='connected_wrong_account']")
	private WebElement wrongAccountRadioBtn;
	
	
	@FindBy(xpath="//input[@data-testid='confirm-disconnect-quickbooks-input']")
	private WebElement confirmDisconnect;
	
	@FindBy(xpath=("//span[contains(text(),'Disconnect') and not(contains(text(),'From'))]"))
	private WebElement disconnectBtn;
	
	public DisconnectQuickBooksDialog(WebDriver driver) {
		super(driver);
	}
	
	public void selectDisconnectReason()
	{
		
		wrongAccountRadioBtn.click();
	}
	
	public void confirmDisconnect()
	{
		confirmDisconnect.sendKeys("DISCONNECT QUICKBOOKS");
	}
	
	public void clickDisconnect()
	{
		disconnectBtn.click();
	}

}
