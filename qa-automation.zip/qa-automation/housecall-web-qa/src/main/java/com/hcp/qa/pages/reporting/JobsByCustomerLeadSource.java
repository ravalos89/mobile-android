package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobsByCustomerLeadSource extends  ReportChartPage{

		@FindBy(xpath="//div[contains(text(),'Week to date')]")
		WebElement weekToDateBtn;

		@FindBy(xpath="//div[contains(text(),'Completed date')]")
		WebElement completedDateBtn;


		public JobsByCustomerLeadSource(WebDriver driver) { super(driver); }

		public void clickDateRange() {
			element.click(weekToDateBtn);
		}

		public void clickActionDate() {
			element.click(completedDateBtn);
		}

}
