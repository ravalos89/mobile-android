package com.hcp.qa.pages.serviceplan;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ServicePlanSettingsPage extends Page {

	@FindBy(css = ".MuiTypography-h1.MuiTypography-colorTextPrimary.MuiTypography-paragraph")
	private WebElement servicePlanSettingsHeader;

	@FindBy(xpath = "(//span[.='Reminder'])[1]/..")
	private WebElement reminderSendSchedulingBtn;

	@FindBy(xpath = "(//label[.='Time before visit is due'])[last()]/../div/div")
	private WebElement timeBeforeVisitDue;

	@FindBy(xpath = "//li[.='14 days']")
	private WebElement days14Option;

	@FindBy(xpath = "(//label[.='Delivery method'])[last()]/../div/div")
	private WebElement deliveryMethod;

	@FindBy(xpath = "//li[.='Email']")
	private WebElement selectEmailDeliverOption;

	@FindBy(xpath = "(//span[.='Reminder'])[2]/..")
	private WebElement reminderSendRenewalBtn;

	@FindBy(xpath = "(//label[.='Time before service plan ends'])[last()]/../div/div")
	private WebElement timeBeforeServicePlanEnds;

	@FindBy(xpath = "//li[.='1 day']")
	private WebElement oneDayOption;

	@FindBy(xpath = "//span[.='Save']/..")
	private WebElement saveBtn;

	@FindBy(xpath = "(//label[.='Time before visit is due']/..//div[@aria-haspopup='listbox'])[last()][.='14 days']")
	private WebElement timeDueDate;

	@FindBy(xpath = "(//label[.='Delivery method']/..//div)[last()][.='Email']")
	private WebElement emailDeliveryMethod;

	@FindBy(xpath = "(//label[.='Time before service plan ends']/..//div)[last()][.='1 day']")
	private WebElement timeEndDate;

	@FindBy(xpath = "(//h3[.='Send scheduling reminders']/../..//button[@class='MuiButtonBase-root MuiIconButton-root'])[last()]")
	private WebElement removeSendSchedulingReminder;

	@FindBy(xpath = "(//button[@class='MuiButtonBase-root MuiIconButton-root'])[last()-1]")
	private WebElement removeSendRenewalReminder;
	
	@FindBys(@FindBy(xpath = "//button[@class='MuiButtonBase-root MuiIconButton-root']"))
	private List<WebElement> removeReminderBtn;

	@FindBy(xpath = "//span[.='Ok']")
	private WebElement okBtn;

	public ServicePlanSettingsPage(WebDriver driver) {
		super(driver);
	}

	public String getPageHeader() {
		return element.getText(servicePlanSettingsHeader);
	}

	public void addSendSchedulingReminder() {
		waitForPageToLoad(1);
		PageUtils.clickUsingJS(driver, reminderSendSchedulingBtn);
		waitForPageToLoad(2);
		timeBeforeVisitDue.click();
		waitForPageToLoad(2);
		days14Option.click();
		waitForPageToLoad(2);
		deliveryMethod.click();
		waitForPageToLoad(2);
		selectEmailDeliverOption.click();
	}

	public void addSendRenewalReminder() {
		PageUtils.clickUsingJS(driver, reminderSendRenewalBtn);
		waitForPageToLoad(2);
		timeBeforeServicePlanEnds.click();
		oneDayOption.click();
	}

	public void clickSaveReminder() {
		saveBtn.click();
	}

	public boolean verifySendSchedulingReminderDisplayed() {
		return timeDueDate.isDisplayed() && emailDeliveryMethod.isDisplayed();
	}

	public boolean verifySendRenewalReminderDisplayed() {
		return timeEndDate.isDisplayed();
	}

	public void removeSendSchedulingReminder() {
		removeSendSchedulingReminder.click();	
		waitForPageToLoad(2);
	}

	public void removeSendRenewalReminder() {
		removeSendRenewalReminder.click();
		waitForPageToLoad(2);
	}

	public boolean verifyDuplicateErrorAlertDisplayed() {
		if (searchForText("Edits resulting in duplicate reminders will be removed")) {
			okBtn.click();
			return true;
		}
		else {
			return false;
		}
	}

	public void removeAllReminders() {
		int indexOfLastElement = removeReminderBtn.size() - 1;
		removeReminderBtn.remove(indexOfLastElement);
		for(WebElement element: removeReminderBtn) {
			element.click();
			waitForPageToLoad(1);
		}
	}

	public boolean isServicePlanSettingsTitleVisible() {
		return driver.findElement(By.xpath("//p[contains(.,'Service plan settings')]")).isDisplayed();
	}

}
