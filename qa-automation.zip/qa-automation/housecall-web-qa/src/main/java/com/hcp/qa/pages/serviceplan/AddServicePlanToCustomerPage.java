package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class AddServicePlanToCustomerPage extends Page {

	@FindBy(xpath = "//input[contains(@class,'FilledInput-inputAdornedEnd')]")
	private WebElement planName;

	@FindBy(xpath = "//div[contains(@class,'MuiFilledInput-adornedEnd')]//span")
	private WebElement calendarIcon;
	
	@FindBy(xpath = "//button[contains(@class,'MuiPickersDay-current')]")
	private WebElement todayDate;
	
	@FindBy(css = "[name='send_or_accept'][value='accept']")
	private WebElement acceptPlanForCustomer;
	
	@FindBy(xpath = "//span[.='Add']")
	private WebElement add;
	
	@FindBy(xpath = "//span[.='NEXT']")
	private WebElement next;
	
	@FindBy(xpath = "//span[.='FINISH & PAY']")
	private WebElement finishPay;

	@FindBy(css = "[aria-label='close']")
	private WebElement close;
	
	@FindBy(xpath = "//button[contains(@class,'MuiIconButton-colorInherit')]")
	private WebElement back;

	@FindBy(xpath = "//span[.='SEND']")
	private WebElement send;

	@FindBy(xpath = "//span[.='Send']")
	private WebElement sendEmail;

	@FindBy(xpath = "//span[.='Accept plan']")
	private WebElement acceptPlan;
	
	@FindBy(xpath = "//button[contains(@class,'MuiPickersDay-current')]/../../div[1]/button")
	private WebElement yesterdayDate;
	
	@FindBy(xpath = "//*[contains(@class,'MuiPickersCalendarHeader-iconButton')]")
	private WebElement previousMonthBack;
	
	@FindBy(xpath = "//p[.='My customer has already paid for this plan']")
	private WebElement customerAlreadyPaid;

	@FindBy(xpath = "//span[.='FINISH']")
	private WebElement finish;

	public AddServicePlanToCustomerPage(WebDriver driver) {
		super(driver);
	}

	public void clickClose() {
		close.click();
	}
	
	public void clickBack() {
		back.click();
	}

	public void clickAdd() {
		waitForPageToLoad(1);
		add.click();		
	}

	public void clickNext() {
		next.click();
	}

	public void clickFinishAndPay() {
		finishPay.click();
	}
	
	public void selectAcceptPlanForCustomer() {
		acceptPlanForCustomer.click();
	}

	public void clickSend() {
		send.click();
	}

	public void confirmSendEmail() {
		sendEmail.click();
	}

	public void clickAcceptPlan() {
		acceptPlan.click();
		waitForPageToLoad(1);
	}

	public void selectAlreadyPaid() {
		customerAlreadyPaid.click();
	}
	
	public void clickFinish() {
		finish.click();
	}
	
	public boolean isServicePlanActivatedMessage() {
		try {
			return driver.findElement(By.xpath("//p[.='Service plan is now active']")).isDisplayed();
		}
		catch(NoSuchElementException e) {
			return false;
		}
		
	}

	public void searchAndSelectPlan(String planName) {
		waitForPageToLoad(2);
		this.planName.sendKeys(planName);
		driver.findElement(By.xpath("//li[text()='"+planName+"']")).click();
		calendarIcon.click();
		waitForPageToLoad(2);
		todayDate.click();
		
	}
		
	public void searchAndSelectPlanWithPreviousDate(String planAlreadyPaidName) {
		this.planName.sendKeys(planAlreadyPaidName);
		driver.findElement(By.xpath("//li[text()='"+planAlreadyPaidName+"']")).click();		
		calendarIcon.click();
		waitForPageToLoad(1);
		if(yesterdayDate.getAttribute("tabindex").equals("0")) {
			yesterdayDate.click();
		}
		else {
			previousMonthBack.click();
			yesterdayDate.click();
		}
	}
		
}
