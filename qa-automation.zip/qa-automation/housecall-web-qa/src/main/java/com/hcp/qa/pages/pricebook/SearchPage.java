package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class SearchPage extends Page {

	public SearchPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@placeholder='Search by name, description, task code, or part number']")
	private WebElement searchBox;

	@FindBy(xpath = "//h2[contains(text(),'Search') and contains(@class,'colorTextPrimary')]//button")
	private WebElement closeBtn;

	public void closeSearch() {
		closeBtn.click();
	}

	public void enterSearchTerm(String searchFor) {
		waitForPageToLoad(1);
		searchBox.sendKeys(searchFor);
	}

	public boolean searchresultFound(String result){
		return  driver.findElement(By.xpath("//span[contains(.,'"+result+"')]")).isDisplayed();
	}

	public String getPriceOfItem(String service) {
		return element.getText(By.xpath("//span[contains(.,'"+service+"')]/ancestor::tr/td[5]/div"));
	}
}
