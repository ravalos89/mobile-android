package com.hcp.qa.pages.schedule;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class NewMenuWidget extends Page {

	@FindBy(xpath = "//h3[contains(.,'Job')]")
	private WebElement newJob;

	@FindBy(xpath = "//h3[contains(.,'Estimate')]")
	private WebElement newEstimate;

	@FindBy(xpath = "//h3[contains(.,'Event')]")
	private WebElement newEvent;

	public NewMenuWidget(WebDriver driver) {
		super(driver);
	}

	public void clickNewJob() {
		element.click(newJob);
	}

	public void clickNewEstimate() {
		element.click(newEstimate);
	}

}
