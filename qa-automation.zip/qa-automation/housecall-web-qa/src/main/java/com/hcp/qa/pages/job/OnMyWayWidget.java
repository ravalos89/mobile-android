package com.hcp.qa.pages.job;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class OnMyWayWidget extends Page {

    @FindBy(xpath = "//span[contains(.,'Notify customer')]/..//input")
    private WebElement notifyCustomerCheckbox;

    @FindBy(xpath = "//span[contains(.,'Cancel')]")
    private WebElement cancelBtn;

    @FindBy(xpath = "//span[contains(.,'ON MY WAY')]")
    private WebElement onMyWayBtn;

    public OnMyWayWidget(WebDriver driver) {
        super(driver);
    }

    public void clickOnMyWay() {
        element.click(onMyWayBtn);
    }

    public void clickCancel() {
        element.click(cancelBtn);
    }

    public void selectNotifyCustomer(boolean select) {
        if (select && !notifyCustomerCheckbox.isSelected())
            element.click(notifyCustomerCheckbox);
        else if (!select && notifyCustomerCheckbox.isSelected())
            element.click(notifyCustomerCheckbox);
    }

}
