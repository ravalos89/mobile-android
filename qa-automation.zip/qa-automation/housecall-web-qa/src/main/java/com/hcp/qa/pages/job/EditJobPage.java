package com.hcp.qa.pages.job;

import static org.openqa.selenium.By.xpath;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.models.LineItem;
import com.hcp.qa.pages.common.ActivityFeedWidget;
import com.hcp.qa.pages.common.DeleteDialog;
import com.hcp.qa.pages.common.EditTeamDialog;
import com.hcp.qa.pages.common.LineItemsWidget;
import com.hcp.qa.pages.common.PageUtils;
import com.hcp.qa.pages.common.PagewithNavigation;
import com.hcp.qa.pages.payment.PaymentHistoryWidget;
import com.hcp.qa.pages.payment.ProcessRefundDialog;
import com.hcp.qa.pages.schedule.AppointmentTimeReader;
import com.hcp.qa.pages.schedule.scheduleview.OldScheduleViewPage;

public class EditJobPage extends PagewithNavigation implements AppointmentTimeReader {

    private final static Logger LOG = LoggerFactory.getLogger(EditJobPage.class);

    @FindBy(xpath = "//span[contains(@title,'Job options')]")
    private WebElement jobOptions;

    @FindBy(xpath = "//a[contains(.,'#')]")
    private WebElement invoiceTitle;

    @FindBy(xpath = "//span[contains(.,'VIEW & SEND INVOICE')]")
    private WebElement sendInvoiceBtn;

    @FindBy(xpath = "//a[@class = 'icon-button-style']")
    private WebElement customerProfile;

    @FindBy(xpath = "//p[contains(.,'Checklists')]")
    private WebElement addChecklistsBtn;

    JobOptionsWidget jobOptionsWidget;

    DeleteDialog deleteJobPrompt;

    ActivityFeedWidget activityFeedWidget;

    JobFlowWidget jobFlowWidget;

    PaymentHistoryWidget paymentHistory;

    boolean isUnassigned;

    @FindBy(xpath = "//label[contains(.,'Item name')]/following-sibling::div/input")
    private WebElement itemName;

    @FindBy(xpath = "//span[.='This and future occurrences']")
    private WebElement allOccuranceDelete;

    @FindBy(xpath = "//h3[text()='Invoice']/..//span/h3")
    private WebElement invoiceNumber;

    @FindBy(xpath = "//p[contains(.,'Due')]/button")
    private WebElement invoiceDue;

    @FindBy(xpath = "//div[@class='line-items-card']//span[@class='MuiChip-label']")
    private List<WebElement> assignedEmployees;

    private final By jobDeletedMessage = xpath("//div[@role='alert']/div[text()='job has been deleted']");

    public EditJobPage(WebDriver driver) {
        super(driver);
        activityFeedWidget = new ActivityFeedWidget(driver);
        jobFlowWidget = new JobFlowWidget(driver);
        waitForPageToLoad(1);
        checkForUnassignedDialogAndDismissIt();

    }

    public void checkForUnassignedDialogAndDismissIt() {
        isUnassigned = false;
        waitForPageToLoad(1);
        if (searchForText("This job is not assigned")) {
            clickOk();
            isUnassigned = true;
            waitForPageToLoad(1);
        }
    }

    public boolean isJobUnassigned() {
        return isUnassigned;
    }
    
    private void clickOk() {
    	waitForPageToLoad(1);
        By okButtonLocator = xpath("//span[contains(.,'Ok')]");
        element.click(okButtonLocator);
        waitForPageToLoad(1);
        LOG.info("Dismissed the unassigned job Dialog successfully");
    }

    public void dismissChecklistError() {
        element.click(xpath("//span[contains(.,'OK')]"));
    }

    public void clickCheckList(String name) {
        waitForPageLoaded();
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 250)");
        element.click(xpath("//span[contains(.,'" + name + "')]"));
        waitForPageLoaded();
    }

    public OldScheduleViewPage clickSchedule() {
        jobFlowWidget.clickSchedule();

        return new OldScheduleViewPage(driver);
    }

    public OnMyWayWidget clickOnMyWay() {
        jobFlowWidget.clickOmw();

        return new OnMyWayWidget(driver);
    }

    public StartJobWidget clickStartJob() {
        jobFlowWidget.clickStart();

        return new StartJobWidget(driver);
    }

    public FinishJobWidget clickFinishJob() {
        PageUtils.scrollToTop(driver);
        waitForPageLoaded();
        jobFlowWidget.clickFinish();

        return new FinishJobWidget(driver);
    }

    public void clickAddChecklists() {
        element.click(addChecklistsBtn);
    }

    public void clickJobOptions() {
        try {
            waitHelper.waitForElementToBeClickable(jobOptions);
            jobOptions.click();
        } catch (NoSuchElementException e) {
            driver.findElement(xpath("//*[@id='react-sub-nav-toolbar']//span[contains(@title,'Job options')]"));
        }
        jobOptionsWidget = new JobOptionsWidget(driver);
    }

    public void clickDeleteFromJobOptions() {
        jobOptionsWidget.clickDeleteJob();
        deleteJobPrompt = new DeleteDialog(driver);
    }

    public void confirmDelete() {
        deleteJobPrompt.clickDelete();
    }

    public String getLatestActivity() {
        return activityFeedWidget.getLatestActivity();
    }

    public String getLatestActivityUser() {
        return activityFeedWidget.getLatestActivityUser();
    }

    public String getFailedPaymentActivity() {
        return activityFeedWidget.getFailedPaymentActivity();
    }

    public List<String> getAllActivitiesFromFeed() {
        return activityFeedWidget.getAllActivities();
    }

    public void addAttachement(String path) {
        WebElement fileInputElement = driver.findElement(By.id("attachment-upload"));
        PageUtils.provideFileUploadPath(driver, fileInputElement, path);
    }

    public void waitForDeleteMessageToAppear() {
        waitHelper.waitForElementToBeVisible(jobDeletedMessage);
    }

    public void waitForDeletedMessageToClear() {
        waitHelper.waitForElementToBeNotVisible(jobDeletedMessage);
    }

    public void waitForChecklistMessageToClear() {
        waitHelper.waitForElementToBeNotVisible(xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'Checklist added')]"));
    }

    public boolean isChecklistRemovedMessageDisplayed() {
        return element.isDisplayed(xpath("//div[starts-with(@class,'MuiSnackbar') and contains(.,'Checklist removed')]"));
    }

    public void addLineItem(LineItem lineItem) {
        LineItemsWidget lineItemWidget = new LineItemsWidget(driver);
        lineItemWidget.addLineItem(lineItem);
        waitForJobToSave();
    }
    
    public void assignEmployee(String employeeName) {
        LineItemsWidget lineItemWidget = new LineItemsWidget(driver);
        lineItemWidget.clickEditTeam();
    	EditTeamDialog editTeamDialog=new EditTeamDialog(driver);
		editTeamDialog.selectEmployee(employeeName);
		editTeamDialog.clickDone();
    }

    public void clickInvoice() {
        try {
            invoiceTitle.click();
        } catch (NoSuchElementException e) {
            LOG.info("Unable to find invoice title using <a>. Using <h3> element to Locate invoiceTitle ");
            element.click(xpath("//h3[contains(.,'#')]"));
        }
    }

    public String getInvoiceNumber() {
        try {
            return StringUtils.substringAfter(invoiceTitle.getText(), "#");
        } catch (NoSuchElementException e) {
            LOG.info("Unable to find invoice title using <a>. Using <h3> element to Locate invoiceTitle ");
            By invoiceTitleOldLocator = xpath("//h3[contains(.,'#')]");
            return StringUtils.substringAfter(element.getText(invoiceTitleOldLocator), "#");
        }
    }

    public void clickInvoiceDue() {
        element.click(invoiceDue);
    }

    public String getInvoiceDue() {
        return element.getText(invoiceDue);
    }

    public String getInvoiceNumberWithoutSegment() {
        return StringUtils.substringBetween(element.getText(invoiceTitle), "#", "-").trim();
    }

    public void clickSendInvoice() {
        PageUtils.scrollToTop(driver);
        element.click(sendInvoiceBtn);
    }

    public void clickCustomerProfile() {
        element.click(customerProfile);
    }

    public void addLineItemFromAutoSuggest(String serviceName) {
        LineItemsWidget addLineItem = new LineItemsWidget(driver);
        addLineItem.enterServiceLineItem(serviceName);
        element.click(xpath("//li[contains(.,'" + serviceName + "')]"));
        waitForJobToSave();
    }

    public void waitForJobToSave() {
        waitHelper.waitForElementToBeVisible(xpath("//span[contains(text(),'Saved')]"));
    }

    public ProcessRefundDialog clickRefund() {
        paymentHistory = new PaymentHistoryWidget(driver);
        return paymentHistory.clickRefund();
    }

    public boolean isChecklistPresent(String checklist) {
        return element.isDisplayed(xpath("//span[contains(.,'" + checklist + "')]"));
    }

    public void clickAllOccurencesDelete() {
        element.click(allOccuranceDelete);
        waitForPageLoaded();
    }

    public boolean isTaxRateNoneVisible() {
        return element.isDisplayed(xpath("//div[@aria-labelledby='select-tax'][.='none']"));
    }

    public List<String> getAssignedEmployees() {
        waitHelper.waitForElementsToBeVisible(assignedEmployees);
        return assignedEmployees.stream().map(WebElement::getText).collect(Collectors.toList());
    }

    @Override
    public String getStartTime() {
        return jobFlowWidget.getStartTime();
    }

    @Override
    public String getEndTime() {
        return jobFlowWidget.getEndTime();
    }

    @Override
    public String getTimeZone() {
        return jobFlowWidget.getScheduleTimezone();
    }
}
