package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends Page {

	@FindBy(id = "email")
	private WebElement email;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(xpath = "//span[text()='Sign in']")
	private WebElement signInBtn;

	@FindBy(linkText = "Sign up")
	private WebElement signUpLink;

	@FindBy(xpath = "//span[text()='Forgot password?']")
	private WebElement forgotPassword;

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public void loginToHCP(String email, String password) {
		element.type(this.email, email);
		element.type(this.password, password);
		element.click(signInBtn);
	}

	public void clickSignUp() {
		waitForPageToLoad(2);
		element.click(signUpLink);
	}

	public void clickForgotPassword() { element.click(forgotPassword);
	}

}
