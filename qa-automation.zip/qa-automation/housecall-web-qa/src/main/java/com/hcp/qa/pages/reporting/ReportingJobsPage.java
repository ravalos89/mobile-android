package com.hcp.qa.pages.reporting;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ReportingJobsPage extends Page {

	ReportingHelper reportingHelper = new ReportingHelper();

	@FindBy(xpath = "//div[contains(@class,'h2')]")
	WebElement reportingHeader;

	@FindBy(xpath = "//h1")
	WebElement jobHeader;

	@FindBy(xpath = "//button[contains(@class,'ss253')]")
	WebElement jobBtn;

	@FindBy(xpath = "//button[contains(@class,'ss254')]")
	WebElement customBtn;

	@FindBy(xpath = "//h6/span[contains(text(),'Date')]")
	WebElement dateHeader;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[1]/div[1]//p")
	List<WebElement> dateOptions;

	@FindBy(xpath = "//span[contains(text(),'Date')]/parent::*/parent::*/parent::*/parent::*//button")
	WebElement hcpCoachVideoDateBtn;

	@FindBy(xpath = "//h6/span[contains(text(),'Type')]")
	WebElement typeHeader;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[2]/div[1]//p")
	List<WebElement> typeOptions;

	@FindBy(xpath = "//span[contains(text(),'Type')]/parent::*/parent::*/parent::*/parent::*//button")
	WebElement hcpCoachVideoTypeBtn;

	@FindBy(xpath = "//h6/span[contains(text(),'Employee')]")
	WebElement employeeHeader;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[3]/div[1]//p")
	List<WebElement> employeeOptions;

	@FindBy(xpath = "//span[contains(text(),'Employee')]/parent::*/parent::*/parent::*/parent::*//button")
	WebElement hcpCoachVideoEmployeeBtn;

	@FindBy(xpath = "//h6/span[contains(text(),'Customer')]")
	WebElement customerHeader;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[1]/div[2]//p")
	List<WebElement> customerOptions;

	@FindBy(xpath = "//h6/span[contains(text(),'tracking')]")
	WebElement timeTrackingHeader;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[2]/div[2]//p")
	List<WebElement> timeTrackingOptions;

	@FindBy(xpath = "//span[contains(text(),'Time trackin')]/parent::*/parent::*/parent::*/parent::*//button")
	WebElement hcpCoachVideoTimeTrackingBtn;

	@FindBy(xpath = "//p[1]//span[contains(@style,'text-transform')]")
	WebElement messageModal;

	@FindBy(xpath = "//p[1]//span[contains(@style,'text-transform')]/span")
	WebElement messageApplication2;

	@FindBy(xpath = "//appcues-container//iframe")
	WebElement frame;

	@FindBy(xpath = "//a[@data-step='skip']")
	WebElement closeBtn;

	public ReportingJobsPage(WebDriver driver) {
		super(driver);
	}
	
	public boolean isHcpCoachVideoDateDisplayed() { return element.isDisplayed(hcpCoachVideoDateBtn); }
	public boolean isHcpCoachVideoTypeDisplayed() { return element.isDisplayed(hcpCoachVideoTypeBtn); }
	public boolean isHcpCoachVideoEmployeeDisplayed() { return element.isDisplayed(hcpCoachVideoDateBtn); }
	public boolean isHcpCoachVideoTimeTrackingDisplayed() { return element.isDisplayed(hcpCoachVideoDateBtn); }

	public void clickHcpCoachVideoDate() {
		element.click(hcpCoachVideoDateBtn);
	}

	public void clickHcpCoachVideoType() {
		element.click(hcpCoachVideoTypeBtn);
	}

	public void clickHcpCoachVideoEmployee() {
		element.click(hcpCoachVideoEmployeeBtn);
	}

	public void clickHcpCoachVideoTimeTracking() {
		element.click(hcpCoachVideoTimeTrackingBtn);
	}

	public void clickClose() {
		
		waitHelper.waitForElementToBeVisible(closeBtn);
		element.click(closeBtn);
	}

	public void switchToDefaultFrame() {
		driver.switchTo().defaultContent();
	}

	public void switchToFrame() {
		waitHelper.waitForElementToBeVisible(frame);
		driver.switchTo().frame(frame);
	}

	public List<String> getDateSectionOptions() {
		waitHelper.waitForPageLoaded();
		waitHelper.waitForElementToBeVisible(dateOptions.get(0));
		return reportingHelper.getOptions(dateOptions);
	}

	public List<String> getTypeSectionOptions() {
		waitHelper.waitForPageLoaded();
		return reportingHelper.getOptions(typeOptions);
	}

	public List<String> getEmployeeSectionOptions() {
		waitHelper.waitForPageLoaded();
		return reportingHelper.getOptions(employeeOptions);
	}

	public List<String> getCustomerSectionOptions() {
		waitHelper.waitForPageLoaded();
		return reportingHelper.getOptions(customerOptions);
	}

	public List<String> getTimeTrackingSectionOptions() {
		waitHelper.waitForPageLoaded();
		return reportingHelper.getOptions(timeTrackingOptions);
	}

	public String getMessageText() {
		waitHelper.waitForAnyTextToBePresent(messageModal);
		return messageModal.getText();
	}
	
	public void openDateOption(String option) { PageUtils.selectOption(dateOptions, option); }
	
	public void openCustomerOption(String option) { PageUtils.selectOption(customerOptions, option); }
	
	public void openTypeOption(String option) { PageUtils.selectOption(typeOptions, option); }
	
	public void openTimeTracking(String option) { PageUtils.selectOption(timeTrackingOptions, option); }

}
