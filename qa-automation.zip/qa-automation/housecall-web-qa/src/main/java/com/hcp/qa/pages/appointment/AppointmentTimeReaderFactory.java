package com.hcp.qa.pages.appointment;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.estimate.EditEstimatePage;
import com.hcp.qa.pages.event.EditEventPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.schedule.AppointmentTimeReader;
import com.hcp.qa.pages.schedule.calendar.AddTaskDialogValue;

public class AppointmentTimeReaderFactory {

    public AppointmentTimeReader create(WebDriver driver, AddTaskDialogValue appointmentType) {
        switch (appointmentType) {
            case JOB:
                return new EditJobPage(driver);
            case ESTIMATE:
                return new EditEstimatePage(driver);
            case EVENT:
                return new EditEventPage(driver);
        }
        throw new RuntimeException("Appointment type not supported");
    }
}
