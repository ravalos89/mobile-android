package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ErrorMessageDialog extends Page{

	@FindBy(xpath="//p[contains(@class,'MuiDialog')]")
	WebElement errorMsg;
	
	@FindBy(xpath="//span[contains(text(),'OK')]")
	WebElement okBtn;
	
	
	public ErrorMessageDialog(WebDriver driver) {
		super(driver);
	}

	public String getErrorMessage()
	{
		return errorMsg.getText();
	}
	
	public void clickOk()
	{
		okBtn.click();
	}

}
