package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.pages.leadsource.LeadSourcePage;

public class LeadSourceHelper {
	
	WebDriver driver;
	protected static Logger LOG = LoggerFactory.getLogger(LeadSourceHelper.class);

	public LeadSourceHelper(WebDriver driver) {
		this.driver = driver;
	}

	public void createLeadSource(String leadSource) {
		LeadSourcePage leadSourceList = new LeadSourcePage(driver);
		leadSourceList.clickAddLeadSource();
		leadSourceList.enterLeadSourceName(leadSource);
		leadSourceList.clickCreateBtn();
	}
	
	public void searchLeadSource(String leadSourceName) {
		LeadSourcePage leadSourceList = new LeadSourcePage(driver);
		leadSourceList.enterLeadSourceInSearch(leadSourceName);
	}

	public void deleteLeadSource(String leadSource) {
		LeadSourcePage leadSourceList = new LeadSourcePage(driver);
		leadSourceList.waitForPageToLoad(1);
		leadSourceList.clickLeadSource(leadSource);
		leadSourceList.delete();
		leadSourceList.confirmDelete();		
	}

	public void editLeadSource(String leadSourceName,String leadSourceUpdated) {
		LeadSourcePage leadSourceList = new LeadSourcePage(driver);
		leadSourceList.clickLeadSource(leadSourceName);
		leadSourceList.editLeadSourceName(leadSourceUpdated);
		leadSourceList.clickSaveBtn();
		driver.navigate().refresh();
	}
}
