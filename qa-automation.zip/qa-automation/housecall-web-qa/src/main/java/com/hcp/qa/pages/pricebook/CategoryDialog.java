package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CategoryDialog extends AddImageDialog{


	@FindBy(xpath="//input[contains(@class,'MuiFilledInput-input')]")
	WebElement categoryName;
			
	
	public CategoryDialog(WebDriver driver) {
		super(driver);
	}
	
	public void enterCategoryName(String categoryName)
	{
		this.categoryName.sendKeys(categoryName);
	}
	

}
