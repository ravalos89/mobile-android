package com.hcp.qa.helpers;

import java.util.List;

import com.hcp.qa.api.ApiClient;
import com.hcp.qa.common.Sleep;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.models.ResultsList;
import com.hcp.qa.models.search.CustomerSearchQuery;

public class ApiHelper {

	private static ApiHelper instance;
    private final ApiClient client;

    private ApiHelper() {
    	String apiKey=PropertiesReader.getInstance().getApiKey();
        client = new ApiClient(apiKey);
    }
    
    ApiHelper(String apiKey) {
        client = new ApiClient(apiKey);
    }
    
    
    public static ApiHelper getInstance()
    {
    	if (instance == null)
			instance = new ApiHelper();
		return instance;
    }

    public Customer createCustomer(Customer customer) {

       return client.createCustomer(customer)
                .as(Customer.class);
    }

    public Job createJob(Customer customer) {
    	LineItem lineItem=DataGenerator.getInstance().generateLineItem();
        return createJob(lineItem,customer);
    }
    
    public Job createJob(LineItem lineItem,Customer customer) {
        
        Job job = new Job();
        double unitPriceInCents=lineItem.getUnitPrice()*100;
        lineItem.setUnitPrice(unitPriceInCents);
        job.addLineItem(lineItem);
        
        job.setCustomerId(getCustomerId(customer));

        return client.createJob(job).as(Job.class);
    }


    private String getCustomerId(Customer customer) {
        CustomerSearchQuery query = new CustomerSearchQuery();
        query.setQueryString(customer.getDisplayName());
        List<Customer> customers = client.getCustomers(query).as(ResultsList.class).getCustomers();
        if (customers.isEmpty()) {
            Sleep.seconds(5);
            customers = client.getCustomers(query).as(ResultsList.class).getCustomers();
        }
        if(customers.isEmpty()) {
            throw new RuntimeException("Customer not found. " + customer.getDisplayName());
        }

        return customers.get(0).getId();
    }
    
}
