package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.pages.common.LoginPage;
import com.hcp.qa.pages.dashboard.DashboardPage;

public class LoginHelper {

    NavigationHelper navigationHelper;
    WebDriver driver;
    String proUser = PropertiesReader.getInstance().getProUser();
    String proPassword = PropertiesReader.getInstance().getPassword();

    protected static Logger LOG = LoggerFactory.getLogger(LoginHelper.class);

    protected DashboardPage dashboard;

    public LoginHelper(WebDriver driver) {
        this.driver = driver;
        this.navigationHelper = new NavigationHelper(driver);
        dashboard = new DashboardPage(driver);
    }

    public DashboardPage login() {
        return login(proUser, proPassword);
    }

    public DashboardPage loginFTU(String user) {
        return login(user, proPassword);
    }

    public DashboardPage login(String user, String password) {

        navigationHelper.goToLoginPage();
        LoginPage login = new LoginPage(driver);
        LOG.debug("Logging in with user " + user);
        login.loginToHCP(user, password);
        dashboard.waitForPageToLoad(1);
        return dashboard;
    }

    public void logout() {
        dashboard.waitForPageToLoad(1);
        dashboard.getTopMenu().clickSignOutFromProfile();
    }
}
