package com.hcp.qa.pages.reporting;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class LeadsPage extends Page{
	ReportingHelper reportingHelper = new ReportingHelper();


	@FindBy(xpath="//div[contains(@class,'h2')]")
	WebElement titleHeader;
	
	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[1]/div[1]//p")
	List<WebElement> dateOptions;
	
	@FindBy(xpath = "//div[contains(@class,'MuiGrid-spacing-xs-3')]/div[3]/div[1]//p")
	List<WebElement> employeeOptions;
	
	@FindBy(xpath="//span[contains(text(),'Create report')]/parent::*")
	WebElement createReportBtn;
	
	public LeadsPage(WebDriver driver) {
		super(driver);
	}
	
	public List<String> getDateSectionOptions() {
		waitHelper.waitForPageLoaded();
		waitHelper.waitForElementToBeVisible(dateOptions.get(0));
		return reportingHelper.getOptions(dateOptions);
	}
	
	public List<String> getEmployeeSectionOptions() {
		waitHelper.waitForPageLoaded();
		return reportingHelper.getOptions(employeeOptions);
	}
	
	public void openDateOption(String option) {
		PageUtils.selectOption(dateOptions, option);
	}

	public void openEmployeeOption(String option) {
		PageUtils.selectOption(employeeOptions, option);
	}

	public boolean isCreateReportDisplayed() {
		return element.isDisplayed(createReportBtn);
	}
	public void clickCrateReport() {
		element.click(createReportBtn);
	}
}
