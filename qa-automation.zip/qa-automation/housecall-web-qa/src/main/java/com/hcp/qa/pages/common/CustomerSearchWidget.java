package com.hcp.qa.pages.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static java.lang.String.format;
import static org.openqa.selenium.By.xpath;

public class CustomerSearchWidget extends Page {

	@FindBy(xpath = "//input[@placeholder='Name, email, phone, or address']")
	private WebElement searchCustomer;

	@FindBy(xpath = "//span[contains(.,'New customer')]")
	private WebElement newCustomer;

	@FindBy(xpath = "//span[@title='Edit']//button")
	private WebElement editCustomerButton;

	public CustomerSearchWidget(WebDriver driver) {
		super(driver);
	}

	public CustomerSearchWidget searchAndSelectExistingCustomer(String customerSearchText) {
		element.type(searchCustomer, customerSearchText, LONG_WAIT_TIME_IN_SECS);
		String customerTooltipTemplate = "//ul/li//p[contains(text(),'%s')]";
		element.click(customerTooltipTemplate, customerSearchText);
		return this;
	}

	public void clickNewCustomer() {
		element.click(newCustomer);
	}

	public CustomerSearchWidget unAssignCustomer() {
		element.click(editCustomerButton);
		return this;
	}

	public CustomerSearchWidget waitForCustomerToLoad(String partialCustomerName) {
		By customerNameLocatorTemplate = xpath(format("//div[.='Customer']/following-sibling::div//p[contains(text(),'%s')]",
				partialCustomerName));
		waitHelper.waitForElementToBeVisible(customerNameLocatorTemplate);
		return this;
	}

}
