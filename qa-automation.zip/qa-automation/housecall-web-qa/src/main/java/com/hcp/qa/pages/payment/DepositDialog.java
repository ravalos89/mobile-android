package com.hcp.qa.pages.payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class DepositDialog extends Page {

	@FindBy(name = "amountInDollar")
	private WebElement amount;

	@FindBy(xpath = "//div[starts-with(@class, 'MuiDialogActions-')]//button/span[contains(.,'ADD DEPOSIT')]")
	private WebElement addDeposit;
	
	@FindBy(xpath = "//button[.='%']")
	private WebElement percentage;
	
	@FindBy(name = "amountInPercent")
	private WebElement depositPercent;

	public DepositDialog(WebDriver driver) {
		super(driver);
	}

	public void clickAddDepositButton() {
		element.click(addDeposit);
	}

	public void enterDepositAmount(String depositAmount) { element.type(amount, depositAmount); }
	
	public void editDepositAmount(String depositAmount) { element.type(amount, depositAmount); }

	public void clickPercentage() { element.click(percentage); }
	
	public void enterDepositPercentage(String depositPercentage) { element.type(depositPercent, depositPercentage); }

}
