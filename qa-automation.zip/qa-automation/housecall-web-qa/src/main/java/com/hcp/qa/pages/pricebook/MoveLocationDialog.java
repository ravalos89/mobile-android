package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebElement;

public class MoveLocationDialog extends Page {

	public MoveLocationDialog(WebDriver driver) {
		super(driver);
	}

	public void selectIndustry(String industry) {
		driver.findElement(By.xpath("//label[contains(.,'Industry')]/following-sibling::div")).click();
		driver.findElement(By.xpath("//li[contains(.,'" + industry + "')]")).click();
	}

	public void selectCategory(String category) {
		waitForPageToLoad(2);
		driver.findElement(By.xpath("//label[contains(.,'Category')]/following-sibling::div")).click();
		driver.findElement(By.xpath("//li[contains(.,'" + category + "')]")).click();
		waitForPageToLoad(2);
	}
	
	public void clickSave()
	{
		WebElement save = driver.findElement(By.xpath("//span[contains(.,'Save')]"));
		waitHelper.waitForElementToBeClickable(save);
		driver.findElement(By.xpath("//span[contains(.,'Save')]")).click();
		waitForPageToLoad(2);
	}

}
