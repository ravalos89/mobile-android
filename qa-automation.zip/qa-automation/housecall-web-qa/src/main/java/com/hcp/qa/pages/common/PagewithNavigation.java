package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.navigation.TopNavigationWidget;
import com.hcp.qa.pages.navigation.TopNavigationWidgetFactory;

public abstract class PagewithNavigation extends Page {

	TopNavigationWidget topMenu;

	public PagewithNavigation(WebDriver driver) {
		super(driver);
		topMenu = TopNavigationWidgetFactory.createTopNavigationWidget(driver);
	}

	public TopNavigationWidget getTopMenu() {
		return topMenu;
	}

}
