package com.hcp.qa.pages.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HousecallLandingPage extends Page{
	
	@FindBy(xpath="//span[contains(.,'Start Free Trial')]")
	private WebElement startTrialBtn;
	
	public HousecallLandingPage(WebDriver driver) { super(driver); }
	
	public void clickStartFreeTrial()
	{
		element.click(startTrialBtn);
	}
}
