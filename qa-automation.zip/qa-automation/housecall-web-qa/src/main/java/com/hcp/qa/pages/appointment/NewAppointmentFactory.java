package com.hcp.qa.pages.appointment;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.pages.estimate.NewEstimatePage;
import com.hcp.qa.pages.event.NewEventPage;
import com.hcp.qa.pages.job.NewJobPage;
import com.hcp.qa.pages.schedule.calendar.AddTaskDialogValue;

public class NewAppointmentFactory {

    @SuppressWarnings("rawtypes")
    public static NewAppointment create(WebDriver driver, AddTaskDialogValue appointmentType) {
        switch (appointmentType) {
            case JOB:
                return new NewJobPage(driver);
            case ESTIMATE:
                return new NewEstimatePage(driver);
            case EVENT:
                return new NewEventPage(driver);
        }
        throw new RuntimeException("Appointment type not supported");
    }
}
