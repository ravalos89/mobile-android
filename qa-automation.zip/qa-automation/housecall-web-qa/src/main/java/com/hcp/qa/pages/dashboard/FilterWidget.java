package com.hcp.qa.pages.dashboard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class FilterWidget extends Page{

	@FindBy(xpath="//input[@value='daily']")
	WebElement dailyCheckbox;
	
	@FindBy(xpath="//h5[contains(.,'Filters')]/preceding-sibling::button")
	WebElement closeBtn;
	
	public FilterWidget(WebDriver driver) {
		super(driver);
	}
	
	public void selectDaily()
	{
		if(!dailyCheckbox.isSelected())
			dailyCheckbox.click();
	}
	
	public void clickClose()
	{
		closeBtn.click();
	}
	

}
