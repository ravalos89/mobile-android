package com.hcp.qa.pages.mymoney;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class PayoutsPage extends Page{


	@FindBy(xpath="//h3[contains(text(),'Pending transactions')]")
	WebElement pendingTransactionsTitle;
	
	@FindBy(xpath="//h6[contains(text(),'Charge date')]")
	WebElement chargeDate;
	
	@FindBy(xpath="//h5[contains(text(),'My payouts')]")
	WebElement myPayoutsTitle;
	
	@FindBy(xpath="//h6[contains(text(),'Deposit date')]")
	WebElement depositDate;
	
	
	
	public PayoutsPage(WebDriver driver) {
		super(driver);
	}
	

	public boolean isPendingTransactionVisible()
	{
		return pendingTransactionsTitle.isDisplayed();
	}
	public boolean isChargeDateVisible()
	{
		return chargeDate.isDisplayed();
	}
	
	public boolean isMyPayoutsVisible()
	{
		return myPayoutsTitle.isDisplayed();
	}
	
	public boolean isDepositDateVisible()
	{
		return depositDate.isDisplayed();
	}

}
