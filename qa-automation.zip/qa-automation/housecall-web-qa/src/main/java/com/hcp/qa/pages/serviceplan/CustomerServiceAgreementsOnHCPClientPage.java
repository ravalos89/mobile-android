package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.pages.common.Page;

import static java.time.Duration.ofSeconds;

public class CustomerServiceAgreementsOnHCPClientPage extends Page{
	
	@FindBy(xpath = "(//table)[1]/tbody/tr[1]/td[2]//span")
	private WebElement billingAmount;
	
	@FindBy(xpath = "(//table)[1]/tbody/tr[1]/td[1]/div")
	private WebElement billingDate;
	
	public CustomerServiceAgreementsOnHCPClientPage(WebDriver driver) {
		super(driver);
	}

	public boolean verifyServicePlan(String planName) {
		try {
			new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS))
			.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h6[.='"+planName+"']")));
			return true;
		}catch(NoSuchElementException e) {
			return false;
		}		
	}

	public boolean verifyServicePlanPaymentStatus() {
		return element.isDisplayed(By.xpath("//td[.='paid']"));
	}

	public String verifyServicePlanAmount() {
		return element.getText(billingAmount);
	}

	public String getBillingDate() {
		return element.getText(billingDate);
	}
}
