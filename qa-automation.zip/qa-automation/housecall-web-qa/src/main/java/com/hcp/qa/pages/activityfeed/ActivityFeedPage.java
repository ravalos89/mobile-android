package com.hcp.qa.pages.activityfeed;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ActivityFeedPage extends Page {

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchBox;

	public ActivityFeedPage(WebDriver driver) {
		super(driver);
	}

	public void enterSearchTerm(String search) {
		this.searchBox.sendKeys(search);
		this.searchBox.sendKeys(Keys.ENTER);
	}

	public void clickOnActivity(String textToSearch) {
		driver.findElement(By.xpath("//p[contains(.,'" + textToSearch + "')]")).click();
	}

	public void clickOnJobLinkInActivity(String jobId) {
		driver.findElement(By.xpath("//span[contains(.,'Job #" + jobId + "')]")).click();
	}

	public void clickOnEstimateLinkInActivity(String estimateId) {
		driver.findElement(By.xpath("//span[contains(.,'Estimate #" + estimateId + "')]")).click();
	}

	public boolean isJobLinkVisible(String jobId) {
		return driver.findElement(By.xpath("//span[contains(.,'Job #" + jobId + "')]")).isDisplayed();
	}

}
