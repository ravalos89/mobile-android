package com.hcp.qa.pages.schedule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.pages.common.Page;

import static com.hcp.qa.helpers.Colors.BUTTON_BLUE;
import static java.lang.String.format;
import static org.openqa.selenium.By.xpath;

public class ReorderEmployeesDialog extends Page {

    @FindBy(xpath = "//h5[text()='Reorder Employees']")
    private WebElement reorderEmployeesHeader;

    @FindBy(xpath = "//button[.= 'save order']")
    private WebElement saveOrderInDialogButton;

    public ReorderEmployeesDialog(WebDriver driver) {
        super(driver);
    }

    public void moveEmployeeAboveAnother(String employeeBeToMoved, String employeeToMoveAbove) {
        String employeeNameTemplate = "//td//p[contains(text(),'%s')]";
        By employeeToMoveLocator = xpath(format(employeeNameTemplate, employeeBeToMoved));
        WebElement employeeToMoveElement = waitHelper.waitForElementToBeClickable(employeeToMoveLocator);

        By employeeToMoveAboveLocator = xpath(format(employeeNameTemplate, employeeToMoveAbove));
        WebElement employeeToMoveAboveElement = waitHelper.waitForElementToBeClickable(employeeToMoveAboveLocator);

        Actions actions = new Actions(driver);
        actions.clickAndHold(employeeToMoveElement)
                .moveToElement(employeeToMoveAboveElement, 0, employeeToMoveAboveElement.getRect().getHeight()/2)
                .release()
                .perform();
    }

    public void clickSaveOrder() {
        By saveButtonLocator = xpath("//button[.= 'Save Order']");
        waitHelper.waitForElementToBeClickable(saveButtonLocator);
        waitHelper.waitForBackgroundColor(saveButtonLocator, BUTTON_BLUE);
        element.click(saveButtonLocator);
    }

    public void clickSaveOrderInDialog() {
        element.click(saveOrderInDialogButton);
        Sleep.seconds(3);
    }

    public void waitForDialogToDisappear() {
        By reorderEmployeesDialogLocator = xpath("//h5[text()='Reorder Employees']");
        waitHelper.waitForElementToBeNotVisible(reorderEmployeesDialogLocator);
    }
}
