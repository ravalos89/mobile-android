package com.hcp.qa.pages.admin;

import com.hcp.qa.pages.common.Page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

import static org.openqa.selenium.By.xpath;

public class ActivityFeedPage extends Page {

    public ActivityFeedPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//h2[text()='Activity Feed']")
    private WebElement activityFeedHeader;

    @FindBy(xpath = "//table//td//p[text()]")
    private List<WebElement> activityList;

    public void waitForActivityFeed() {
        waitHelper.waitForElementToBeVisible(activityFeedHeader, LONG_WAIT_TIME_IN_SECS);
    }

    public boolean isActivityWithTextVisible(String text) {
        return activityList.stream().anyMatch(activity -> activity.getText().contains(text));
    }

    public boolean isTextPresentInTimestampByActivityIndex(int activityIndex, String text) {
        return getTimestampByActivityIndex(activityIndex).contains(text);
    }

    public boolean isTextPresentInTimestampOfLatestActivity(String text) {
        return isTextPresentInTimestampByActivityIndex(0, text);
    }

    private String getTimestampByActivityIndex(int activityIndex) {
        return element.getText(xpath("//table//tr[" + activityIndex + 1 + "]/td[4]//p"));
    }
}
