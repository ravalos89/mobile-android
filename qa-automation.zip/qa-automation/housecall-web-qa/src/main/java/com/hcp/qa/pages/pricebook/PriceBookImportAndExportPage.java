package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class PriceBookImportAndExportPage extends Page {

	@FindBy(xpath = "//div[@class='_react-file-reader-input']/input")
	WebElement fileUpload;

	@FindBy(xpath = "//input/following-sibling::div/button")
	WebElement uploadBtn;

	@FindBy(xpath = "//button[.='Import']")
	WebElement importBtn;
	
	@FindBy(xpath = "//button[.='Export']")
	WebElement exportBtn;

	@FindBy(xpath = "//h6/div[text()='File successfully uploaded']")
	WebElement fileSuccessfullyUploaded;

	public PriceBookImportAndExportPage(WebDriver driver) {
		super(driver);
	}

	public void enterFilePath(String filePath) {
		PageUtils.provideFileUploadPath(driver, fileUpload, filePath);
	}

	public void clickUpload() {
		uploadBtn.click();
	}

	public void clickImport() {
		element.click(importBtn);
	}
	
	public void clickExport() {
		element.click(exportBtn);
	}

	public void waitForImportToFinish() {
		waitHelper.waitForElementToBeVisible(fileSuccessfullyUploaded);
	}

}
