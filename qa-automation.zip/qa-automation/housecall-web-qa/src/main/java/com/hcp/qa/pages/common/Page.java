package com.hcp.qa.pages.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.helpers.WaitHelper;
import com.hcp.qa.helpers.WebElementHelper;

public abstract class Page {

	protected WebDriver driver;
	protected WaitHelper waitHelper;
	protected WebElementHelper element;

	public static final int WAIT_TIME_IN_SECS = 10;
	public static final int LONG_WAIT_TIME_IN_SECS = 30;

	public Page(WebDriver driver) {
		this.driver = driver;
		waitHelper = new WaitHelper(driver);
		element = new WebElementHelper(driver);
		PageFactory.initElements(driver, this);
	}

	public boolean searchForText(String searchText) {
		waitForPageToLoad(1);
		WebElement element = driver.findElement(By.xpath("//*[contains(.,.)]"));
		return element.getText().toLowerCase().contains(searchText.toLowerCase());
	}

	// sometimes in headless mode the browser is too quick for the system to respond
	public void waitForPageToLoad(int waitTimeInSecs) {
		Sleep.seconds(waitTimeInSecs);
	}

	public void waitForPageLoaded() {
		waitHelper.waitForPageLoaded();
	}

	public void refreshPage() {
		driver.navigate().refresh();
		waitForPageLoaded();
	}
}
