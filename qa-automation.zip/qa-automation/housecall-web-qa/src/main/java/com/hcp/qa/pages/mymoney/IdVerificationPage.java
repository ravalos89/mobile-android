package com.hcp.qa.pages.mymoney;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class IdVerificationPage extends Page {
	public IdVerificationPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//input[@name='account_type'][@value='company']")
	WebElement accountTypeCompany;

	@FindBy(xpath = "//input[@name='account_type'][@value='individual']")
	WebElement accountTypeIndividual;

	@FindBy(xpath = "//input[@name='business_name']")
	private WebElement businessName;

	@FindBy(xpath = "//input[@name='business_tax_id']")
	private WebElement ein;

	@FindBy(name = "support_phone")
	private WebElement phone;

	@FindBy(xpath = "//input[@name='first_name']")
	private WebElement legalRepFirstName;

	@FindBy(xpath = "//input[@name='last_name']")
	private WebElement legalRepLastName;

	@FindBy(xpath = "//input[@name='dob']")
	private WebElement dob;

	@FindBy(xpath = "//input[@name='ssn']")
	private WebElement ssn;

	@FindBy(xpath = "//input[@type='file']")
	private WebElement idDocumentUpload;

	@FindBy(xpath = "//span[contains(text(),'Next')]")
	private WebElement next;

	public void selectAccountTypeCompany() {
		accountTypeCompany.click();
	}

	public void selectAccountTypeIndividual() {
		accountTypeIndividual.click();
	}

	public void enterBusinessName(String businessName) {
		this.businessName.sendKeys(businessName);
	}

	public void enterEIN(String ein) {
		this.ein.sendKeys(ein);
	}

	public void enterPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public void enterLegalRepFirstName(String firstName) {
		legalRepFirstName.sendKeys(firstName);
	}

	public void enterLegalRepLastName(String lastName) {
		legalRepLastName.sendKeys(lastName);
	}

	public void enterDateOfBirth(String dob) {
		this.dob.sendKeys(dob);
	}

	public void enterSSN(String ssn) {
		this.ssn.sendKeys(ssn);
	}

	public void uploadIdDocument(String path) {
		PageUtils.provideFileUploadPath(driver, idDocumentUpload, path);
	}

	public void clickNext() {
		next.click();
	}

}
