package com.hcp.qa.pages.serviceplan;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class CustomerServicePlanVisitsWidget extends Page {
	@FindBy(xpath = "//span[.='UNSCHEDULED']")
	private WebElement unschedule;
	
	@FindBy(xpath = "//span[.='Maintenance schedule']/ancestor::div//tbody/tr[1]/td[2]//span")
	private WebElement invoiceNumber;
	
	@FindBy(xpath = "//span[@title='Schedule visit']/button")
	private WebElement calendar;

	public CustomerServicePlanVisitsWidget(WebDriver driver) {
		super(driver);
	}
	
	public void clickCalendar() {
		calendar.click();
	}
}