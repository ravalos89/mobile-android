package com.hcp.qa.pages.payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class AddTipWidget extends Page {

	@FindBy(xpath = "//span[contains(text(),'10%')]")
	private WebElement tenPercentBtn;

	@FindBy(xpath = "//span[contains(text(),'15%')]")
	private WebElement fifteenPercentBtn;

	@FindBy(xpath = "//span[contains(text(),'20%')]")
	private WebElement twentyPercentBtn;

	@FindBy(xpath = "//span[contains(text(),'No Tip')]")
	private WebElement noTipBtn;

	@FindBy(xpath = "//span[contains(text(),'Custom')]")
	private WebElement customBtn;

	@FindBy(xpath = "//input[@name='customTip']")
	private WebElement customTip;

	public AddTipWidget(WebDriver driver) {
		super(driver);
	}

	public void clickTenPercentTip() {
		element.click(tenPercentBtn);
	}

	public void clickFifteenPercentTip() {
		element.click(fifteenPercentBtn);
	}

	public void clickTwentyPercentTip() {
		element.click(twentyPercentBtn);
	}

	public void clickNoTip() {
		element.click(noTipBtn);
	}

	public void clickCustomTip() {
		element.click(customBtn);
	}

	public void enterCustomTipAmount(String tipAmount) {
		element.type(customTip, tipAmount);
	}

}
