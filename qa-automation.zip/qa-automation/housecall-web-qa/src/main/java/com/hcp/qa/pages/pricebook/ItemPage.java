package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;
import com.hcp.qa.pages.common.PageUtils;

public class ItemPage extends Page{
	
	@FindBy(xpath = "//label[contains(.,'Item name')]/following-sibling::div/input")
	private WebElement itemName;
	
	@FindBy(xpath = "//label[contains(.,'Description')]/following-sibling::div/textarea")
	private WebElement description;
	
	@FindBy(xpath = "//label[contains(.,'Part number')]/following-sibling::div/input")
	private WebElement partNumber;
	
	@FindBy(xpath = "//label[contains(.,'Item cost')]/following-sibling::div/input")
	private WebElement itemCost;
	
	@FindBy(id = "unit-autocomplete")
	private WebElement itemUnit;
	
	@FindBy(xpath = "//span[contains(text(),'Save')]")
	private WebElement saveBtn;
	
	@FindBy(xpath="//span[contains(.,'Change to pro-managed')]")
	private WebElement changeToProManageBtn;
	
	@FindBy(css=".MuiSwitch-switchBase.MuiSwitch-colorPrimary")
	private WebElement markupToggle;

	public ItemPage(WebDriver driver) {
		super(driver);
	}
	
	public void enterItemName(String itemName) {
		waitForPageToLoad(1);
		this.itemName.sendKeys(itemName);
	}

	public void enterDescription(String description) {
		this.description.sendKeys(description);
	}	

	public void enterPartNumber(String partNumber) {
		this.partNumber.sendKeys(partNumber);
	}
	
	public void enterCost(String itemCost){
		this.itemCost.clear();
		this.itemCost.sendKeys(itemCost);
	}
	
	public void selectUnit(String unit){
		PageUtils.scrollAndSelectTextFromDropDown(driver, itemUnit, unit);
	}
	
	public void clickSave(){
		saveBtn.click();
	}

	public boolean verifyChangeToProManagedPresent() {
		return changeToProManageBtn.isDisplayed();
	}

	public void markupToggleOn() {
		PageUtils.toggleButton(markupToggle, true);
	}

}
