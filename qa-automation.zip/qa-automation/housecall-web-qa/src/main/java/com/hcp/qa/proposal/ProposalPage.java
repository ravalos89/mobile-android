package com.hcp.qa.proposal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ProposalPage extends Page{
	
	@FindBy(xpath="//h5[contains(.,'New proposal')]/preceding-sibling::button")
	WebElement closeBtn;
	
	@FindBy(xpath="//h5[contains(.,'New proposal')]")
	WebElement title;

	public ProposalPage(WebDriver driver) {
		super(driver);
	}
	
	public boolean isTitleVisible()
	{
		return title.isDisplayed();
	}
	
	public void clickClose()
	{
		closeBtn.click();
	}
	

}
