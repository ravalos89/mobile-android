package com.hcp.qa.pages.schedule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.helpers.StringHelper;
import com.hcp.qa.pages.common.Page;

import static java.lang.String.format;
import static org.openqa.selenium.By.xpath;

public class TeamCalendars extends Page {
    public TeamCalendars(WebDriver driver) {
        super(driver);
    }

    private static final String EMPLOYEE_CHECKBOX_XPATH = "//div[@role and descendant::span[contains(text(), '%s')]]//input";

    @FindBy(xpath = "//p[text()='Team calendars']")
    private WebElement teamCalendarsHeader;

    @FindBy(xpath = "(//*[@data-testid='calendarControlsDrawer__container']//button)[1]")
    private WebElement reorderEmployeesButton;

    public boolean isTeamCalendarVisible() {
        return element.isDisplayed(teamCalendarsHeader);
    }

    public void clickOnEmployeeCheckbox(String employeeName) {
        WebElement checkbox = getEmployeeCheckbox(employeeName);
        element.click(checkbox);
    }

    public boolean isEmployeeSelected(String employeeName) {
        return getEmployeeCheckbox(employeeName).isSelected();
    }

    private WebElement getEmployeeCheckbox(String employeeName) {
        waitHelper.waitForElementToBeVisible(teamCalendarsHeader);
        By employeeCheckboxLocator = xpath(format(EMPLOYEE_CHECKBOX_XPATH, employeeName));
        return driver.findElement(employeeCheckboxLocator);
    }

    public TeamCalendars checkEmployee(String employeeName) {
        String employeeNameCapitalized = StringHelper.capitalizeEachWord(employeeName);
        if(!isEmployeeSelected(employeeNameCapitalized)) {
            clickOnEmployeeCheckbox(employeeNameCapitalized);
        }
        return this;
    }

    public String getEmployeeName(int employeeNumber) {
        By employeeNameLocator = xpath(format("//div[@data-testid='EmployeeSelectionList__item'][%d]//span[text()]", employeeNumber));
        return element.getText(employeeNameLocator);
    }

    public void clickOnReorderButton() {
        element.click(reorderEmployeesButton);
        sleepUntilReorderDialogShifts();
    }

    private void sleepUntilReorderDialogShifts() {
        Sleep.seconds(1);
    }
}
