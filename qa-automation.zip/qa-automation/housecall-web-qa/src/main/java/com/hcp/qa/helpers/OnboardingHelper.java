package com.hcp.qa.helpers;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;

import com.hcp.qa.api.GrowthApiClient;
import com.hcp.qa.common.ProDto;
import com.hcp.qa.models.growth.CompanySize;
import com.hcp.qa.models.growth.SignUp;
import com.hcp.qa.models.growth.SignUpResponse;
import com.hcp.qa.pages.common.LineItemsWidget;
import com.hcp.qa.pages.job.JobFlowWidget;
import com.hcp.qa.pages.job.NewJobPage;
import com.hcp.qa.pages.mymoney.MyMoneyPage;
import com.hcp.qa.pages.navigation.TopNavigationWidgetFactory;
import com.hcp.qa.pages.onboarding.FTUFlowWidget;
import com.hcp.qa.pages.onboarding.SignUpFlow;
import com.hcp.qa.pages.onboarding.WelcomePage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OnboardingHelper {

	private final WebDriver driver;
	private final NavigationHelper navigationHelper;
	private final PropertiesReader properties = PropertiesReader.getInstance();

	protected GrowthApiClient growthClient = new GrowthApiClient();

	public OnboardingHelper(WebDriver driver) {
		this.driver = driver;
		this.navigationHelper = new NavigationHelper(driver);
	}

	public ProDto createNewProThroughSignUp() {
		return createNewProThroughSignUp("");
	}

	public ProDto createNewProThroughApi() {
		String email = "qa+" + RandomStringUtils.randomAlphanumeric(10) + "@housecallpro.com";

		return createNewProThroughApi(email);
	}

	public ProDto createNewProThroughApi(String email) {
		SignUp signUp = SignUpDtoFactory.getDefaultCompany(email);
		SignUpResponse response = growthClient.createOrganization(signUp).getBody().as(SignUpResponse.class);
		driver.get(response.getUrl());
		navigationHelper.waitForUrlToContain("get_started", 30);
		TopNavigationWidgetFactory.createTopNavigationWidget(driver).waitForGetStartedIcon();
		ProDto pro = new ProDto(signUp);
		pro.setOrgId(response.getOrgId());

		return pro;
	}

	public ProDto createNewProThroughSignUp(String emailPart) {
		navigationHelper.goToLoginPage();
		LocalStorage local = ((WebStorage) driver).getLocalStorage();
		local.clear();
		local.setItem("SIMPLE_EXPERIMENTS", "{\"data\":{\"progressive-disclosure-signup\":\"treatment\"}}");

		SignUpFlow signUpFlowPage = new SignUpFlow(driver);
		signUpFlowPage.waitForPageToLoad(2);
		signUpFlowPage.clickSignUpLink();
		ProDto pro = new ProDto();
		pro.setEmail("qa+" + RandomStringUtils.randomAlphanumeric(10) + emailPart + "@housecallpro.com");
		log.info("Creating new Pro with the email " + pro.getEmail());
		signUpFlowPage.setEmail(pro.getEmail());
		pro.setFirstName("QA " + RandomStringUtils.randomAlphabetic(5));
		signUpFlowPage.setFirstName(pro.getFirstName());
		pro.setLastName("PRO");
		signUpFlowPage.setLastName(pro.getLastName());
		signUpFlowPage.setPhoneNumber(properties.getMobileNumber());

		signUpFlowPage.clickContinueButton();
		signUpFlowPage.waitForPageToLoad(1);

		pro.setCompanyName("Company" + RandomStringUtils.randomAlphabetic(5));
		signUpFlowPage.setCompanyName(pro.getCompanyName());
		signUpFlowPage.setCompanyStreet("1234 Auto Street");
		signUpFlowPage.setCompanyCity("Carlsbad");
		signUpFlowPage.setCompanyState("California");
		signUpFlowPage.setCompanyZip("92008");
		signUpFlowPage.selectPrimaryIndustry("Handyman");

		signUpFlowPage.selectCompanySize(CompanySize.SMALL.toString());

		signUpFlowPage.clickCompanyWebsite();

		signUpFlowPage.clickContinueButton();
		pro.setPassword(properties.getPassword());
		signUpFlowPage.setPassword(properties.getPassword());

		signUpFlowPage.clickStartFreeTrialButton();
		navigationHelper.waitForUrlToContain("get_started", 30);

		TopNavigationWidgetFactory.createTopNavigationWidget(driver).waitForGetStartedIcon();

		return pro;
	}

	public void completeJobOnboarding() {
		WelcomePage welcomePage = new WelcomePage(driver);
		welcomePage.clickCloseVideo();
		welcomePage.clickScheduleAndDispatchJobLink();

		FTUFlowWidget ftuFlow = new FTUFlowWidget(driver);
		ftuFlow.clickStartTutorial();

		ftuFlow.clickNextOnSampleCustomer();
		ftuFlow.clickNextOnSchedule();

		LineItemsWidget lineItemWidget = new LineItemsWidget(driver);
		lineItemWidget.addLineItem(DataGenerator.getInstance().generateLineItem());
		ftuFlow.clickNextOnAddLineItem();

		NewJobPage newJob = new NewJobPage(driver);
		newJob.waitForPageLoaded();
		newJob.waitForCustomerCardToLoad();
		newJob.save();

		newJob.waitForPageToLoad(3);
		ftuFlow.clickNotNowButton();
		ftuFlow.waitForPageToLoad(5);
		new JobFlowWidget(driver).waitForPayIcon();
	}

	public void completeMyMoneyOnboarding() {
		WelcomePage welcomePage = new WelcomePage(driver);
		welcomePage.clickCloseVideo();
		welcomePage.clickGetPaidInstantlyLink();

		FTUFlowWidget ftuFlow = new FTUFlowWidget(driver);
		ftuFlow.clickGetStartedButton();
		ftuFlow.waitForPageToLoad(1);

		MyMoneyPage myMoney = new MyMoneyPage(driver);
		myMoney.clickConnectMyBank();

		new PlaidHelper(driver).connectChaseCheckingAccount();
		myMoney.waitForPageToLoad(10);

	}
}
