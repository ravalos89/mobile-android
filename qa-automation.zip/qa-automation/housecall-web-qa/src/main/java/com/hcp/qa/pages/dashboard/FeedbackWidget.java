package com.hcp.qa.pages.dashboard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class FeedbackWidget extends Page {

	@FindBy(xpath = "//div[@role=\"tooltip\" and not(contains(@style,'display: none'))]//span[contains(.,\"I like this report\")]")
	private WebElement likeBtn;

	@FindBy(xpath = "//div[@role='tooltip' and not(contains(@style,'display: none'))]//span[contains(.,\"I don't like this report\")]")
	private WebElement dislikeBtn;

	@FindBy(xpath = "//textarea[@data-testid='feedback-input']")
	private WebElement comment;

	@FindBy(xpath = "//button[contains(.,'SEND')]")
	private WebElement sendBtn;

	@FindBy(xpath = "//button[contains(.,'CLOSE')]")
	private WebElement closeBtn;

	public FeedbackWidget(WebDriver driver) {
		super(driver);
	}

	public void clickLikeReport() {
		likeBtn.click();
	}

	public void clickDislikeReport() {
		waitForPageToLoad(1);
		dislikeBtn.click();
	}

	public void enterComments(String text) {
		comment.click();
		comment.sendKeys(text);
	}

	public void clickSend() {
		sendBtn.click();
	}

	public void clickClose() {
		closeBtn.click();
	}

}
