package com.hcp.qa.pages.dashboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.pages.common.Page;

import static java.time.Duration.ofSeconds;

public class AverageJobSizeCard extends Page{

	@FindBy(xpath="//div[contains(.,'Average job size')]/following-sibling::div/span[@title='More actions']/button")
	WebElement moreActionsBtn;
	
	@FindBy(xpath="//div[starts-with(@class,'MuiCardHeader-content') and contains(.,'Average job size')]/following-sibling::div/span[@title='Filter']")
	WebElement filterBtn;
	
	@FindBy(xpath="//span[contains(.,'Help')]")
	WebElement help;
	
	@FindBy(xpath="//div[contains(text(),'Today')]/../preceding-sibling::div/h6")
	WebElement todayRevenue;
	
	@FindBy(xpath="//div[contains(text(),'Average')]/../preceding-sibling::div/h6")
	WebElement average;
	
	@FindBy(xpath="//span[contains(.,'Average job size')]/../../..//button[contains(.,'Give us feedback')]")
	WebElement feedbackBtn;

	public AverageJobSizeCard(WebDriver driver) {
		super(driver);
	}
	
	public void clickMoreActions()
	{
		waitHelper.waitForElementToBeClickable(moreActionsBtn, LONG_WAIT_TIME_IN_SECS).click();
	}
	
	public void clickFilter()
	{
		waitForAverageJobSizeToLoad();
		waitHelper.waitForElementToBeClickable(filterBtn).click();
		Sleep.seconds(1);
	}
	
	public void clickHelp()
	{
		help.click();
	}
	
	public double getTodaysRevenue()
	{
		String revenueAmt=todayRevenue.getText().replace("$","");
		return Double.parseDouble(revenueAmt);
		
	}

	public String getAverage()
	{
		return average.getText();
	}
	
	public void clickFeedback()
	{
		waitHelper.waitForElementToBeVisible(feedbackBtn, LONG_WAIT_TIME_IN_SECS);
		waitForAverageJobSizeToLoad();
		waitHelper.waitForElementToBeClickable(feedbackBtn).click();
	}

	private void waitForAverageJobSizeToLoad() {
		new WebDriverWait(driver, ofSeconds(LONG_WAIT_TIME_IN_SECS)).until(ExpectedConditions.invisibilityOfElementLocated(
				By.xpath("//span[contains(.,'Average job size')]/ancestor::div/following-sibling::div[@role='progressbar']")
		));
	}

}
