package com.hcp.qa.pages.payment;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ProcessRefundDialog extends Page {

	@FindBy(xpath = "//label[contains(.,'Refund amount')]/../div/input")
	private WebElement refundAmount;

	@FindBy(xpath = "//span[contains(text(),'ISSUE REFUND')]")
	private WebElement issueRefundBtn;

	@FindBy(xpath = "//span[contains(text(),'CANCEL')]")
	private WebElement cancelBtn;
	
	@FindBy(xpath = "//p[contains(.,'Refund amount must be less than the remaining transaction total')]")
	private WebElement amtGreaterErrorMsg;

	public ProcessRefundDialog(WebDriver driver) {
		super(driver);
	}

	public void enterRefundAmount(String refundAmt) {
		for (int i = 0; i < 5; i++) {
			element.type(refundAmount, Keys.BACK_SPACE.toString());
		}
		element.type(refundAmount, refundAmt);
	}

	public void clickIssueRefund() {
		element.click(issueRefundBtn);
	}

	public void clickCancel() {
		element.click(cancelBtn);
	}
	
	public boolean isAmountGreaterErrorMsgPresent() { return element.isDisplayed(amtGreaterErrorMsg); }

}
