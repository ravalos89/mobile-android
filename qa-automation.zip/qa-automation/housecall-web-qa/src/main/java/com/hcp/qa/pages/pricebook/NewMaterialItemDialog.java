package com.hcp.qa.pages.pricebook;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

import com.hcp.qa.pages.common.Page;

public class NewMaterialItemDialog extends Page {

	@FindBy(xpath = "(//span[contains(text(),'Cancel')])[2]")
	private WebElement cancelPopupBtn;

	@FindBy(id = "mui-component-select-Category/Subcategory")
	private WebElement locationDropDown;

	@FindBys(@FindBy(xpath = "//div[@id='menu-Category/Subcategory']//ul/li"))
	private List<WebElement> locationCategories;

	public NewMaterialItemDialog(WebDriver driver) {
		super(driver);
	}

	public boolean validateProfitRhinoCategoryNotPresent() {
		for(WebElement cat: locationCategories) {
			if(cat.getText().contains("Profit Rhino")) {
				return false;
			}
		}
		return true;
	}
	
	public void clickCancel() {
		cancelPopupBtn.click();
	}

	public void clickLocation() {
		locationDropDown.click();
	}

	public void clickLocationCategory() {
		locationCategories.get(0).click();
	}
}
