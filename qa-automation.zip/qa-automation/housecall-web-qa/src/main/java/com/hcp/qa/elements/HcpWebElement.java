package com.hcp.qa.elements;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Coordinates;
import org.openqa.selenium.interactions.Locatable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.reports.ReportUtils;

public class HcpWebElement implements Element {

	protected final WebElement element;
	private ReportUtils rep = new ReportUtils();
	Logger LOG = LoggerFactory.getLogger(HcpWebElement.class);

	public HcpWebElement(final WebElement element) {
		this.element = element;
	}

	@Override
	public void clear() {
		try {
			element.clear();
			if (element.getAttribute("value").length() > 0) {
				LOG.info("Clearing text '" + element.getAttribute("value") + "'");
				element.click();
				element.sendKeys(Keys.END);
				int inputLength = element.getAttribute("value").length();
				Sleep.seconds(1);
				for (int i = 0; i < inputLength; i++) {
					element.sendKeys(Keys.BACK_SPACE);
				}
				Sleep.seconds(1);
			}

			rep.reporter("Element was cleared", element);
		} catch (Exception e) {
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			rep.fail("Is not possible to clear the web element [ " + rep.getFormattedLocator(element) + " ]"+errors.toString());
			
		}

	}

	@Override
	public void click() {
		element.click();
		rep.reporter("Element was clicked", element);
		LOG.info("Element was clicked " + rep.getFormattedLocator(element));
	}

	@Override
	public WebElement findElement(By arg0) {
		return element.findElement(arg0);
	}

	@Override
	public List<WebElement> findElements(By arg0) {

		return element.findElements(arg0);
	}

	@Override
	public String getAttribute(String arg0) {

		return element.getAttribute(arg0);
	}

	@Override
	public String getCssValue(String arg0) {

		return element.getCssValue(arg0);
	}

	@Override
	public Point getLocation() {

		return element.getLocation();
	}

	@Override
	public Rectangle getRect() {

		return element.getRect();
	}

	@Override
	public Dimension getSize() {

		return element.getSize();
	}

	@Override
	public String getTagName() {

		return element.getTagName();
	}

	@Override
	public String getText() {
		rep.reporter("Text extracted from application", element.getText());
		return element.getText();
	}

	@Override
	public boolean isDisplayed() {
		try {
			rep.reporter("Element is visible in the screen", element);
			return element.isDisplayed();

		} catch (NoSuchElementException e) {
			return false;
		}
	}

	@Override
	public boolean isEnabled() {

		return element.isEnabled();
	}

	@Override
	public boolean isSelected() {

		return element.isSelected();
	}

	@Override
	public void sendKeys(CharSequence... arg0) {
		if (getLocator().contains("password")) {
			LOG.info("Entering password ********** in element " + rep.getFormattedLocator(element));
		} else if (!containsSpecialKeys(arg0)) {
			LOG.info("Entering text '" + String.valueOf(arg0[0]) + "' in element " + rep.getFormattedLocator(element));
		}
		element.sendKeys(arg0);
		rep.reporter("Text was typed",  String.valueOf(arg0[0]), element);
	}

	private boolean containsSpecialKeys(CharSequence... arg0) {
		if (String.valueOf(arg0[0]).contains(Keys.ARROW_RIGHT) || String.valueOf(arg0[0]).contains(Keys.ARROW_LEFT)
				|| String.valueOf(arg0[0]).contains(Keys.BACK_SPACE) || String.valueOf(arg0[0]).contains(Keys.ENTER)
				|| String.valueOf(arg0[0]).contains(Keys.END))
			return true;
		else
			return false;
	}

	@Override
	public void submit() {
		element.submit();

	}

	@Override
	public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {

		return element.getScreenshotAs(arg0);
	}

	@Override
	public WebElement getWrappedElement() {
		return element;
	}

	@Override
	public Coordinates getCoordinates() {

		if (element instanceof Locatable) {
			return ((Locatable) element).getCoordinates();
		}
		throw new UnsupportedOperationException("Underlying element instance does not support location");
	}

	@Override
	public String getLocator() {
		return StringUtils.substringAfter(element.toString(), "->");
	}

}
