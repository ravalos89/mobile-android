package com.hcp.qa.pages.leadsource;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class LeadSourceDialog extends Page {

	@FindBy(xpath = "//p[.='Lead source']")
	WebElement addLeadSource;

	@FindBy(css = "[data-testid='lead-sources-autocomplete']")
	private WebElement leadSource;

	@FindBy(xpath = "//button[@title='Clear']")
	private WebElement close;

	public LeadSourceDialog(WebDriver driver) {
		super(driver);
	}

	public void addLeadSource(String leadSourceName) {
		addLeadSource.click();
		leadSource.sendKeys(leadSourceName);
		waitHelper.waitForElementToBeClickable(By.xpath("//*[contains(text(),'"+leadSourceName+"')]"), WAIT_TIME_IN_SECS).click();
	}

	public void deleteLeadSource(String leadSourceName) {
		leadSource.click();
		close.click();
	}

	public boolean isLeadSourceAdded(String leadSourceName) {
		return driver.findElement(By.xpath("//input[@value='"+leadSourceName+"']")).isDisplayed();
	}
	
	public boolean isLeadSourceDeleted(String leadSourceName) {
		return leadSource.getAttribute("value").isEmpty();
	}
	
}
