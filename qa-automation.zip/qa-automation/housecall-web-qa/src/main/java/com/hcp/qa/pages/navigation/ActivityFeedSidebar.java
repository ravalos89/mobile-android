package com.hcp.qa.pages.navigation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class ActivityFeedSidebar extends Page {
	//@FindBy(xpath="//h1[contains(.,'Activity feed')]")
	@FindBy(xpath="//div[contains(text(),'Activity feed')]")
	WebElement title;
	
	//@FindBy(xpath="//h1[contains(.,'Activity feed')]/preceding-sibling::div/button")
	@FindBy(xpath="//div[contains(text(),'Activity feed')]/preceding-sibling::button")
	WebElement closeBtn;

	public ActivityFeedSidebar(WebDriver driver) {
		super(driver);
	}
	
	public boolean isTitleVisible()
	{
		return title.isDisplayed();
	}
	
	public void clickClose()
	{
		closeBtn.click();
	}
	

}
