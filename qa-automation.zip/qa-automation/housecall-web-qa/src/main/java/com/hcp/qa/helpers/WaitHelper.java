package com.hcp.qa.helpers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hcp.qa.common.Sleep;

import static java.time.Duration.ofSeconds;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class WaitHelper {

    public static final int DEFAULT_TIMEOUT_SECONDS = 10;

    private final WebDriverWait wait;

    private final WebDriver driver;

    public WaitHelper(WebDriver driver) {
        wait = new WebDriverWait(driver, ofSeconds(DEFAULT_TIMEOUT_SECONDS));
        this.driver = driver;
    }

    public void waitForExpectedCondition(ExpectedCondition condition) {
        wait.until(condition);
    }

    public WebElement waitForElementToBeClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public WebElement waitForElementToBeClickable(By by) {
        return wait.until(ExpectedConditions.elementToBeClickable(by));
    }

    public WebElement waitForElementToBeVisible(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    public List<WebElement> waitForElementsToBeVisible(List<WebElement> elements) {
        return wait.until(ExpectedConditions.visibilityOfAllElements(elements));
    }

    public WebElement waitForElementToBeVisible(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public WebElement waitForElementToBeVisible(WebElement element, int timeToWait) {
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(timeToWait));
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    public WebElement waitForElementToBeVisible(By elementBy, int timeToWait) {
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(timeToWait));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(elementBy));
    }

    public WebElement waitForElementToBeVisible(String xpath, int timeToWait) {
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(timeToWait));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
    }

    public WebElement waitForElementToBeClickable(By by, int timeToWait) {
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(timeToWait));
        return wait.until(ExpectedConditions.elementToBeClickable(by));
    }

    public WebElement waitForElementToBeClickable(WebElement element, int timeToWait) {
        WebDriverWait wait = new WebDriverWait(driver, ofSeconds(timeToWait));
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public void waitForAnyTextToBePresent(WebElement element) {
        wait.until((ExpectedCondition<Boolean>) driver ->
                element.getText().length() != 0);
    }

    public void waitForAnyValueToBePresent(WebElement element) {
        wait.until((ExpectedCondition<Boolean>) driver ->
                element.getAttribute("value").length() != 0);
    }

    public void waitForBackgroundColor(By by, Colors color) {
        int waitTime = DEFAULT_TIMEOUT_SECONDS;
        String actualColor;
        while (!(actualColor = getColorOrEmpty(by)).equals(color.toString()) && waitTime-- > 0) {
            Sleep.seconds(1);
        }
        assertThat(actualColor).as("Element not in correct color").isEqualTo(color.toString());
    }

    private String getColorOrEmpty(By by) {
        try {
            return driver.findElement(by).getCssValue("background-color");
        } catch (StaleElementReferenceException e) {
            return "";
        }
    }

    public void waitForPageLoaded() {
        wait.until((ExpectedCondition<Boolean>) wd ->
                ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
        Sleep.seconds(1);
    }

    public void waitForElementToBeNotVisible(WebElement element) {
        wait.until(ExpectedConditions.invisibilityOf(element));
    }

    public void waitForElementToBeNotVisible(By by) {
        wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
    }
}
