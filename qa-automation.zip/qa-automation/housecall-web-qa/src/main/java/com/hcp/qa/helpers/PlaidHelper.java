package com.hcp.qa.helpers;

import org.openqa.selenium.WebDriver;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.TabManager;
import com.hcp.qa.pages.payment.plaid.PlaidAccountIds;
import com.hcp.qa.pages.payment.plaid.PlaidDialog;
import com.hcp.qa.pages.payment.plaid.PlaidPage;
import com.hcp.qa.pages.payment.plaid.PlaidSignInPage;

import lombok.extern.slf4j.Slf4j;

import static com.hcp.qa.pages.payment.plaid.PlaidAccountIds.CHECKING;

@Slf4j
public class PlaidHelper {

	WebDriver driver;

	private final String plaidBank = ConfigHandler.getStringPropertyValueFromKey("hcp.web.plaid.bank");
	private final String plaidUser = ConfigHandler.getStringPropertyValueFromKey("hcp.web.plaid.user");
	private final String plaidPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.web.plaid.password");

	public PlaidHelper(WebDriver driver) {
		this.driver = driver;
	}

	public void connectChaseCheckingAccount() {
		PlaidDialog plaidDialog = new PlaidDialog(driver)
				.switchToDialogFrame()
				.clickContinue()
				.selectBankName(plaidBank)
				.clickContinue()
				.switchToMainFrame();
		
		loginInPlaidAndConnectAccountInformation(CHECKING);
		
		plaidDialog
				.switchToDialogFrame()
				.selectAccount("Plaid Checking")
				.clickContinue()
				.clickContinue()
				.switchToMainFrame();
	}

	private void loginInPlaid() {
		new PlaidSignInPage(driver)
				.enterUsername(plaidUser)
				.enterPassword(plaidPassword)
				.clickSignIn()
				.clickGetCode()
				.submitCode();
	}

	private void connectAccountInformation(PlaidAccountIds accountId) {
		new PlaidPage(driver)
				.clickAccountCheckbox(accountId)
				.clickContinue()
				.clickTermsAndCondition()
				.clickConnectAccountInformation();
	}
	
	private void loginInPlaidAndConnectAccountInformation(PlaidAccountIds accountId) {
		String my_moneyTab = driver.getWindowHandle();
		TabManager tabManager=new TabManager(driver);
		String loginPlaidTab = tabManager.switchToLatestTab(my_moneyTab);
		
		loginInPlaid();
		connectAccountInformation(accountId);
		tabManager.switchToLatestTab(loginPlaidTab);
	}
			
}
