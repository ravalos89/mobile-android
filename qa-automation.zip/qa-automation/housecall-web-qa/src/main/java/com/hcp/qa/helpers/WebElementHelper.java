package com.hcp.qa.helpers;

import static java.lang.String.format;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class WebElementHelper {

    private final WebDriver driver;
    private final WaitHelper waitHelper;

    public WebElementHelper(WebDriver driver) {
        this.driver = driver;
        this.waitHelper = new WaitHelper(driver);
    }

    public void click(WebElement element) {
        try {
            element.click();
        }
        catch (WebDriverException e) {
            waitHelper.waitForElementToBeClickable(element);
            element.click();
        }
    }

    public void click(WebElement element, int customTimeoutSeconds) {
        try {
            element.click();
        }
        catch (WebDriverException e) {
            waitHelper.waitForElementToBeClickable(element, customTimeoutSeconds);
            element.click();
        }
    }

    public void click(By by) {
        try {
            driver.findElement(by).click();
        }
        catch (WebDriverException e) {
            waitHelper.waitForElementToBeClickable(by);
            driver.findElement(by).click();
        }
    }

    public void click(By by, int customTimeoutSeconds) {
        try {
            driver.findElement(by).click();
        }
        catch (WebDriverException e) {
            waitHelper.waitForElementToBeClickable(by, customTimeoutSeconds);
            driver.findElement(by).click();
        }
    }

    public void click(String xpathTemplate, Object... arg) {
        By by = By.xpath(format(xpathTemplate, arg));
        click(by);
    }

    public void type(WebElement element, String text) {
        waitHelper.waitForElementToBeClickable(element);
        typeInElement(element, text);
    }

    public void type(WebElement element, String text, int customTimeoutSeconds) {
        waitHelper.waitForElementToBeClickable(element, customTimeoutSeconds);
        typeInElement(element, text);
    }

    public void type(By by, String text) {
        waitHelper.waitForElementToBeClickable(by);
        WebElement element = driver.findElement(by);
        typeInElement(element, text);
    }

    private void typeInElement(WebElement element, String text) {
        element.clear();
        element.sendKeys(text);
    }

    public String getText(WebElement element) {
        waitHelper.waitForElementToBeVisible(element);

        return getTextFromElement(element);
    }

    public String getText(By by) {
        waitHelper.waitForElementToBeVisible(by);
        WebElement element = driver.findElement(by);

        return getTextFromElement(element);
    }

    private String getTextFromElement(WebElement element) {
        waitHelper.waitForAnyTextToBePresent(element);

        return element.getText();
    }

    public String getAttributeValue(WebElement element) {
        waitHelper.waitForElementToBeVisible(element);

        return element.getAttribute("value");
    }
    
    public boolean isDisplayed(By by) {
        waitHelper.waitForPageLoaded();
        return !driver.findElements(by).isEmpty();
    }

    public boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public void hoverOn(By by) {
        Actions actions = new Actions(driver);
        WebElement element = driver.findElement(by);
        actions.moveToElement(element).perform();
    }

    public boolean isEnabled(By by) {
        try {
            WebElement element = driver.findElement(by);
            return element.isEnabled();
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}
