package com.hcp.qa.helpers;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalendarHelper {

	private static CalendarHelper instance;

	private CalendarHelper() {
	}

	public static CalendarHelper getInstance() {
		if (instance == null)
			instance = new CalendarHelper();
		return instance;
	}

	public String formatDate(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("MMM dd");
		String weekStartDay = format.format(date);
		return weekStartDay;
	}

	public String expectedDateInFormat(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("MMM dd yyyy");
		String weekStartDay = format.format(date);
		return weekStartDay;
	}

	public Date getWeekStartDate() {
		Calendar calendar = Calendar.getInstance();
		while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
			calendar.add(Calendar.DATE, -1);
		}
		return calendar.getTime();
	}

	public Date getWeekEndDate() {
		Calendar calendar = Calendar.getInstance();
		if(calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			calendar.add(Calendar.DATE, 6);
			return calendar.getTime();
		}
		while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
			calendar.add(Calendar.DATE, 1);
		}
		calendar.add(Calendar.DATE, -1);
		return calendar.getTime();
	}

	public Date get2WeekStartDate() {
		Calendar calendar = Calendar.getInstance();
		while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
			calendar.add(Calendar.DATE, -1);
		}
		calendar.add(Calendar.DATE, -7);
		return calendar.getTime();
	}

	public Date getMonthStartDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
		return cal.getTime();
	}

	public Date getMonthEndDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DATE));
		return cal.getTime();
	}

	public Date getYearStartDate() {
		Calendar cal = new GregorianCalendar();
		cal.set(Calendar.DAY_OF_YEAR, 1);
		return cal.getTime();
	}

	public Date getYearEndDate() {
		Calendar cal = new GregorianCalendar();
		cal.set(Calendar.DAY_OF_YEAR, 365);
		return cal.getTime();
	}

	public String getTodayDay() {
		Calendar cal = Calendar.getInstance();
		String dayWeekText = new SimpleDateFormat("EEEE").format(cal.getTime());
		return dayWeekText;
	}

	public String getnextYearDateInMMMMdyyyy() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, 365);
		Date date=calendar.getTime();
		SimpleDateFormat format = new SimpleDateFormat("MMMM d, yyyy");
		String todaydate = format.format(date);
		return todaydate;
	}

	@SuppressWarnings("deprecation")
	public int getDayOfMonth() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime().getDate();
	}

	public String getCurrentMonth() {
		Calendar calendar = Calendar.getInstance();
		Date date=calendar.getTime();
		SimpleDateFormat format = new SimpleDateFormat("MMMM");
		String currentMonth = format.format(date);
		return currentMonth;
	}
	
	public String getTodayDateInyyyyMMdd() {
		Calendar cal= Calendar.getInstance();
		Date date=cal.getTime();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
		String todayDateVal = format.format(date);
		return todayDateVal;
	}

}
