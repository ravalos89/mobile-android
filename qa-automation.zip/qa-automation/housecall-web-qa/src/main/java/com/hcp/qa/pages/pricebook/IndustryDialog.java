package com.hcp.qa.pages.pricebook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.PageUtils;

public class IndustryDialog extends AddImageDialog{
	
	@FindBy(xpath="//div[starts-with(@class,'MuiSelect')]")
	WebElement industrySelectBox;
			
	public IndustryDialog(WebDriver driver) {
		super(driver);
	}
	
	public void selectIndustry(String industry) {
		PageUtils.scrollAndSelectTextFromDropDown(driver, industrySelectBox, industry);
	}

}

