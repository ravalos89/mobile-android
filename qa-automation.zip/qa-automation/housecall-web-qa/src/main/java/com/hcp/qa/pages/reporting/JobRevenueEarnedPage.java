package com.hcp.qa.pages.reporting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobRevenueEarnedPage extends ReportChartPage {

	
	@FindBy(xpath="//div[contains(text(),'Last 45 days')]")
	WebElement last45DaysBtn;

	@FindBy(xpath="//div[contains(text(),'Scheduled date')]")
	WebElement scheduledBtn;

	@FindBy(xpath="//button//span[contains(text(),'EXPORT')]/parent::*/parent::*")
	WebElement exportBtn;

	@FindBy(xpath="//button//span[contains(text(),'Manage Filters')]")
	WebElement manageFiltersBtn;

	@FindBy(xpath="//button//span[contains(text(),'Edit columns')]")
	WebElement editColumnBtn;

	@FindBy(xpath="//table//span[contains(text(),'Day')]")
	WebElement dayColumn;

	@FindBy(xpath="//table//h6[contains(text(),'Job revenue')]")
	WebElement jobRevenueColumn;


	public JobRevenueEarnedPage(WebDriver driver) {
		super(driver);
	}

	public void clickOnPage() { element.click(page); }

	public void clickDateRange() { element.click(last45DaysBtn); }

	public void clickActionDate() { element.click(scheduledBtn); }
	
	public boolean isEditColumnDisplayed() { return element.isDisplayed(editColumnBtn); }

	public boolean isJobRevenueColumnDisplayed() { return element.isDisplayed(jobRevenueColumn); }

	public boolean isDayColumnDisplayed() { return element.isDisplayed(dayColumn); }

}
