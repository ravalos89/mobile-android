package com.hcp.qa.pages.inbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class InboxPage extends Page{

	@FindBy(xpath="//div[contains(text(),'Community')]")
	private WebElement community;
	
	public InboxPage(WebDriver driver) {
		super(driver);
	}

	public boolean isCommunityDisplayed()
	{
		waitForPageToLoad(1);
		return community.isDisplayed();
	}
}
