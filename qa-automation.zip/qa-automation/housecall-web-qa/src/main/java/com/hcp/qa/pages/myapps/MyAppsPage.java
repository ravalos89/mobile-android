package com.hcp.qa.pages.myapps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.pages.common.Page;

public class MyAppsPage extends Page{
	@FindBy(xpath="//span[contains(.,'Go to App store')]")
	WebElement appStoreLink;

	@FindBy(xpath="//a[contains(.,'Checklists')]")
	WebElement checklists;
	
	@FindBy(xpath="//a[contains(.,'Timesheet')]")
	WebElement timesheet;
	
	@FindBy(xpath="//a[contains(.,'Service plans')]")
	WebElement servicePlan;
	
	public MyAppsPage(WebDriver driver) {
		super(driver);
	}
	
	public void clickGoToAppStore()
	{
		appStoreLink.click();
	}
	
	public boolean isAppsTitleVisible()
	{
		return driver.findElement(By.xpath("//h4[contains(.,'Apps')]")).isDisplayed();
	}
	
	public void clickChecklists()
	{
		checklists.click();
	}

	public void clickTimeSheet() {
		timesheet.click();
		waitForPageToLoad(2);
	}

	public void clickServicePlan() {
		servicePlan.click();
		waitForPageToLoad(2);
	}
	

}
