package com.hcp.qa.web.reporting;

import java.util.List;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.reports.ReportUtils;
import com.hcp.qa.web.BaseWebTest;

public class LeadsDefatulOptionsTest extends BaseWebTest{
	
	DashboardPage dashboard;
	LeadsPage leadsPage;
	ReportUtils reportUtils;
	LeftMenuWidget leftMenuWidget;
	ReportingHelper reportingHelper = new ReportingHelper();

	@BeforeTest
	public void loginHCP() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		reportUtils = new ReportUtils();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickLeads();

	}
	
	@Test
	public void verifyDefaultOptionsForLeads() {
		List<String> actualEmployeeOptions = leadsPage.getEmployeeSectionOptions();
		List<String> expectedEmployeeOptions = reportingHelper.getExpectedEmployeeOptionsLeads();
		reportingHelper.verifyOptions(actualEmployeeOptions, expectedEmployeeOptions);
		
		List<String> actualDateOptions = leadsPage.getDateSectionOptions();
		List<String> expectedDateOptions = reportingHelper.getExpectedDateOptionsLeads();
		reportingHelper.verifyOptions(actualDateOptions, expectedDateOptions);
		
		
		if(!leadsPage.isCreateReportDisplayed()) {
			reportUtils.fail("buttons is not in the page");
			}
		
	}
	


}
