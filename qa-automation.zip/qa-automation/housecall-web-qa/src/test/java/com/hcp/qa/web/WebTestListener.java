package com.hcp.qa.web;

import org.testng.ITestResult;

import com.hcp.qa.testng.CustomTestListener;

import static com.hcp.qa.testng.LogHelper.log;
import static com.hcp.qa.testng.LogHelper.logHcpStackTrace;
import static com.hcp.qa.testng.LogHelper.printLine;

public class WebTestListener extends CustomTestListener {
	
	@Override
	public void onTestFailure(ITestResult result) {
		BaseWebTest.takeScreenShot(result.getName() + "_FAILED");

		if (result.getThrowable().getMessage() != null) {
			log(result.getName() + " FAILED  with following Exception\n"
					+ result.getThrowable().getMessage());
		}
		logHcpStackTrace(result);
		printLine();
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		if (isSkippedByBeforeMethod(result)) {
			return;
		}

		BaseWebTest.takeScreenShot(result.getName() + "_SKIPPED");
		log(result.getName() + " SKIPPED  with following Exception\n"
				+ result.getThrowable().getMessage());
		logHcpStackTrace(result);
		printLine();
	}

	private boolean isSkippedByBeforeMethod(ITestResult result) {
		return !result.getSkipCausedBy().isEmpty();
	}
}
