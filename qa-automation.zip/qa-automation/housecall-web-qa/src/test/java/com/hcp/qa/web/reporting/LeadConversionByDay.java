package com.hcp.qa.web.reporting;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeadConversionByDayPage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.web.BaseWebTest;

public class LeadConversionByDay extends BaseWebTest {

	private DashboardPage dashboard;
	private LeadsPage leadsPage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private LeadConversionByDayPage leadConversionByDayPage;
	private LeftMenuWidget leftMenuWidget;

	@BeforeTest
	public void loginHCP() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		leadConversionByDayPage = new LeadConversionByDayPage(driver);
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickLeads();
		Assert.assertTrue(leadsPage.isCreateReportDisplayed(),"button is not in the page");
	}

	@Test
	public void verifyOptionsConversionByDay() {
		leadsPage.openDateOption("Lead conversion by day");
		leadConversionByDayPage.clickDateRange();
		reportingHelper.verifyOptions(leadConversionByDayPage.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsLeads());
		leadConversionByDayPage.clickOnPage();
		leadConversionByDayPage.clickActionDate();
		reportingHelper.verifyOptions(leadConversionByDayPage.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsLeads());
		leadConversionByDayPage.clickOnPage();
	}


}
