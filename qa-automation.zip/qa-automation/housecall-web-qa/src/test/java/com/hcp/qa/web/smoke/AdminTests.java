package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.AdminHelper;
import com.hcp.qa.pages.admin.CompaniesListPage;
import com.hcp.qa.pages.admin.OldAdminPage;
import com.hcp.qa.web.BaseWebTest;

public class AdminTests extends BaseWebTest {

	private AdminHelper adminHelper;

	@BeforeClass
	public void setUp() {
		adminHelper = new AdminHelper(driver);
		adminHelper.login();
	}

	@Test(priority=1)
	public void checkOldAdminPage() {
		adminHelper.goToOldAdminPage();
		OldAdminPage oldAdmin = new OldAdminPage(driver);
		Assert.assertTrue(oldAdmin.isTitleDisplayed(), "The old admin page did not display correctly");
	}

	@Test(priority=2)
	public void checkNewAdminPage() {
		adminHelper.goToAdminPage();
		CompaniesListPage companyList = new CompaniesListPage(driver);
		Assert.assertTrue(companyList.isTitleDisplayed(), "The companies page on admin Ui did not display correctly");
	}
	
	@Test(dependsOnMethods = "checkNewAdminPage")
	public void searchEmployee() {
		String email="qa+adminsearchemp@housecallpro.com";
		String employeeName="Test Admin Employee";
		CompaniesListPage companyList = new CompaniesListPage(driver);
		companyList.searchForEmployee(email);
		companyList.clickExpandIcon();
		Assert.assertEquals(companyList.getEmployeeEmail(), email, "Employee email on admin Ui did not display correctly");
		Assert.assertEquals(companyList.getEmployeeName(), employeeName, "Employee name on admin Ui did not display correctly");
		
	}

}
