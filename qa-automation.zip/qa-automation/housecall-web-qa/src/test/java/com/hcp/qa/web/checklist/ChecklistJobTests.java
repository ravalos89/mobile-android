package com.hcp.qa.web.checklist;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.gmail.AttachmentUtils;
import com.hcp.qa.gmail.EmailMessage;
import com.hcp.qa.gmail.GmailMessageClient;
import com.hcp.qa.helpers.PaymentHelper;
import com.hcp.qa.models.Job;
import com.hcp.qa.pages.checklist.AttachmentsDialog;
import com.hcp.qa.pages.checklist.ChecklistPage;
import com.hcp.qa.pages.checklist.EditChecklistPage;
import com.hcp.qa.pages.common.DeleteDialog;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.customer.JobsTab;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.invoice.InvoiceSettingsPage;
import com.hcp.qa.pages.job.EditJobChecklistPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.FinishJobWidget;
import com.hcp.qa.pages.myapps.MyAppsPage;
import com.hcp.qa.pages.navigation.TopNavigationWidget;
import com.hcp.qa.pages.navigation.TopNavigationWidgetFactory;
import com.hcp.qa.web.BaseWebTest;

public class ChecklistJobTests extends BaseWebTest {

	Job job;
	String checklistName = "Auto Test Checklist";
	protected PaymentHelper paymentHelper;

	@BeforeMethod
	public void setup() {
		loginHelper.login();
		//FIXME: Take out refresh once DT-458 is fixed 
		driver.navigate().refresh();
		
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.waitForPageToLoad(1);
		goToChecklistsPage();
		deleteAllChecklists();
		ChecklistPage checklists = new ChecklistPage(driver);
		checklists.clickAddChecklist();
		EditChecklistPage checklist = new EditChecklistPage(driver);
		checklist.enterChecklistName(checklistName);
		checklist.enterChecklistItem(0, "Checkbox", "Test Checkbox Item");
		checklist.clickNext();
		checklist.clickSave();
	}

	@Test
	public void checklistPreventFinishJob() {
		setPreventJobCompletion(true);
		createJobWithChecklist();
		String errorMsg = "Complete outstanding checklist items before finishing the Job.";
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForChecklistMessageToClear();
		editJob.waitForPageToLoad(1);

		FinishJobWidget finishJob = editJob.clickFinishJob();
		finishJob.clickFinish();
		Assert.assertTrue(editJob.searchForText(errorMsg), "Error for incomplete checklist not displayed");
		editJob.dismissChecklistError();

	}

	@Test
	public void completeCheckListFinishJob() {
		setPreventJobCompletion(true);
		createJobWithChecklist();
		EditJobPage editJob = new EditJobPage(driver);
		editJob.clickCheckList(checklistName);
		EditJobChecklistPage checklist = new EditJobChecklistPage(driver);
		checklist.clickCheckbox();
		checklist.clickSave();
		Assert.assertTrue(editJob.searchForText("complete"), "Checklist not marked complete");

		FinishJobWidget finishJob = editJob.clickFinishJob();
		finishJob.clickFinish();
		Assert.assertTrue(editJob.searchForText("UNDO"), "Job not marked Finished ");
	}

	@Test
	public void checklistFinishJob() {
		createJobWithChecklist();
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForChecklistMessageToClear();
		editJob.waitForPageToLoad(1);
		FinishJobWidget finishJob = editJob.clickFinishJob();
		finishJob.clickFinish();
		Assert.assertTrue(editJob.searchForText("UNDO"), "Job not marked Finished ");
	}

	@Test
	public void removeChecklistFromJob() {
		createJobWithChecklist();
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(3);

		editJob.clickCheckList(checklistName);
		EditJobChecklistPage checklist = new EditJobChecklistPage(driver);
		checklist.removeCheckList();
		editJob.waitForPageToLoad(1);
		editJob = new EditJobPage(driver);
		Assert.assertFalse(editJob.isChecklistPresent(checklistName), "Checklist is present even after deleting");
	}

	@Test
	public void checklistExistsInJobAfterDelete() {
		createJobWithChecklist();
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(3);
		goToChecklistsPage();
		deleteChecklist();

		customerHelper.searchAndSelectCustomer(customer);
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		JobsTab jobs = customerDetails.clickJobs();
		jobs.clickOnJob(job.getInvoiceNumber());
		editJob = new EditJobPage(driver);
		Assert.assertTrue(editJob.searchForText(checklistName), "Checklist not found on job page");
	}

	@Test
	public void verifyCheckListAttachmentInEmail() {
		createJobWithChecklist();

		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(3);
		editJob.clickCheckList(checklistName);
		EditJobChecklistPage checklist = new EditJobChecklistPage(driver);
		checklist.clickCheckbox();
		checklist.clickSave();

		sendInvoiceWithChecklistAttached();
		verifyEmailAttachment();
	}

	private void sendInvoiceWithChecklistAttached() {
		EditJobPage editJob = new EditJobPage(driver);
		editJob.waitForPageToLoad(3);
		editJob.clickSendInvoice();
		editJob.waitForPageToLoad(1);

		InvoiceSettingsPage invoiceSettings = new InvoiceSettingsPage(driver);
		invoiceSettings.clickAttachments();

		AttachmentsDialog AttachmentsDialog = new AttachmentsDialog(driver);
		AttachmentsDialog.clickChecklistsTab();
		EditJobChecklistPage checklist = new EditJobChecklistPage(driver);
		checklist.clickCheckboxChecklist();
		AttachmentsDialog.clickAttachBtn();

		invoiceSettings.clickNext();
		invoiceSettings.clickSend();
	}

	private void verifyEmailAttachment() {

		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
		String attachmentName = "checklists_" + job.getInvoiceNumber() + ".pdf";
		EmailMessage checklistEmail = gmailClient.getEmailWithAttachments(attachmentName, WAIT_TIME_FOR_EMAIL, true);
		Assert.assertTrue(checklistEmail.isAttachmentPresent(attachmentName));

		File attachment = checklistEmail.getAttachmentFile(attachmentName);
		String pdfText = AttachmentUtils.getTextFromPdf(attachment);
		AttachmentUtils.deleteFiles(checklistEmail.getAttachments());

		Assert.assertNotEquals(pdfText, "", "The pdf is blank. ");
		Assert.assertTrue(pdfText.contains(checklistName), "Checklist Name not present in the PDF");
	}

	private void createJobWithChecklist() {
		job = jobHelper.createJob(customer);
		EditJobPage editJob = new EditJobPage(driver);
		editJob.clickAddChecklists();
		ChecklistPage checklists = new ChecklistPage(driver);
		checklists.waitForPageToLoad(1);
		checklists.selectChecklist(checklistName);
		checklists.clickAddSelected();

	}

	private void setPreventJobCompletion(boolean preventJobFinish) {
		goToChecklistsPage();
		ChecklistPage checklists = new ChecklistPage(driver);
		checklists.waitForPageToLoad(2);
		checklists.editChecklist(checklistName);
		EditChecklistPage editChecklist = new EditChecklistPage(driver);
		editChecklist.clickNext();
		editChecklist.waitForPageToLoad(1);
		editChecklist.togglePreventJobFinish(preventJobFinish);
		editChecklist.clickUpdate();
	}

	private void goToChecklistsPage() {
		TopNavigationWidget topMenu = TopNavigationWidgetFactory.createTopNavigationWidget(driver);
		topMenu.clickMyApps();
		MyAppsPage myApps = new MyAppsPage(driver);
		myApps.clickChecklists();
	}

	private void deleteChecklist() {
		goToChecklistsPage();
		ChecklistPage checklists = new ChecklistPage(driver);
		checklists.editChecklist(checklistName);
		EditChecklistPage checklist = new EditChecklistPage(driver);
		checklist.deleteCheckList();
		DeleteDialog deleteDialog = new DeleteDialog(driver);
		deleteDialog.clickDelete();

	}

	private void deleteAllChecklists() {
		goToChecklistsPage();
		ChecklistPage checklists = new ChecklistPage(driver);
		while (checklists.searchForText(checklistName)) {
			deleteChecklist();
		}
	}

	@AfterMethod
	public void cleanUp() {
		deleteAllChecklists();
	}

}
