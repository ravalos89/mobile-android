package com.hcp.qa.web.serviceplan;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.hcp.qa.common.Sleep;
import com.hcp.qa.common.TabManager;
import com.hcp.qa.helpers.CalendarHelper;
import com.hcp.qa.helpers.PaymentHelper;
import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.serviceplan.AddServicePlanToCustomerPage;
import com.hcp.qa.pages.serviceplan.CustomerServiceAgreementsOnHCPClientPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPaymentsWidget;
import com.hcp.qa.pages.serviceplan.HCPClientLoginPage;
import com.hcp.qa.pages.serviceplan.HCPClientReviewAndConfirmPlanPage;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.web.BaseWebTest;


public class ServicePlanCustomerTests extends BaseWebTest {
	String planName = "Test Service Plan";
	static String customerId;
	ServicePlanHelper servicePlanHelper;
	public String billingAmount = "52.08";
	String customerGmailPassword= "qa@Hcp1234";
	
	@BeforeClass
	public void setUp() {
		loginHelper.login();
		driver.navigate().refresh();
		servicePlanHelper = new ServicePlanHelper(driver);
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
		servicePlanHelper.addServicePlan(planName);		
		customerId = customerHelper.createCustomer(customer).getId();
	}
	
	@Test
	public void sendServicePlanToCustomerEmail() {
		navigationHelper.goToCustomer(customerId);
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddServicePlan();

		AddServicePlanToCustomerPage addPlanToCustomer = new AddServicePlanToCustomerPage(driver);
		addPlanToCustomer.searchAndSelectPlan(planName);
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickAdd();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickSend();
		addPlanToCustomer.confirmSendEmail();		
		
		ServicePlanSummaryPage planSummary=new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isEmailSentMessage(),
				"Service plan email sent message not present");
		planSummary.waitForPageToLoad(1);		
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your service agreement for Housecall Pro QA",false,
				"You have received a service agreement","VIEW MY AGREEMENT");	
	}
	
	@Test(dependsOnMethods = "sendServicePlanToCustomerEmail")
	public void customerAcceptServicePlanFromEmail() {
		String mainHcpWindow = driver.getWindowHandle();
		Sleep.seconds(5);
		
		String servicePlanUrl = servicePlanHelper.getServicePlanViewAgreementUrl();
		Assert.assertNotNull(servicePlanUrl, "Service plan Url is Null. Check if service plan acceptance email was received");
		
		TabManager tabManager = new TabManager(driver);
		String reviewTab = tabManager.switchToNewTab(servicePlanUrl);
		
		ServicePlanHelper planHelper = new ServicePlanHelper(driver);
		planHelper.createAccountToViewPlanFromEmail();
		
		CustomerServicePlanPaymentsWidget servicePlanCreditCardPage = new CustomerServicePlanPaymentsWidget(driver);		
		PaymentHelper paymentHelper=new PaymentHelper(driver);
		paymentHelper.fillCreditCardDetailsWithZip();
		servicePlanCreditCardPage.waitForPageToLoad(2);

		HCPClientReviewAndConfirmPlanPage confirmPlanPage = new HCPClientReviewAndConfirmPlanPage(driver);
		confirmPlanPage.clickConfirmPlan();
		
		CustomerServiceAgreementsOnHCPClientPage confirmPlan = new CustomerServiceAgreementsOnHCPClientPage(driver);
		confirmPlan.verifyServicePlan(planName);
		
		tabManager.closeTabAndSwitchtoAnother(reviewTab, mainHcpWindow);
				
		servicePlanHelper.verifyServiceAgreementEmailReceived("has accepted your service agreement",false, 
				"Your customer has agreed to the following plan:","");
		
		Sleep.seconds(2);
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your plan is now active",false,
				"is now active","MANAGE MY PLAN");	
	}	
	
	@Test(dependsOnMethods = "customerAcceptServicePlanFromEmail")
	public void customerManageServicePlanFromEmail() {
		String mainHcpWindow = driver.getWindowHandle();
		Sleep.seconds(5);

		String managePlanUrl = servicePlanHelper.getManagePlanUrl();
		Assert.assertNotNull(managePlanUrl, "Manage plan Url is Null. Check if service plan	acceptance email was received");
		
		TabManager tabManager = new TabManager(driver);
		String reviewTab = tabManager.switchToNewTab(managePlanUrl);
		
		
		HCPClientLoginPage clientLoginPage = new HCPClientLoginPage(driver);
		clientLoginPage.signInHcpClient(customer.getEmail(),customerGmailPassword);
		
		SoftAssert assertions = new SoftAssert();
		CustomerServiceAgreementsOnHCPClientPage serviceAgreementsPage = new CustomerServiceAgreementsOnHCPClientPage(driver);
		assertions.assertTrue(serviceAgreementsPage.verifyServicePlan(planName));
		assertions.assertTrue(serviceAgreementsPage.verifyServicePlanPaymentStatus());
		assertions.assertEquals(serviceAgreementsPage.verifyServicePlanAmount(),"$"+billingAmount);
		assertions.assertEquals(CalendarHelper.getInstance().getTodayDateInyyyyMMdd(),serviceAgreementsPage.getBillingDate());
		assertions.assertAll("Service plan email manage plan assertions failed");
		 
		tabManager.closeTabAndSwitchtoAnother(reviewTab, mainHcpWindow);
	}	
	
	@Test
	public void addServicePlanToCustomerAlreadyAcceptedAndPaid() {
		navigationHelper.goToCustomer(customerId);
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddServicePlan();

		AddServicePlanToCustomerPage addPlanToCustomer = new AddServicePlanToCustomerPage(driver);
		addPlanToCustomer.searchAndSelectPlanWithPreviousDate(planName);
		addPlanToCustomer.selectAcceptPlanForCustomer();
		addPlanToCustomer.selectAlreadyPaid();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickAdd();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickFinish();
		addPlanToCustomer.clickAcceptPlan();		

		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");

		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		customerServicePlan.clickBack();
	}
	
	@AfterClass
	private void cleanUp() {
		customerHelper.deleteAllCustomers(customerId);
		loginHelper.logout();
	}
}
