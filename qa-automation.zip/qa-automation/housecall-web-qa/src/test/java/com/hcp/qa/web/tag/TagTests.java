package com.hcp.qa.web.tag;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.pages.common.SettingsPage;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.tag.AddTagDialog;
import com.hcp.qa.pages.tag.DeleteTagDialog;
import com.hcp.qa.pages.tag.EditTagDialog;
import com.hcp.qa.pages.tag.MergeTagDialog;
import com.hcp.qa.pages.tag.TagListPage;
import com.hcp.qa.web.BaseWebTest;

public class TagTests extends BaseWebTest {

	@BeforeClass
	public void loginAndGoToAccountSettingsPage() {
		DashboardPage dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickAccountSettingsFromProfile();
		SettingsPage settings = new SettingsPage(driver);
		settings.clickTagsIcon();
	}

	@Test
	public void addTag() {
		TagListPage tagList = new TagListPage(driver);
		String tagName = "CreateTag";
		createTag(tagName);
		Assert.assertTrue(tagList.searchForText(tagName), "Newly created tag not found");
		deleteTag(tagName);
	}

	@Test()
	public void deleteTag() {
		String tagName ="DelTag";
		createTag(tagName);
		TagListPage tagList = new TagListPage(driver);
		
		deleteTag(tagName);
		Assert.assertFalse(tagList.searchForText(tagName), "Deleted tag name is still displayed");
	}

	@Test
	public void duplicateTag() {
		String tagName = "DuplicateTag";
		createTag(tagName);
		TagListPage tagList = new TagListPage(driver);

		tagList.clickAddTag();
		AddTagDialog addTagDialog = new AddTagDialog(driver);
		addTagDialog.enterTagName(tagName);
		addTagDialog.clickSave();
		Assert.assertTrue(addTagDialog.isErrorMessageDisplayed(), "Error message not displayed for duplicate tag");
		addTagDialog.clickCancel();
		deleteTag(tagName);
	}

	@Test
	public void editTag() {
		String tagName = "UpdateTag";
		createTag(tagName);

		TagListPage tagList = new TagListPage(driver);
		tagList.clickEdit(tagName);
		EditTagDialog editTagDialog = new EditTagDialog(driver);

		String updatedTagName = tagName + "updated";
		editTagDialog.enterTagName(updatedTagName);
		editTagDialog.clickSave();
		driver.navigate().refresh();
		tagList.enterSearch(updatedTagName);
		tagList.waitForPageToLoad(1);
		Assert.assertTrue(tagList.searchForText(updatedTagName), "Updated tag name not found");
		deleteTag(updatedTagName);
	}

	@Test
	public void mergeTag() {
		String tag1 = "MergeTag1";
		createTag(tag1);

		String tag2 = "MergeTag2";
		createTag(tag2);
		
		driver.navigate().refresh();
		
		TagListPage tagList = new TagListPage(driver);
		tagList.waitForPageToLoad(1);
		tagList.selectCheckBoxByTagName(tag1);
		tagList.selectCheckBoxByTagName(tag2);
		tagList.clickMerge();

		MergeTagDialog mergeTagDialog = new MergeTagDialog(driver);
		String mergedTagName = "MergedTag";
		mergeTagDialog.enterTagName(mergedTagName);
		mergeTagDialog.clickMergeTag();
		driver.navigate().refresh();
		tagList.waitForPageToLoad(1);
		tagList.enterSearch(mergedTagName);
		tagList.waitForPageToLoad(1);
		Assert.assertTrue(tagList.searchForText(mergedTagName), "Merged tag name not found");
		deleteTag(mergedTagName);
	}

	@Test
	public void searchTag() {
		String tagName = "SearchTag";
		createTag(tagName);

		TagListPage tagList = new TagListPage(driver);
		tagList.enterSearch(tagName);
		tagList.waitForPageToLoad(1);
		Assert.assertTrue(tagList.searchForText(tagName), "Searched tag not found");
		deleteTag(tagName);
	}

	private void createTag(String tag) {
		TagListPage tagList = new TagListPage(driver);
		tagList.clickAddTag();
		AddTagDialog addTagDialog = new AddTagDialog(driver);
		addTagDialog.enterTagName(tag);
		addTagDialog.clickSave();
		driver.navigate().refresh();
		tagList.waitForPageToLoad(1);
		tagList.enterSearch(tag);
		tagList.waitForPageToLoad(1);
	}

	private void deleteTag(String tag) {
		TagListPage tagList = new TagListPage(driver);
		tagList.enterSearch(tag);
		tagList.waitForPageToLoad(1);
		tagList.delete(tag);
		DeleteTagDialog deleteDialog = new DeleteTagDialog(driver);
		deleteDialog.clickDelete();
		driver.navigate().refresh();
		tagList.waitForPageToLoad(1);
	}

}
