package com.hcp.qa.web.serviceplan;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.gmail.GmailMessageClient;
import com.hcp.qa.helpers.PaymentHelper;
import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.ServicePlanTileWidget;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.ServicePlanSettingsPage;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.pages.serviceplan.ServicePlanTemplatePage;
import com.hcp.qa.pages.serviceplan.ServicePlansDashboardPage;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanTests extends BaseWebTest {
	String planName = "Test Service Plan";
	static String customerId;
	ServicePlanHelper servicePlanHelper;
	PaymentHelper paymentHelper;
	
	@BeforeClass
	public void setUp() {
		GmailMessageClient.getInstance().deleteMessages();
		loginHelper.login();
		driver.navigate().refresh();
		servicePlanHelper = new ServicePlanHelper(driver);
		customerId = customer.getId();
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();
	}

	@Test
	public void addServicePlan() {	
		servicePlanHelper.addServicePlan(planName);
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertEquals(planSummary.getServicePlanName(), planName, "Service Plan name not matched");
		Assert.assertEquals(planSummary.getVisitPerYearCount(), servicePlanHelper.visitsPerYear, "Visit per year count not matched");
		Assert.assertTrue(planSummary.getMonthlyAmount().contains(servicePlanHelper.monthlyAmount), "Monthly amount not matched");
		Assert.assertEquals(planSummary.getAddOnItemName(), servicePlanHelper.addOnItemName, "Add On Item name not matched");
		Assert.assertTrue(planSummary.getAddOnItemPrice().contains(servicePlanHelper.addedOnItemPriceOnCreatedPlan),
				"Add On Item Price not matched");
		
		servicePlanHelper.goToServicePlanPage();
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		Assert.assertTrue(servicePlansPage.validatePlanDisplayedOnServicePlans(planName),
				"Created service plan is not present in plans we offer list");
	}

	@Test(dependsOnMethods = "addServicePlan")
	public void editServicePlan() {
		servicePlanHelper.goToServicePlanPage();
		String updatedMonthlyAmount = "150";
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);		
		servicePlansPage.clickServicePlan(planName);
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		planSummary.editServicePlan();
		
		ServicePlanTemplatePage editPlanTemplate=new ServicePlanTemplatePage(driver);
		editPlanTemplate.clickNext();
		editPlanTemplate.enterMonthlyAmount(updatedMonthlyAmount);
		editPlanTemplate.clickNext();
		editPlanTemplate.clickSavePlan();
		Assert.assertEquals(planSummary.getServicePlanName(), planName, "Service Plan name not matched");
		Assert.assertTrue(planSummary.getMonthlyAmount().contains(updatedMonthlyAmount),
				"Updated Monthly amount not matched");
	}

	@Test(dependsOnMethods = "editServicePlan")
	public void addJobToCustomerWithServicePlan() {
		navigationHelper.goToCustomer(customerId);
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId, planName);
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddNewJob();
		ServicePlanTileWidget servicePlanTile = new ServicePlanTileWidget(driver);
		Assert.assertTrue(servicePlanTile.isServicePlanPresent(planName),
				"Service plan activate label not present");
		Assert.assertTrue(servicePlanTile.isVisitDueMessagePresent(),
				"Service plan visit due message not present");
		
		servicePlanTile.clickServicePlanVisit();
		servicePlanTile.selectVisit1();
		servicePlanTile.clickSave();
		Assert.assertTrue(servicePlanTile.isVisitAddedPresent(),
				"Service plan visit added not present");	
	}

	@Test(dependsOnMethods = "addJobToCustomerWithServicePlan")
	public void scheduleServicePlanVisit() {
		navigationHelper.goToCustomer(customerId);
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickActivatedServicePlan(planName);
		
		CustomerServicePlanPage visitsWidget = new CustomerServicePlanPage(driver);
		visitsWidget.clickScheduleVisit();
		visitsWidget.waitForPageToLoad(1);
		
		EditJobPage editJob = new EditJobPage(driver);
		ServicePlanTileWidget servicePlanTile = new ServicePlanTileWidget(driver);
		editJob.clickSchedule();
		visitsWidget.waitForPageToLoad(1);
		servicePlanTile.clickSave();
		visitsWidget.waitForPageToLoad(1);	
		String jobInvoiceNumber = editJob.getInvoiceNumber();
		Assert.assertTrue(servicePlanTile.isServicePlanPresent(planName),
				"Service plan activate label not present");	
		
		navigationHelper.goToCustomer(customerId);
		editCustomer.expandServicePlanField();
		editCustomer.clickActivatedServicePlan(planName);
		String servicePlanInvoiceNumber = visitsWidget.getInvoiceNumber();
		
		
		Assert.assertEquals(jobInvoiceNumber ,servicePlanInvoiceNumber ,
				"Invoice numbers are not matching");
	}
	
	@Test(dependsOnMethods = "scheduleServicePlanVisit")
	public void cancelServicePlan() {
		navigationHelper.goToCustomersListPage();
	    customerHelper.searchAndSelectCustomer(customer);
		
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickActivatedServicePlan(planName);
		CustomerServicePlanPage servicePlansPage = new CustomerServicePlanPage(driver);
		servicePlansPage.clickThreeDots();
		servicePlansPage.clickCancelServicePlan();
		servicePlansPage.cancelServicePlan();
		servicePlansPage.waitForPageToLoad(2);
		driver.navigate().back();
		driver.navigate().refresh();
		Assert.assertTrue(editCustomer.isCancelledPlanDisplayed(),
				"Created service plan is not cancelled");
		servicePlanHelper.verifyServiceAgreementEmailReceived("service agreement has been cancelled",true, 
				"Your service agreement","has been cancelled, you can sign in to view the details");
	}

	@Test(dependsOnMethods = "cancelServicePlan")
	public void deleteServicePlan() {
		servicePlanHelper.goToServicePlanPage();
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);		
		servicePlansPage.clickServicePlan(planName);
		
		ServicePlanSummaryPage plansummary = new ServicePlanSummaryPage(driver);
		plansummary.clickDeleteServicePlan();
		plansummary.deleteOrArchive();
		plansummary.waitForPageToLoad(2);
		
		Assert.assertFalse(plansummary.isPlanDisplayedOnServicePlans(planName),
				"Created service plan is not deleted in plans we offer list");
	}

	@Test(dependsOnMethods = "deleteServicePlan")
	public void scheduleRenewalServicePlanReminder() {		
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickSettings();

		ServicePlanSettingsPage servicePlanSettingsPage=new ServicePlanSettingsPage(driver);
		Assert.assertEquals(servicePlanSettingsPage.getPageHeader() ,"Service plan settings" ,
				"Sevice plan settings header is not matching");	
		
		servicePlanSettingsPage.removeAllReminders();
		servicePlansPage.waitForPageToLoad(1);
		servicePlanSettingsPage.addSendSchedulingReminder();
		servicePlanSettingsPage.addSendRenewalReminder();
		servicePlanSettingsPage.clickSaveReminder();
		servicePlansPage.clickSettings();		
		Assert.assertTrue(servicePlanSettingsPage.verifySendSchedulingReminderDisplayed() ,
				"Sevice plan Send Scheduling Reminder is not added");
		Assert.assertTrue(servicePlanSettingsPage.verifySendRenewalReminderDisplayed() ,
				"Sevice plan Send Renewal Reminder is not added");
		
		servicePlanSettingsPage.addSendSchedulingReminder();
		servicePlanSettingsPage.clickSaveReminder();
		Assert.assertTrue(servicePlanSettingsPage.verifyDuplicateErrorAlertDisplayed() ,
				"duplicate error message is not displayed");
		
		servicePlanSettingsPage.waitForPageToLoad(1);
		servicePlanSettingsPage.removeSendSchedulingReminder();
		servicePlanSettingsPage.removeSendRenewalReminder();
		servicePlanSettingsPage.clickSaveReminder();
	}

	@AfterClass
	private void cleanUp() {
		loginHelper.logout();
	}
	
}
