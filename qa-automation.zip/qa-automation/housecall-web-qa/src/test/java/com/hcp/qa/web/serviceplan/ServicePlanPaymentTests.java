package com.hcp.qa.web.serviceplan;

import static com.hcp.qa.common.ValidCreditCardData.CREDIT_CARD_NUMBER;
import static com.hcp.qa.common.ValidCreditCardData.EXPIRATION_DATE;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.common.ActivityFeedKey;
import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.helpers.PaymentHelper;
import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.models.Customer;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.payment.CreditCardInformationWidget;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPaymentsWidget;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.pages.serviceplan.ServicePlansDashboardPage;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanPaymentTests extends BaseWebTest {
	
	String planName = "Test Service Plan";
	static String customerId;
	ServicePlanHelper servicePlanHelper;
	PaymentHelper paymentHelper;
	Customer customerForCC;
	Customer customerForCheck;
	Customer customerForCash;
	
	@BeforeClass
	public void setUp() {
		loginHelper.login();
		driver.navigate().refresh();
		servicePlanHelper = new ServicePlanHelper(driver);
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
		customerForCC= customerHelper.createCustomer("CustomerCC", ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key"));
		customerForCheck= customerHelper.createCustomer("CustomerCheck", ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key"));
		customerForCash= customerHelper.createCustomer("CustomerCash", ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key"));
	}
	
	@Test
	public void acceptServicePlanForCustomerWithCC() {
		addServicePlan();
		customerId = customerForCC.getId();
		navigationHelper.goToCustomer(customerId);
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId, planName);
		
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your new service plan from Housecall Pro QA + $52.08",true,"New service plan","Using card on file");
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your receipt from Housecall Pro QA + $52.08",true,"Your receipt","");
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		customerServicePlan.clickBack();
	}

	@Test
	public void acceptServicePlanForCustomerWithCash() {
		addServicePlan();
		navigationHelper.goToCustomer(customerId);
		String customerIdForCash = customerForCash.getId();
		servicePlanHelper.acceptServicePlanForCustomerWithCash(customerIdForCash, planName);
		
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");
		
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		customerServicePlan.clickBack();
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your new service plan + $52.08",true,"New service plan","Payable by cash");
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your receipt from Housecall Pro QA + %52.08",true,"Your receipt","");
	}
	
	@Test
	public void acceptServicePlanForCustomerWithCheck() {
		addServicePlan();
		navigationHelper.goToCustomer(customerId);
		String customerIdForCheck = customerForCheck.getId();
		servicePlanHelper.acceptservicePlanForCustomerWithCheck(customerIdForCheck, planName);
		
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your new service plan + $52.08",true,"New service plan","Payable by check");
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your receipt from Housecall Pro QA + %52.08",true,"Your receipt","");
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		customerServicePlan.clickBack();
	}
	
	@Test(dependsOnMethods = "acceptServicePlanForCustomerWithCC")
	public void updateCreditCardOnServicePlan() {	
		addServicePlan();
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId, planName);
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();		
		
		CustomerServicePlanPaymentsWidget paymentWidget = new CustomerServicePlanPaymentsWidget(driver);
		paymentWidget.clickUpdateCreditCard();
		paymentWidget.enterNameOnCard("Test Credit Card");
		
		PaymentHelper paymentHelper = new PaymentHelper(driver);
		paymentHelper.fillCreditCardDetailsWithPostalCode();
		paymentWidget.waitForPageToLoad(5);
		paymentWidget.clickSave();
		Assert.assertTrue(paymentWidget.isUpdateCreditCardDisplayed(),"Update credit card is not displayed");
		
		String cardNumberAndExpiryDate = paymentWidget.getCardNumberAndExpiryDate();
		String ccNumWithExtraChars = StringUtils.substringBetween(cardNumberAndExpiryDate, "Visa", "Expires");
		Pattern pattern = Pattern.compile("\\d+");
        Matcher match = pattern.matcher(ccNumWithExtraChars);
        String cardNumberLastFourDigit = null;
        while(match.find()) {
        	cardNumberLastFourDigit = match.group();
        }
		String expiryDate = StringUtils.substringAfter(cardNumberAndExpiryDate, "Expires ").replace("/", "");
		
		Assert.assertTrue(CREDIT_CARD_NUMBER.contains(cardNumberLastFourDigit),"credit card number last 4 digit is not displayed");
		Assert.assertTrue(EXPIRATION_DATE.contains(expiryDate),"credit card expiry date is not displayed");
		Assert.assertTrue(paymentWidget.isPaymentStatusDisplayed("Paid - Credit card"),"credit card payment status is not displayed");
		
		EditJobPage editJob = new EditJobPage(driver);
		jobHelper.verifyActivityFeed(editJob.getLatestActivity(), ActivityFeedKey.CREDITCARD_UPDATED);
	}
	
	@Test(dependsOnMethods = "updateCreditCardOnServicePlan")
	public void failedPaymentOnServicePlan() {	
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);	
		customerServicePlan.clickPay();
		
		CustomerServicePlanPaymentsWidget paymentWidget = new CustomerServicePlanPaymentsWidget(driver);	
		paymentWidget.enterNameOnCard("Test Credit Card");
		
		PaymentHelper paymentHelper = new PaymentHelper(driver);
		String declinedCCNumber = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.declined.number");
		paymentHelper.fillDeclinedCreditCardDetailsWithPostalCode(declinedCCNumber);
		paymentWidget.waitForPageToLoad(1);
		
		CreditCardInformationWidget cardInfo = new CreditCardInformationWidget(driver);
		cardInfo.clickChargeCard();
		cardInfo.waitForPageToLoad(5);
		Assert.assertTrue(customerServicePlan.isServicePlanPaymentFailedDisplayed(), "Service plan failed message not present");
		customerServicePlan.clickClose();
	
		EditJobPage editJob = new EditJobPage(driver);		
		jobHelper.verifyActivityFeed(editJob.getFailedPaymentActivity(), ActivityFeedKey.CC_PAYMENT_FAILURE);
	}
	
	public void addServicePlan() {	
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.addServicePlan(planName);
		servicePlanHelper.goToServicePlanPage();
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		Assert.assertTrue(servicePlansPage.validatePlanDisplayedOnServicePlans(planName),
				"Created service plan is not present in plans we offer list");
	}
	
	@AfterClass
	private void cleanUp() {
		customerHelper.deleteCustomer(customerForCC);
		customerHelper.deleteCustomer(customerForCheck);
		customerHelper.deleteCustomer(customerForCash);
		loginHelper.logout();
	}
	

}
