package com.hcp.qa.web.reporting;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.AverageJobSizePage;
import com.hcp.qa.pages.reporting.JobCountPage;
import com.hcp.qa.pages.reporting.JobRevenueEarnedPage;
import com.hcp.qa.pages.reporting.JobTimeTrackinEmployeePage;
import com.hcp.qa.pages.reporting.JobsBusinessUnitPage;
import com.hcp.qa.pages.reporting.JobsByCustomerLeadSource;
import com.hcp.qa.pages.reporting.JobsByCustomerPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingCustomPage;
import com.hcp.qa.pages.reporting.ReportingJobsPage;
import com.hcp.qa.pages.reporting.SaveReportModalPage;
import com.hcp.qa.web.BaseWebTest;

public class SaveCustomReportTest extends BaseWebTest{
	private DashboardPage dashboard;
	private ReportingJobsPage reportingJobs;
	private JobRevenueEarnedPage jobRevenueEarnedPage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private SaveReportModalPage saveReportModalPage;
	private LeftMenuWidget  leftMenuWidget;
	private ReportingCustomPage reportingCustomPage;
	private JobsByCustomerPage jobsByCustomerPage;
	private AverageJobSizePage averageJobSizePage;
	private JobCountPage jobCountPage;
	private JobsBusinessUnitPage jobsBusinessUnitPage;
	private JobTimeTrackinEmployeePage jobTimeTrackinEmployeePage;
	private JobsByCustomerLeadSource jobsByCustomerLeadSource;
	
	
	@BeforeTest
	public void setup() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		leftMenuWidget = new LeftMenuWidget(driver);
	}
	
	@Test
	public void saveCustomReportJobRevenueEarned() {
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openDateOption("Revenue earned");   
		jobRevenueEarnedPage = new JobRevenueEarnedPage(driver);
		jobRevenueEarnedPage.clickDateRange();
		jobRevenueEarnedPage.selectDateRangeByVisibleText("Year to date");
		jobRevenueEarnedPage.clickActionDate();
		jobRevenueEarnedPage.selectActionByVisibleText("Completed date");
		jobRevenueEarnedPage.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

		
	}
	
	@Test
	public void saveCustomReportCustomerName() {
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openCustomerOption("Customer name");   
		jobsByCustomerPage = new JobsByCustomerPage(driver);
		jobsByCustomerPage.clickDateRange();
		jobsByCustomerPage.selectDateRangeByVisibleText("Year to date");
		jobsByCustomerPage.clickActionDate();
		jobsByCustomerPage.selectActionByVisibleText("Completed date");
		jobsByCustomerPage.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

		
	}
	
	@Test
	public void saveCustomReportAverageJobSize() {
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openDateOption("Average job size");   
		averageJobSizePage = new AverageJobSizePage(driver);
		averageJobSizePage.clickDateRange();
		averageJobSizePage.selectDateRangeByVisibleText("Year to date");
		averageJobSizePage.clickActionDate();
		averageJobSizePage.selectActionByVisibleText("Completed date");
		averageJobSizePage.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);
		
		
	}
	
	
	@Test
	public void saveCustomReportJobCount() {
		
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openDateOption("Job count");   
		jobCountPage = new JobCountPage(driver);
		jobCountPage.clickDateRange();
		jobCountPage.selectDateRangeByVisibleText("Year to date");
		jobCountPage.clickActionDate();
		jobCountPage.selectActionByVisibleText("Completed date");
		jobCountPage.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

		
	}
	
	
	@Test
	public void saveCustomReportBusinessUnit() {
		
	
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openTypeOption("Business unit");  
		jobsBusinessUnitPage = new JobsBusinessUnitPage(driver);
		jobsBusinessUnitPage.clickDateRange();
		jobsBusinessUnitPage.selectDateRangeByVisibleText("Year to date");
		jobsBusinessUnitPage.clickActionDate();
		jobsBusinessUnitPage.selectActionByVisibleText("Created date");
		jobsBusinessUnitPage.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

		
	}
	
	
	@Test
	public void saveCustomReportJobTimeTrackinEmployee() {
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openTimeTracking("Job time tracking by employee");  
		jobTimeTrackinEmployeePage = new JobTimeTrackinEmployeePage(driver);
		jobTimeTrackinEmployeePage.clickDateRange();
		jobTimeTrackinEmployeePage.selectDateRangeByVisibleText("Year to date");
		jobTimeTrackinEmployeePage.clickActionDate();
		jobTimeTrackinEmployeePage.selectActionByVisibleText("Created date");
		jobTimeTrackinEmployeePage.clickSaveReport();	
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

		
	}
	@Test
	public void saveCustomReportCustomerLeadSource() {
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openCustomerOption("Customer lead source");   
		jobsByCustomerLeadSource = new JobsByCustomerLeadSource(driver);
		jobsByCustomerLeadSource.clickDateRange();
		jobsByCustomerLeadSource.selectDateRangeByVisibleText("Year to date");
		jobsByCustomerLeadSource.clickActionDate();
		jobsByCustomerLeadSource.selectActionByVisibleText("Completed date");
		jobsByCustomerLeadSource.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

	}
	
	
	@AfterTest
	public void deleteAllCustomReports() {
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.deleteCustomReports();

		
	}	
}
