package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.pages.serviceplan.ServicePlanSettingsPage;
import com.hcp.qa.pages.serviceplan.ServicePlansDashboardPage;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanTests extends BaseWebTest {

	ServicePlanHelper servicePlanHelper;
		
	@BeforeClass
	public void setUp() {
		loginHelper.login();
	}

	@Test
	public void checkServicePlanPage() {	
		servicePlanHelper = new ServicePlanHelper(driver);
		servicePlanHelper.goToServicePlanPage();
		
		SoftAssert servicePlansAssertions = new SoftAssert();
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansAssertions.assertTrue(servicePlansPage.isServicePlansTitleVisible(), "Service plan Title is not visible");
		servicePlansAssertions.assertTrue(servicePlansPage.isAddServicePlanDisplayed(),
				"Add service plan is not present");
		servicePlansAssertions.assertAll("Some assertions failed on service plan page");
		        
		servicePlansPage.clickSettings();
		ServicePlanSettingsPage settingsPage = new ServicePlanSettingsPage(driver);
		Assert.assertTrue(settingsPage.isServicePlanSettingsTitleVisible(), "Service plan settings Title is not visible");
		
	}

}
