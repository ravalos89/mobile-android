package com.hcp.qa.web.reporting;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeadConversionByEmployeePage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.web.BaseWebTest;

public class LeadConversionByEmployeeTest extends BaseWebTest {

	private DashboardPage dashboard;
	private LeadsPage leadsPage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private LeadConversionByEmployeePage leadConversionByEmployee;
	private LeftMenuWidget leftMenuWidget;

	@BeforeTest
	public void loginAndGoToReporting() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		leadConversionByEmployee = new LeadConversionByEmployeePage(driver);
		leftMenuWidget = new LeftMenuWidget(driver);
	}

	@Test
	public void verifyOptionsConversionByWeek() {
		leftMenuWidget.clickLeads();
		Assert.assertTrue(leadsPage.isCreateReportDisplayed(),"button is not in the page");
		leadsPage.openEmployeeOption("Lead conversion by employee");
		leadConversionByEmployee.clickDateRange();
		reportingHelper.verifyOptions(leadConversionByEmployee.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsLeads());
		leadConversionByEmployee.clickOnPage();
		leadConversionByEmployee.clickActionDate();
		reportingHelper.verifyOptions(leadConversionByEmployee.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsLeads());
		leadConversionByEmployee.clickOnPage();
	}
}
