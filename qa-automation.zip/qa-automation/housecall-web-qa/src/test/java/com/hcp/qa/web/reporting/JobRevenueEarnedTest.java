package com.hcp.qa.web.reporting;

import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.JobRevenueEarnedPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingJobsPage;
import com.hcp.qa.reports.ReportUtils;
import com.hcp.qa.web.BaseWebTest;

public class JobRevenueEarnedTest extends BaseWebTest {
	DashboardPage dashboard;
	ReportingJobsPage reportingJobs;
	ReportUtils reportUtils = new ReportUtils();
	JobRevenueEarnedPage jobRevenueEarnedPage;
	ReportingHelper reportingHelper = new ReportingHelper();
	private LeftMenuWidget leftMenuWidget;
	
	
	
	@Test
	public void jobRevenueEarned() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportingJobs.openDateOption("Revenue earned");
		jobRevenueEarnedPage = new JobRevenueEarnedPage(driver);
		
		if(!jobRevenueEarnedPage.isDayColumnDisplayed()) {
			reportUtils.fail("Day Column is not in page ");
			}
		
		if(!jobRevenueEarnedPage.isJobRevenueColumnDisplayed()) {
			reportUtils.fail("Job revenuew Column is not in page ");
			}
		
		
		jobRevenueEarnedPage.clickDateRange();
		reportingHelper.verifyOptions(jobRevenueEarnedPage.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsJobs());
		jobRevenueEarnedPage.clickOnPage();
		jobRevenueEarnedPage.clickActionDate();
		reportingHelper.verifyOptions(jobRevenueEarnedPage.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsJobs());
		jobRevenueEarnedPage.clickOnPage();
		
		}
}
