package com.hcp.qa.web.serviceplan;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.serviceplan.AddServicePlanToCustomerPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanZeroDollarTests extends BaseWebTest {
	String planName = "Test Service Plan";
	static String customerId;
	ServicePlanHelper servicePlanHelper;
	
	@BeforeClass
	public void setUp() {
		loginHelper.login();
		servicePlanHelper = new ServicePlanHelper(driver);
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
	}
	
	@Test
	public void addZeroDollarServicePlan() {			
		servicePlanHelper.addZeroDollarServicePlan(planName);
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertEquals(planSummary.getServicePlanName(), planName, "Service Plan name not matched");		
	}


	@Test(dependsOnMethods = "addZeroDollarServicePlan")
	public void acceptZeroDollarServicePlanToCustomer() {
		customerId = customer.getId();
		navigationHelper.goToCustomer(customerId);

		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddServicePlan();

		AddServicePlanToCustomerPage addPlanToCustomer = new AddServicePlanToCustomerPage(driver);
		addPlanToCustomer.searchAndSelectPlan(planName);
		addPlanToCustomer.selectAcceptPlanForCustomer();
		addPlanToCustomer.clickNext();
		addPlanToCustomer.clickFinishAndPay();
		addPlanToCustomer.clickAcceptPlan();

		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");

		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		customerServicePlan.clickBack();
	}
	
	@AfterClass
	private void cleanUp() {
		customerHelper.deleteAllCustomers(customerId);
		loginHelper.logout();
	}
}
