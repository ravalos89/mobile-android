package com.hcp.qa.web.reporting;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.CustomLeadConversionByWeekPage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingCustomPage;
import com.hcp.qa.pages.reporting.SaveReportModalPage;
import com.hcp.qa.web.BaseWebTest;

public class LeadsCreateReportTest extends BaseWebTest {

	private DashboardPage dashboard;
	private LeadsPage leadsPage;
	private LeftMenuWidget leftMenuWidget;
	private CustomLeadConversionByWeekPage customLeadConversionByWeek;
	private ReportingCustomPage reportingCustomPage;
	private SaveReportModalPage saveReportModalPage;
	private ReportingHelper reportingHelper = new ReportingHelper();

	@BeforeTest
	public void loginHCP() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickLeads();
		customLeadConversionByWeek = new CustomLeadConversionByWeekPage(driver);

	}

	@Test
	public void verifyDefaultOptionsForLeads() {
		Assert.assertTrue(leadsPage.isCreateReportDisplayed(),"button is not in the page");
		leadsPage.clickCrateReport();
		customLeadConversionByWeek.clickDateRange();
		customLeadConversionByWeek.selectDateRangeByVisibleText("Year to date");
		customLeadConversionByWeek.clickActionDate();
		customLeadConversionByWeek.selectActionByVisibleText("Created date");
		customLeadConversionByWeek.clickSaveReport();
		saveReportModalPage = new SaveReportModalPage(driver);
		String reportName = "Report "+ reportingHelper.generateTimeStamp();
		saveReportModalPage.setReportName(reportName);
		saveReportModalPage.clickSave();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.verifyReportName(reportName);

	}


	@AfterTest
	public void deleteAllCustomReports() {

		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickCustom();
		reportingCustomPage = new ReportingCustomPage(driver);
		reportingCustomPage.deleteCustomReports();

	}

}
