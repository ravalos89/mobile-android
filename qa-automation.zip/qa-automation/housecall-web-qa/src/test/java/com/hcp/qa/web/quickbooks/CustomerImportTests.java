package com.hcp.qa.web.quickbooks;

import org.openqa.selenium.NoSuchElementException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.AdminHelper;
import com.hcp.qa.helpers.PropertiesReader;
import com.hcp.qa.pages.admin.CompaniesListPage;
import com.hcp.qa.pages.admin.company.CompanyPage;
import com.hcp.qa.pages.admin.company.CompanySupportPage;
import com.hcp.qa.pages.admin.company.ConfirmActionDialog;
import com.hcp.qa.pages.customer.CustomerListOptionsMenu;
import com.hcp.qa.pages.customer.CustomersListPage;
import com.hcp.qa.pages.quickbooks.QBOImportPage;
import com.hcp.qa.pages.quickbooks.QBOOnboardingPage;
import com.hcp.qa.web.BaseWebTest;

public class CustomerImportTests extends BaseWebTest {

	private static Logger LOG = LoggerFactory.getLogger(CustomerImportTests.class);

	String qboCompany = "QBO Test Company";
	String qboUser = PropertiesReader.getInstance().getQBOUser();
	final static int WAIT_TIME_FOR_IMPORT = 60;

	@Test
	public void removeImportedCustomersFromAdmin() {
		AdminHelper adminHelper = new AdminHelper(driver);
		adminHelper.login();
		CompaniesListPage companiesListPage = new CompaniesListPage(driver);
		companiesListPage.waitForLoadingToFinish();

		companiesListPage.searchForCompany(qboUser);
		companiesListPage.clickDetailsOnRowWith(qboCompany);

		CompanyPage company = new CompanyPage(driver);
		company.clickSupport();
		CompanySupportPage support = new CompanySupportPage(driver);
		support.clickRemoveImportedData();
		ConfirmActionDialog confirmDialog = new ConfirmActionDialog(driver);
		confirmDialog.enterActionConfirmation("REMOVE IMPORT");
		confirmDialog.clickSubmit();

		loginHelper.login(qboUser, PropertiesReader.getInstance().getPassword());
		navigationHelper.goToCustomersListPage();
		CustomersListPage customers = new CustomersListPage(driver);
		Assert.assertEquals(customers.getNumberOfCustomers(), "0", "The number of customers should be 0");

	}

	@Test(dependsOnMethods = "removeImportedCustomersFromAdmin")
	public void importCustomersFromQuickBooks() {
		loginHelper.login(qboUser, PropertiesReader.getInstance().getPassword());
		navigationHelper.goToCustomersListPage();
		CustomersListPage customers = new CustomersListPage(driver);
		customers.waitForPageToLoad(2);
		customers.clickThreeDotsIcon();
		CustomerListOptionsMenu options = new CustomerListOptionsMenu(driver);
		options.clickImportFromQuickooks();
		try {
			QBOOnboardingPage qboOnboarding = new QBOOnboardingPage(driver);
			qboOnboarding.clickSkip();
			qboOnboarding.clickFinish();
		} catch (NoSuchElementException e) {
			LOG.info("No QBO Onboarding prompts .Continuing with Import");
		}

		QBOImportPage qboImport = new QBOImportPage(driver);
		qboImport.clickImportData();
		qboImport.clickImport();
		qboImport.waitForPageToLoad(WAIT_TIME_FOR_IMPORT);
		driver.navigate().refresh();
		qboImport.waitForPageToLoad(1);
		
		//Assert.assertEquals(qboImport.getHCPCustomerCount(), qboImport.getQBOCustomerCount(),"QBO and HCP count does not match on import page. ");

		
		navigationHelper.goToCustomersListPage();
		customers.waitForPageToLoad(2);
		customers = new CustomersListPage(driver);
		//Assert.assertEquals(customers.getNumberOfCustomers(),qboImport.getQBOCustomerCount(),The Count on customers page does not match QBO count. ");
		Assert.assertNotEquals(customers.getNumberOfCustomers(), "0", "Customer count should not be 0");		

	}

}
