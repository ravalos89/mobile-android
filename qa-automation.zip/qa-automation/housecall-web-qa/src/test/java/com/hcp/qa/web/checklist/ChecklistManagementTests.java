package com.hcp.qa.web.checklist;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.pages.checklist.ChecklistPage;
import com.hcp.qa.pages.checklist.EditChecklistPage;
import com.hcp.qa.pages.common.DeleteDialog;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.myapps.MyAppsPage;
import com.hcp.qa.web.BaseWebTest;

public class ChecklistManagementTests extends BaseWebTest{
	String checklistName="Auto Test Checklist";
	@BeforeClass
	public void setup()
	{
		loginHelper.login();
		//FIXME: Take out refresh once DT-458 is fixed 
		driver.navigate().refresh();
	}
	
	@Test
	public void createChecklist(){
		DashboardPage dashboard=new DashboardPage(driver);
		dashboard.getTopMenu().clickMyApps();
		MyAppsPage myApps=new MyAppsPage(driver);
		myApps.clickChecklists();
		ChecklistPage checklists=new ChecklistPage(driver);
		checklists.clickAddChecklist();
		
		EditChecklistPage checklist =new EditChecklistPage(driver);
		checklist.enterChecklistName("Auto Test Checklist");
		checklist.enterChecklistItem(0, "Checkbox", "Test Checkbox Item");
		checklist.clickAddChecklistItemBtn();
		checklist.enterChecklistItem(1, "Text", "Test Text Item");
		checklist.clickAddChecklistItemBtn();
		checklist.enterChecklistItem(2, "Pass/Flag/Fail", "Test Inspection Item");
		checklist.clickNext();		
		checklist.clickSave();
	}

	@Test(dependsOnMethods="createChecklist")
	public void editChecklist()	{
		ChecklistPage checklists=new ChecklistPage(driver);
		checklists.editChecklist(checklistName);
		
		EditChecklistPage checklist =new EditChecklistPage(driver);
		checklist.enterChecklistName(" updated");
		checklist.clickNext();
		checklist.clickUpdate();
		Assert.assertTrue(checklists.searchForText(checklistName+" updated"));
	}
	
	@Test(dependsOnMethods="editChecklist")
	public void deleteChecklistItem(){
		ChecklistPage checklists=new ChecklistPage(driver);
		checklists.editChecklist(checklistName);
		String checklistItem="Test Inspection Item";
		EditChecklistPage checklist =new EditChecklistPage(driver);
        checklist.deleteCheckListItem(checklistItem);
		checklist.clickNext();
		checklist.clickUpdate();
		checklists.editChecklist(checklistName);
		Assert.assertFalse(checklist.searchForText(checklistItem));
		checklist.clickClose();
	}
	
	@Test(dependsOnMethods="deleteChecklistItem")
	public void deleteChecklist(){
		ChecklistPage checklists=new ChecklistPage(driver);
		checklists.editChecklist(checklistName);
		EditChecklistPage editChecklist =new EditChecklistPage(driver);
		editChecklist.deleteCheckList();
		DeleteDialog deleteDialog=new DeleteDialog(driver);
		deleteDialog.clickDelete();
		Assert.assertFalse(checklists.searchForText(checklistName+" updated"));
	}
	
}
