package com.hcp.qa.web.reporting;

import org.testng.annotations.Test;

import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.AverageJobSizePage;
import com.hcp.qa.pages.reporting.JobRevenueEarnedPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingJobsPage;
import com.hcp.qa.web.BaseWebTest;

public class ExportReportAsCSVTest extends BaseWebTest {
	DashboardPage dashboard;
	ReportingJobsPage reportingJobs;
	JobRevenueEarnedPage jobRevenueEarnedPage;
	AverageJobSizePage averageJobSizePage;
	LeftMenuWidget leftMenuWidget;
	
	@Test
	public void exportReportAsCSV() {
		dashboard = loginHelper.login();
		dashboard.getTopMenu().clickReporting(); 
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		jobRevenueEarnedPage = new JobRevenueEarnedPage(driver);
		averageJobSizePage = new AverageJobSizePage(driver);
		
		reportingJobs.openDateOption("Revenue earned");
		
		jobRevenueEarnedPage.clickExportCSV();
		driver.navigate().back();
		
		reportingJobs.openDateOption("Average job size");
		averageJobSizePage.clickExportCSV();
		driver.navigate().back();
		
		
	}
}