package com.hcp.qa.web.timetracking;

import java.io.File;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.common.TabManager;
import com.hcp.qa.gmail.AttachmentUtils;
import com.hcp.qa.gmail.EmailMessage;
import com.hcp.qa.gmail.GmailMessageClient;
import com.hcp.qa.helpers.CalendarHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.help.HelpPage;
import com.hcp.qa.pages.myapps.MyAppsPage;
import com.hcp.qa.pages.timetracking.TimeTrackingPage;
import com.hcp.qa.web.BaseWebTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class TimeTrackingTests extends BaseWebTest {
	String checklistName = "Auto Test Checklist";
	TimeTrackingPage timeTracking;
	CalendarHelper calenderHelper = CalendarHelper.getInstance();

	@BeforeClass
	public void setup() {
		loginHelper.login();
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickMyApps();
		MyAppsPage myApps = new MyAppsPage(driver);
		myApps.clickTimeSheet();
		timeTracking = new TimeTrackingPage(driver);
	}

	@Test(priority = 1)
	public void timeSheetHelp() {
		String mainWindow = driver.getWindowHandle();
		timeTracking.clickHelp();
		TabManager tabManager = new TabManager(driver);

		String helpWindow = tabManager
				.switchToNewTabByTitle("View & Edit Employee Timecard | Housecall Pro Help Center");
		HelpPage helpPage = new HelpPage(driver);
		Assert.assertTrue(helpPage.searchForText("View & Edit Employee Timecard"));
		tabManager.closeTabAndSwitchtoAnother(helpWindow, mainWindow);
	}

	@Test(priority = 2)
	public void timeEntryInTimeCard() {
		timeTracking.clickOneWeekRadio();
		timeTracking.enterTimeEntry();
		assertEquals(timeTracking.getEnteredTime(), "9:00", "Entered time is not correct");
	}

	@Test(priority = 3)
	public void OneWeekFilter() {
		timeTracking.click2Week2Radio();
		timeTracking.clickOneWeekRadio();
		assertTrue(timeTracking.firstDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getWeekStartDate())), "Start Date is not correct");
		assertTrue(timeTracking.endDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getWeekEndDate())), "End Date is not correct");
		saveAndExportReport();

		String expectedData = calenderHelper.expectedDateInFormat(calenderHelper.getWeekStartDate()) + ",09:00";
		verifyExportedReport(expectedData);

	}

	@Test(priority = 4)
	public void twoWeeksFilter() {
		timeTracking.click2Week2Radio();
		assertTrue(timeTracking.firstDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.get2WeekStartDate())), "Start Date is not correct");
		assertTrue(timeTracking.endDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getWeekEndDate())), "End Date is not correct");
		saveAndExportReport();

		String expectedData = calenderHelper.expectedDateInFormat(calenderHelper.getWeekStartDate()) + ",09:00";
		verifyExportedReport(expectedData);

	}

	@Test(priority = 5)
	public void MonthFilter() {
		timeTracking.clickMonthRadio();
		assertTrue(timeTracking.firstDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getMonthStartDate())), "Start Date is not correct");
		assertTrue(timeTracking.endDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getMonthEndDate())), "End Date is not correct");
		saveAndExportReport();

		String expectedData = calenderHelper.formatDate(calenderHelper.getMonthStartDate());

		verifyExportedReport(expectedData);
	}

	@Test(priority = 6)
	public void YearFilter() {
		timeTracking.clickYearRadio();
		assertTrue(timeTracking.firstDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getYearStartDate())), "Start Date is not correct");
		assertTrue(timeTracking.endDateInFilteredTable()
				.contains(calenderHelper.formatDate(calenderHelper.getYearEndDate())), "End Date is not correct");
		saveAndExportReport();

		String expectedData = calenderHelper.expectedDateInFormat(calenderHelper.getWeekStartDate()) + ",09:00";
		verifyExportedReport(expectedData);

	}

	private void saveAndExportReport() {
		timeTracking.saveReport();
		timeTracking.clickExportIcon();
		Assert.assertTrue(timeTracking.verifyExportAlertMsg(), "Export alert message is not correct");
		timeTracking.clickConfirmExport();

	}

	private void verifyExportedReport(String expectedData) {
		timeTracking.waitForPageToLoad(20);
		GmailMessageClient gmailClient = GmailMessageClient.getInstance();
		EmailMessage email = gmailClient.getEmailWithAttachments("**QA_TESTHouseCall Pro time card export", 10, true);

		File attachment = email.getAttachmentFile("time_card_export.csv");
		List<String> exportedData = AttachmentUtils.getRows(attachment);
		boolean isFound = false;
		for (String row : exportedData) {
			if (row.contains(expectedData)) {
				isFound = true;
				break;
			}
		}
		Assert.assertTrue(isFound, "Expected data" + expectedData + "Not found in " + exportedData);
	}

	@AfterClass
	public void finish() {
		timeTracking.clickOneWeekRadio();
		timeTracking.deleteTimeEntry();
	}

}
