package com.hcp.qa.web.reporting;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeadConversionByMonthPage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.web.BaseWebTest;

public class LeadConversionByMonthTest extends BaseWebTest {
	
	private DashboardPage dashboard;
	private LeadsPage leadsPage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private LeadConversionByMonthPage leadConversionByMonth;
	private LeftMenuWidget leftMenuWidget;

	@BeforeMethod
	public void loginAndGoToReporting() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		leadConversionByMonth = new LeadConversionByMonthPage(driver);
		leftMenuWidget = new LeftMenuWidget(driver);	
	}

	@Test
	public void verifyOptionsConversionByMonth() {
		leftMenuWidget.clickLeads();
		Assert.assertTrue(leadsPage.isCreateReportDisplayed(),"button is not in the page");
		leadsPage.openDateOption("Lead conversion by month");
		leadConversionByMonth.clickDateRange();
		reportingHelper.verifyOptions(leadConversionByMonth.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsLeads());
		leadConversionByMonth.clickOnPage();
		leadConversionByMonth.clickActionDate();
		reportingHelper.verifyOptions(leadConversionByMonth.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsLeads());
		leadConversionByMonth.clickOnPage();
	}


}
