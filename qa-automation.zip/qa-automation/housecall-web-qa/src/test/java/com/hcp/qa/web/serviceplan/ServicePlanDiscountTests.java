package com.hcp.qa.web.serviceplan;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.DataGenerator;
import com.hcp.qa.helpers.PaymentHelper;
import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.job.AmountWidget;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.serviceplan.CustomerServicePlanPage;
import com.hcp.qa.pages.serviceplan.ServicePlanSummaryPage;
import com.hcp.qa.pages.serviceplan.ServicePlanTemplatePage;
import com.hcp.qa.pages.serviceplan.ServicePlansDashboardPage;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanDiscountTests extends BaseWebTest {
	String planName = "Discount Service Plan";
	String discountPercentage = "10%";
	static String customerId;
	static String customerIdForCash;
	ServicePlanHelper servicePlanHelper;
	PaymentHelper paymentHelper;
	static String customerIdForCheck;
	
	@BeforeClass
	public void setUp() {
		loginHelper.login();
		driver.navigate().refresh();
		servicePlanHelper = new ServicePlanHelper(driver);
		customerId = customer.getId();
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
	}

	@Test
	public void addServicePlanWithDiscount() {	
		servicePlanHelper.addServicePlanWithDiscount(planName,"10");
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertEquals(planSummary.getServicePlanName(), planName, "Service Plan name not matched");	
		
		CustomerServicePlanPage planSummaryOnServicePlanTemplate = new CustomerServicePlanPage(driver);
		Assert.assertTrue(planSummaryOnServicePlanTemplate.getDiscountPercentage().equals(discountPercentage),
				"Discount Percentage not matched");
		
		servicePlanHelper.goToServicePlanPage();
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		Assert.assertTrue(servicePlansPage.validatePlanDisplayedOnServicePlans(planName),
				"Created service plan is not present in plans we offer list");
	}

	@Test(dependsOnMethods = "addServicePlanWithDiscount")
	public void acceptDiscountServicePlanForCustomer() {
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId,planName);
		
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");
		
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();
		Assert.assertTrue(customerServicePlan.getDiscountPercentage().equals(discountPercentage), "Discount Percentage not matched");
		customerServicePlan.waitForPageToLoad(2);
		customerServicePlan.clickBack();
		servicePlanHelper.verifyServiceAgreementEmailReceived("Your new service plan from",true,"New service plan","You have a new service plan with");
	}
	
	@Test(dependsOnMethods = "acceptDiscountServicePlanForCustomer")
	public void validateAutomaticDiscountOnJob() {	
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
        customerDetails.clickAddNewJob();

        EditJobPage editJob = new EditJobPage(driver);
        LineItem lineItem = DataGenerator.getInstance().generateLineItem();
        editJob.addLineItem(lineItem);
        AmountWidget amountWidget = new AmountWidget(driver);
        Assert.assertTrue(amountWidget.isDiscountNameDisplayed(planName),
				"Discount Name is not same as service plan");
        Assert.assertTrue(amountWidget.isDiscountPercentageDisplayed(discountPercentage),
				"Discount Percentage is not same as service plan");
        Assert.assertTrue(amountWidget.isDiscountAmountDisplayed("$1.00"),
				"Discount Amount is not correct");
	}

	@Test(priority=1)
	public void addDiscountToAlreadyActivatedPlanForCustomer() {	
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
		servicePlanHelper.addServicePlan(planName);	
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId,planName);
		
		ServicePlanSummaryPage planSummary = new ServicePlanSummaryPage(driver);
		planSummary.isServicePlanActivatedMessage();
		
		CustomerServicePlanPage customerServicePlan = new CustomerServicePlanPage(driver);
		customerServicePlan.clickClose();	
		
		Assert.assertEquals(customerServicePlan.getServicePlanName(), planName, "Service Plan name not matched");
		Assert.assertFalse(customerServicePlan.getDiscountPercentage().equals("30%"),
				"Discount Percentage still present");
		customerServicePlan.clickBack();
		driver.navigate().refresh();
		servicePlanHelper.goToServicePlanPage();	
		
		ServicePlansDashboardPage servicePlansPage = new ServicePlansDashboardPage(driver);
		servicePlansPage.clickServicePlan(planName);
		planSummary.editServicePlan();
		
		ServicePlanTemplatePage editPlanTemplate = new ServicePlanTemplatePage(driver);
		editPlanTemplate.toggleDiscount();
		editPlanTemplate.enterDiscountDescription();
		editPlanTemplate.enterDiscountPercentage("30");
		editPlanTemplate.clickNext();
		editPlanTemplate.clickNext();
		editPlanTemplate.clickSavePlan();
		CustomerServicePlanPage editPlanTemplatePage = new CustomerServicePlanPage(driver);
		Assert.assertTrue(editPlanTemplatePage.getDiscountPercentage().equals("30%"),
				"Discount Percentage not matched");
		
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId,planName);
		Assert.assertTrue(planSummary.isServicePlanActivatedMessage(),
				"Service plan activated message not present");
		customerServicePlan.clickClose();
		Assert.assertTrue(customerServicePlan.getDiscountPercentage().equals("30%"),
				"Discount Percentage not matched");
		customerServicePlan.clickBack();
	}
	
	@AfterClass
	private void cleanUp() {
		customerHelper.deleteAllCustomers(customerId);
		loginHelper.logout();
	}
}
