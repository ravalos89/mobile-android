package com.hcp.qa.web.activityfeed;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.DataGenerator;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.pages.activityfeed.ActivityFeedPage;
import com.hcp.qa.pages.common.CustomerSearchWidget;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.estimate.EditEstimatePage;
import com.hcp.qa.pages.estimate.NewEstimatePage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.web.BaseWebTest;

public class ActivityFeedTests extends BaseWebTest {
	Job job;

	@BeforeClass
	public void setup() {
		loginHelper.login();
	}

	@Test
	public void searchActivityFeed() {
		job = jobHelper.createJob(customer);
		EditJobPage editJob = new EditJobPage(driver);
		editJob.getTopMenu().clickDash();
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickActivityFeed();
		ActivityFeedPage activityFeed = new ActivityFeedPage(driver);
		activityFeed.waitForPageToLoad(5);
		activityFeed.enterSearchTerm(job.getInvoiceNumber());
		activityFeed.waitForPageToLoad(3);
		activityFeed.clickOnActivity(job.getInvoiceNumber());
		activityFeed.waitForPageToLoad(1);
		Assert.assertTrue(activityFeed.isJobLinkVisible(job.getInvoiceNumber()), "Job link not found");
	}

	@Test(dependsOnMethods = "searchActivityFeed")
	public void clickOnJobFromActivityFeed() {
		ActivityFeedPage activityFeed = new ActivityFeedPage(driver);
		activityFeed.clickOnJobLinkInActivity(job.getInvoiceNumber());
		EditJobPage editJob = new EditJobPage(driver);
		Assert.assertEquals(editJob.getInvoiceNumber(), job.getInvoiceNumber(),
				"Invoice number does not match for job");
	}

	@Test
	public void clickOnEstimateFromActivityFeed() {
		navigationHelper.goToNewEstimatesPage();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		CustomerSearchWidget customerWidget = new CustomerSearchWidget(driver);
		customerWidget.searchAndSelectExistingCustomer(customer.getDisplayName());
		LineItem lineItem = DataGenerator.getInstance().generateLineItem();
		newEstimate.addLineItem(lineItem);
		newEstimate.save();
		newEstimate.waitForPageToLoad(1);
		EditEstimatePage editEstimate = new EditEstimatePage(driver);
		String estimateNumber = editEstimate.getEstimateNumber();

		editEstimate.getTopMenu().clickDash();
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickActivityFeed();

		ActivityFeedPage activityFeed = new ActivityFeedPage(driver);
		activityFeed.waitForPageToLoad(5);
		activityFeed.enterSearchTerm(estimateNumber);
		activityFeed.waitForPageToLoad(3);
		activityFeed.clickOnActivity(estimateNumber);
		activityFeed.waitForPageToLoad(1);
		activityFeed.clickOnEstimateLinkInActivity(estimateNumber);

		editEstimate = new EditEstimatePage(driver);
		Assert.assertEquals(editEstimate.getEstimateNumber(), estimateNumber, "Estimate number does not match for job");
	}
}
