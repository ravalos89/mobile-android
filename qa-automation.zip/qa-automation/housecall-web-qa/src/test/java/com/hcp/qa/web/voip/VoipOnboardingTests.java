package com.hcp.qa.web.voip;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.helpers.PropertiesReader;
import com.hcp.qa.pages.common.SettingsPage;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.voip.VoipSetupPage;
import com.hcp.qa.web.BaseWebTest;

public class VoipOnboardingTests extends BaseWebTest {

	@Test
	public void testVoipOnboarding() {
		String voipEnabledPro = ConfigHandler.getStringPropertyValueFromKey("hcp.web.voip.onboarding.user");
		String password = PropertiesReader.getInstance().getPassword();

		DashboardPage dashboard = loginHelper.login(voipEnabledPro, password);
		dashboard.getTopMenu().clickAccountSettingsFromProfile();
		SettingsPage settings = new SettingsPage(driver);
		settings.clickCommunications();
		VoipSetupPage voipSetup = new VoipSetupPage(driver);
		voipSetup.clickGetStarted();
		Assert.assertTrue(voipSetup.isSetUpTitleDisplayed(), "Voip Setup Title is not Displayed");
	}

}
