package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.pages.common.LoginPage;
import com.hcp.qa.pages.common.ResetPasswordDialog;
import com.hcp.qa.web.BaseWebTest;

public class ForgotPasswordTests extends BaseWebTest {
	@Test
	public void checkForgotPasswordFlow() {
		navigationHelper.goToLoginPage();
		LoginPage login = new LoginPage(driver);
		login.clickForgotPassword();

		ResetPasswordDialog resetPassword = new ResetPasswordDialog(driver);
		Assert.assertTrue(resetPassword.isResetPasswordDisplayed(), "Reset Password Dialog is not displayed");
	}

}
