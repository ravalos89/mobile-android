package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.pages.common.LoginPage;
import com.hcp.qa.pages.onboarding.SignUpFlow;
import com.hcp.qa.web.BaseWebTest;

public class SignUpForTrialTests extends BaseWebTest{
	
	
	//String housecallUrl="https://www.housecallpro.com/";
	@Test
	public void signUpForTrial()
	//TODO: cannot click on the sign up link from home page
	{
   /*  driver.navigate().to(housecallUrl);
     HousecallLandingPage landingPage=new HousecallLandingPage(driver);
     landingPage.waitForPageToLoad(5);
     landingPage.clickStartFreeTrial();
     */
		
	 navigationHelper.goToLoginPage();
     LoginPage login=new LoginPage(driver);
     login.clickSignUp();
     
     SignUpFlow signupFlow=new SignUpFlow(driver);
     signupFlow.waitForPageToLoad(2);
     Assert.assertTrue(signupFlow.isCreateYourProfileDisplayed(),"Create your profile is not diplayed during sign up ");
     Assert.assertTrue(signupFlow.isSetupYourCompanyDisplayed(),"Set up company is not displayed during sign up ");
     Assert.assertTrue(signupFlow.isSetPasswordDisplayed(),"Set a password is not displayed during sign up ");

	}
}
