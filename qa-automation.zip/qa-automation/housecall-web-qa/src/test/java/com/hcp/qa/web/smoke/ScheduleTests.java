package com.hcp.qa.web.smoke;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.Random;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.api.ApiClient;
import com.hcp.qa.common.Sleep;
import com.hcp.qa.helpers.PropertiesReader;
import com.hcp.qa.helpers.TimezoneHelper;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.models.Schedule;
import com.hcp.qa.pages.schedule.calendar.DayCalendar;
import com.hcp.qa.pages.schedule.calendar.full.FullCalendarFactory;
import com.hcp.qa.web.BaseWebTest;

import static com.hcp.qa.pages.schedule.calendar.full.NewCalendarViewName.DAY;

public class ScheduleTests extends BaseWebTest {

    private final ZonedDateTime start = LocalDateTime.now().withHour(10).withMinute(30).withSecond(0).atZone(TimezoneHelper.defaultOrganizationTimeZoneId);
    private final ZonedDateTime end = start.plusHours(1).plusMinutes(0);
    private final ApiClient client = new ApiClient(PropertiesReader.getInstance().getApiKey());
    private final String JOB_DESCRIPTION_PREFIX = "Smoke LineItemPrefix";

    @BeforeClass
    public void login() {
        loginHelper.login();
    }

    @BeforeMethod
    public void setUp() {
        createJob();
        navigationHelper.goToNewCalendar();
    }

    @Test
    public void clickOnJobInCalendar() {
        DayCalendar calendar = new FullCalendarFactory().createDayCalendar(driver);
        calendar.selectView(DAY);
        calendar.clickEvent(JOB_DESCRIPTION_PREFIX);
        jobHelper.deleteJob();
    }

    private Job createJob() {
        Job job = new Job();
        job.setCustomerId(customer.getId());
        LineItem lineItem = new LineItem();
        lineItem.setName(JOB_DESCRIPTION_PREFIX + new Random().nextInt());
        job.addLineItem(lineItem);
        Schedule schedule = new Schedule();

        schedule.setScheduledStart(start);
        schedule.setScheduledEnd(end);
        job.setSchedule(schedule);
        client.createJob(job);
        Sleep.seconds(5);
        return job;
    }
}