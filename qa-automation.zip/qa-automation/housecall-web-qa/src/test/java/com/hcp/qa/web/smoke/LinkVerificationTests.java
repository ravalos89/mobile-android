package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.TabManager;
import com.hcp.qa.pages.common.SettingsPage;
import com.hcp.qa.pages.customer.AddNewCustomerPage;
import com.hcp.qa.pages.customer.CustomersListPage;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.employee.EmployeeListPage;
import com.hcp.qa.pages.estimate.NewEstimatePage;
import com.hcp.qa.pages.inbox.InboxPage;
import com.hcp.qa.pages.job.NewJobPage;
import com.hcp.qa.pages.map.MapPage;
import com.hcp.qa.pages.myapps.MyAppsPage;
import com.hcp.qa.pages.mymoney.MyMoneyPage;
import com.hcp.qa.pages.navigation.ActivityFeedSidebar;
import com.hcp.qa.pages.navigation.HelpPage;
import com.hcp.qa.pages.navigation.TasksSidebar;
import com.hcp.qa.pages.pricebook.PriceBookPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportPage;
import com.hcp.qa.pages.schedule.SchedulePage;
import com.hcp.qa.proposal.ProposalPage;
import com.hcp.qa.referral.ShareTheLovePage;
import com.hcp.qa.web.BaseWebTest;

public class LinkVerificationTests extends BaseWebTest {
	Logger LOG = Logger.getLogger(LinkVerificationTests.class);
	DashboardPage dashboard;

	@BeforeClass
	public void setUp() {
		loginHelper.login();
	}

	@BeforeMethod
	public void goToDashboard() {
		navigationHelper.goToDashboardPage();
		driver.navigate().refresh();
		dashboard = new DashboardPage(driver);
		dashboard.waitForPageLoaded();

	}

	@Test
	public void checkDashboardPage() {
		dashboard.getTopMenu().clickDash();
		Assert.assertTrue(dashboard.getUpcomingJobsWidget().searchForText("Upcoming jobs"),
				"Upcoming jobs widget not found on Dashboard");
	}

	@Test
	public void checkSchedulePage() {
		dashboard.waitForPageToLoad(1);
		dashboard.getTopMenu().clickSchedule();
		SchedulePage schedule = new SchedulePage(driver);
		Assert.assertTrue(schedule.isTodayButtonVisible(), "Today button is not visible on Schedule page");
	}

	@Test
	public void checkCustomerPage() {
		dashboard.getTopMenu().clickCustomers();
		CustomersListPage customersList = new CustomersListPage(driver);
		Assert.assertTrue(customersList.isAddCustomersDisplayed(),
				"Add Customers button is not visible on Customers List page");
	}

	@Test
	public void checkMapPage() {
		dashboard.getTopMenu().clickMap();
		MapPage map = new MapPage(driver);
		Assert.assertTrue(map.isHcpMapVisible(), "Hcp Map button is not visible on Maps page");
	}

	@Test
	public void checkMyAppsPage() {
		dashboard.getTopMenu().clickMyApps();
		MyAppsPage myApps = new MyAppsPage(driver);
		myApps.clickGoToAppStore();
		Assert.assertTrue(myApps.isAppsTitleVisible(), "Apps Title  is not visible on My Apps page");
	}

	@Test
	public void checkMyMoneyPage() {
		dashboard.getTopMenu().clickMyMoney();
		MyMoneyPage myMoney = new MyMoneyPage(driver);
		//FIXME: This is a temporary solution because we have alot of pending transactions on QA.
		if (ConfigHandler.getTargetEnv().equals("qa")) {
			LOG.info("Waiting for My money page on QA");
			myMoney.waitForPageToLoad(45);
		}

		Assert.assertTrue(myMoney.isMyMoneyTitleVisible(), "My Money Title  is not visible on My Money page");
	}

	@Test
	public void checkReportingPage() {
		dashboard.waitForPageToLoad(1);
		dashboard.getTopMenu().clickReporting();
		LeftMenuWidget leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickJobs();
		ReportPage report = new ReportPage(driver);
		Assert.assertTrue(report.isBuildReportVisible(), "Build My own Report is not visible on Report page");
	}

	@Test
	public void checkPriceBookPage() {
		dashboard.getTopMenu().clickPriceBook();
		PriceBookPage pricebook = new PriceBookPage(driver);
		Assert.assertTrue(pricebook.isPriceBookBreadCrumbVisible(), "PriceBook title  is not visible on Pricebook  page");
	}

	@Test
	public void checkProposalFromNew() {
		dashboard.getTopMenu().clickProposalFromNew();
		ProposalPage proposal = new ProposalPage(driver);
		proposal.waitForPageToLoad(1);
		Assert.assertTrue(proposal.isTitleVisible(), "Proposal  title is not visible on New Proposal page");
		proposal.clickClose();
	}

	@Test
	public void checkJobFromNew() {
		dashboard.getTopMenu().clickJobFromNew();
		NewJobPage newJob = new NewJobPage(driver);
		Assert.assertTrue(newJob.isNewJobTitleVisible(), "New Job title is not visible on New Job page");
		newJob.clickClose();
	}

	@Test
	public void checkEstimateFromNew() {
		dashboard.getTopMenu().clickEstimateFromNew();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		Assert.assertTrue(newEstimate.isTitleVisible(), "New Estimate title is not visible on New Estimate page");
		newEstimate.clickClose();
	}

	@Test
	public void checkCustomersFromNew() {
		dashboard.getTopMenu().clickCustomerFromNew();
		AddNewCustomerPage customer = new AddNewCustomerPage(driver);
		customer.waitForPageToLoad(1);
		Assert.assertTrue(customer.isTitleVisible(), "Customer title is not visible on Customers page");
		customer.clickCancel();
	}

	@Test
	public void checkAccountSettings() {
		dashboard.getTopMenu().clickAccountSettingsFromProfile();
		SettingsPage settings = new SettingsPage(driver);
		settings.waitForPageToLoad(1);
		Assert.assertTrue(settings.isCompanyProfileVisible(), "Settings title is not displayed on Settings page");
		settings.clickClose();

	}

	@Test
	public void checkActivityFeed() {
		dashboard.getTopMenu().clickActivityFeed();
		ActivityFeedSidebar activityFeed = new ActivityFeedSidebar(driver);
		activityFeed.waitForPageToLoad(1);
		Assert.assertTrue(activityFeed.isTitleVisible(), "Activity feed title not found");
		activityFeed.clickClose();
	}

	@Test
	public void checkAllTasks() {
		dashboard.getTopMenu().clickTasks();
		TasksSidebar tasks = new TasksSidebar(driver);
		tasks.waitForPageToLoad(1);
		Assert.assertTrue(tasks.isTitleVisible());
		tasks.clickClose();
	}

	@Test()
	public void checkReferAFriend() {
		dashboard.getTopMenu().clickReferFromProfile();
		ShareTheLovePage referral = new ShareTheLovePage(driver);
		referral.waitForPageToLoad(1);
		Assert.assertTrue(referral.isTitleVisible(), "Referral title is not displayed on Referral page");
		referral.clickClose();
	}

	@Test
	public void checkHelp() {
		dashboard.getTopMenu().clickHelp();
		TabManager tabManager=new TabManager(driver);
		String mainWindow=driver.getWindowHandle();
		String helpWindow=tabManager.switchToLatestTab(mainWindow);
		HelpPage help = new HelpPage(driver);
		Assert.assertTrue(help.isHelpTitleVisible(), "Help title is not visible on Help page");
		tabManager.closeTabAndSwitchtoAnother( helpWindow,mainWindow );
	}
	
	@Test
	public void checkInbox() 
	{
		dashboard.getTopMenu().clickInbox();
		InboxPage inbox=new InboxPage(driver);
		Assert.assertTrue(inbox.isCommunityDisplayed(),"Community in the left menu is not displayed");
	}

	@Test
	public void checkEmployeesPage(){
		dashboard.getTopMenu().clickAccountSettingsFromProfile();
		SettingsPage settings = new SettingsPage(driver);
		settings.clickEmployeesIcon();

		new EmployeeListPage(driver).waitForEmployeesToLoad();
	}

}
