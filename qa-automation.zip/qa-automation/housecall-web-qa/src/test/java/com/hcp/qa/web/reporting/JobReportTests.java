package com.hcp.qa.web.reporting;

import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.hcp.qa.common.TabManager;
import com.hcp.qa.models.Job;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.customer.JobsTab;
import com.hcp.qa.pages.dashboard.AverageJobSizeCard;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.dashboard.FeedbackWidget;
import com.hcp.qa.pages.dashboard.FilterWidget;
import com.hcp.qa.pages.help.HelpPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.FinishJobWidget;
import com.hcp.qa.testng.Retriable;
import com.hcp.qa.web.BaseWebTest;
import com.hcp.qa.web.WebTestListener;

@Listeners(WebTestListener.class)
public class JobReportTests extends BaseWebTest {
	private static Logger LOG = LoggerFactory.getLogger(JobReportTests.class);

	@BeforeClass
	@Retriable
	public void setUp() {
		DashboardPage dashboard = loginHelper.login();
		dashboard.waitForPageToLoad(5);
		LOG.info("Setting  Filter to Daily");
		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		avgJobSizeCard.clickFilter();
		FilterWidget filter = new FilterWidget(driver);
		filter.selectDaily();
		filter.clickClose();
	}

	@Test
	public void averageJobSizeCardHelp() {

		String mainWindow = driver.getWindowHandle();

		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		avgJobSizeCard.waitForPageToLoad(5);
		avgJobSizeCard.clickMoreActions();
		avgJobSizeCard.clickHelp();
		avgJobSizeCard.waitForPageToLoad(1);

		TabManager tabManager = new TabManager(driver);

		String helpWindow = tabManager
				.switchToNewTabByTitle("Average Job Size Dashboard Report | Housecall Pro Help Center");
		HelpPage helpPage = new HelpPage(driver);
		Assert.assertTrue(helpPage.searchForText("Average Job Size Dashboard Report"));
		tabManager.closeTabAndSwitchtoAnother(helpWindow, mainWindow);
	}

	@Test
	public void averageJobSizeCreateJob() {

		jobHelper.createJob(customer);
		EditJobPage editJob = new EditJobPage(driver);
		FinishJobWidget finishJob = editJob.clickFinishJob();
		finishJob.clickFinish();

		navigationHelper.goToDashboardPage();
		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		Assert.assertNotEquals(avgJobSizeCard.getTodaysRevenue(), 0, "This month Average Job Size should not be 0 ");

	}

	@Test
	public void givePositiveFeedback() {
		navigationHelper.goToDashboardPage();
		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		avgJobSizeCard.clickFeedback();
		FeedbackWidget feedback = new FeedbackWidget(driver);
		feedback.clickLikeReport();
		feedback.enterComments("Like Test");
		feedback.clickSend();
		Assert.assertTrue(feedback.searchForText("Thanks for your feedback"));
		feedback.clickClose();
	}

	@Test
	public void giveNegativeFeedback() {
		navigationHelper.goToDashboardPage();
		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		avgJobSizeCard.clickFeedback();
		FeedbackWidget feedback = new FeedbackWidget(driver);
		feedback.clickDislikeReport();
		feedback.enterComments("dislike Test");
		feedback.clickSend();
		Assert.assertTrue(feedback.searchForText("Thanks for your feedback"));
		feedback.clickClose();
	}

	@Test
	public void averageJobSizeDeleteJob() {
		navigationHelper.goToDashboardPage();

		AverageJobSizeCard avgJobSizeCard = new AverageJobSizeCard(driver);
		String userAgent = (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;");
	
		LOG.info("User Agent "+ userAgent);
		double startingRevenue = avgJobSizeCard.getTodaysRevenue();
		LOG.info("TEST STEP: Fetching intital revenue and creating job to raise average. Starting Revenue = "+startingRevenue);
        Assert.assertNotEquals(startingRevenue, "Today's revenue should not be 0 ");
		Job job = jobHelper.createJob(100, "JobReport");
		EditJobPage editJob = new EditJobPage(driver);
		FinishJobWidget finishJob = editJob.clickFinishJob();
		finishJob.clickFinish();
		
		navigationHelper.goToDashboardPage();
		avgJobSizeCard.waitForPageToLoad(5);
		avgJobSizeCard = new AverageJobSizeCard(driver);
		double todaysRevenue = avgJobSizeCard.getTodaysRevenue();
		LOG.info("TEST STEP: Fetching revenue after job creation. Revenue = "+ todaysRevenue);
		takeScreenShot("Reporting_");
		//FIXME:This might be an anti pattern .
		try {
			Assert.assertTrue(todaysRevenue > startingRevenue,
					"The average job size did not increase. The starting revenue was " + startingRevenue
							+ "The current revenue is " + todaysRevenue);
		} finally {
			LOG.info("TEST STEP: Delete job to revert revenue ");
			deleteJobFromCustomerPage(job);
		}
		navigationHelper.goToDashboardPage();
		avgJobSizeCard = new AverageJobSizeCard(driver);
		Assert.assertEquals(avgJobSizeCard.getTodaysRevenue(), startingRevenue,
				"Todays Revenue = is not reverted back to the original $ " + startingRevenue);

	}

	private void deleteJobFromCustomerPage(Job job) {
		navigationHelper.goToCustomersListPage();
		customerHelper.searchAndSelectCustomer(job.getCustomer());
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		JobsTab jobs = customerDetails.clickJobs();
		jobs.clickOnJob(job.getInvoiceNumber());
		EditJobPage editJob = new EditJobPage(driver);
		editJob.clickJobOptions();
		editJob.clickDeleteFromJobOptions();
		editJob.waitForPageToLoad(1);
		editJob.confirmDelete();
		editJob.waitForDeletedMessageToClear();
		navigationHelper.goToDashboardPage();
		customerHelper.deleteCustomer(job.getCustomer());
	}

}
