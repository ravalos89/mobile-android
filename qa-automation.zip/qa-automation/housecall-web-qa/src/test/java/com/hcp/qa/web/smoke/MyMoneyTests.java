package com.hcp.qa.web.smoke;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.PropertiesReader;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.mymoney.MyMoneyPage;
import com.hcp.qa.pages.mymoney.PayoutsPage;
import com.hcp.qa.web.BaseWebTest;

public class MyMoneyTests extends BaseWebTest {

	@BeforeClass
	public void signInAsPaymentPro() {
		loginHelper.login("qa+payments@housecallpro.com", PropertiesReader.getInstance().getPassword());
	}


	@BeforeMethod
	public void goToDashboard() {
		navigationHelper.goToDashboardPage();
	}

	@Test
	public void checkPayouts() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickMyMoney();
		MyMoneyPage myMoneyPage = new MyMoneyPage(driver);
		
		Assert.assertTrue(myMoneyPage.isPayoutsPageTitleVisible(),
				"Payouts Title is not displayed");
		PayoutsPage payouts=new PayoutsPage(driver);
		
		Assert.assertTrue(payouts.isPendingTransactionVisible(),"Pending Transactions table is not visible");
		Assert.assertTrue(payouts.isChargeDateVisible(),"Charge date in Pending Transactions table is not visible");
		
		Assert.assertTrue(payouts.isMyPayoutsVisible(),"My Payouts table is not visible");
		Assert.assertTrue(payouts.isDepositDateVisible(),"Deposit date in My Payouts table is not visible");
	}
	

	@Test
	public void checkBusinessFinancing() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickMyMoney();
		MyMoneyPage myMoneyPage = new MyMoneyPage(driver);
		myMoneyPage.clickBusinessFinancing();
		Assert.assertTrue(myMoneyPage.isBusinessFinancingTextDisplayed(),
				"Business Financing Text is not displayed after clicking Business Financing link");
	}
	
	@Test
	public void checkCardReader() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickMyMoney();
		MyMoneyPage myMoneyPage = new MyMoneyPage(driver);
		myMoneyPage.clickCardReader();
	
		Assert.assertTrue(myMoneyPage.isBuyNowBtnDisplayed(),
				"Buy Now Button is not displayed after clicking Card reader link");
		myMoneyPage.closeCardReader();
	}
	
	@Test
	public void checkExpenseCards() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.getTopMenu().clickMyMoney();
		MyMoneyPage myMoneyPage = new MyMoneyPage(driver);
		myMoneyPage.clickExpenseCards();
		Assert.assertTrue(myMoneyPage.isCurrentBalanceDisplayed(),
				"Current Balance is not displayed after clicking Expense cards link");
	}


}
