package com.hcp.qa.web;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IConfigurable;
import org.testng.IConfigureCallBack;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.hcp.qa.api.EmployeeApiClient;
import com.hcp.qa.elements.driver.HcpChromeDriver;
import com.hcp.qa.helpers.CustomerHelper;
import com.hcp.qa.helpers.JobHelper;
import com.hcp.qa.helpers.LoginHelper;
import com.hcp.qa.helpers.NavigationHelper;
import com.hcp.qa.models.Customer;
import com.hcp.qa.testng.Retriable;

import io.github.bonigarcia.wdm.WebDriverManager;

import static java.time.Duration.ofSeconds;

public abstract class BaseWebTest implements IConfigurable {

	enum BrowserNames {
		CHROME, FIREFOX, SAFARI
	}

	protected static WebDriver driver;

	protected static NavigationHelper navigationHelper;
	protected static LoginHelper loginHelper;
	protected static CustomerHelper customerHelper;
	protected static JobHelper jobHelper;
	protected EmployeeApiClient employeeApiClient;

	protected static BrowserNames targetBrowser = BrowserNames
			.valueOf(System.getProperty("targetBrowser", "CHROME").toUpperCase());

	private static final Logger LOG = LoggerFactory.getLogger(BaseWebTest.class);

	protected static Customer customer;

	public int WAIT_TIME_FOR_EMAIL = 20;
	private static boolean isCustomerRequired;

	@BeforeSuite
	@Parameters("isCustomerRequiredBySuite")
	public static void setupSuite(@Optional("true") String isCustomerRequiredBySuite) {
		isCustomerRequired = Boolean.parseBoolean(isCustomerRequiredBySuite);
		switch (targetBrowser) {
		case CHROME:
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--headless");
			options.addArguments("--disable-gpu");
			options.addArguments("--disable-dev-shm-usage");
			options.addArguments("--no-sandbox");
			options.addArguments("--allow-running-insecure-content");
			options.addArguments("--window-size=1920,1080");
			options.addArguments("--use-fake-ui-for-media-stream");
			options.addArguments("--use-fake-device-for-media-stream");
			options.addArguments("--mute-audio");
			driver = new HcpChromeDriver(options);
			break;

		case SAFARI:// Safari does not support headless mode run locally only. not working correctly
			SafariOptions safariOptions = new SafariOptions();
			driver = new SafariDriver(safariOptions);
			break;

		case FIREFOX:
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions firefoxOptions = new FirefoxOptions();
			firefoxOptions.addArguments("--headless");
			firefoxOptions.addArguments("--disable-gpu");
			driver = new FirefoxDriver(firefoxOptions);
			break;

		default:
			LOG.error("Browser Not Supported");
			System.exit(0);
		}
		driver.manage().timeouts().implicitlyWait(ofSeconds(15));
		navigationHelper = new NavigationHelper(driver);
		loginHelper = new LoginHelper(driver);
		customerHelper = new CustomerHelper(driver);
		jobHelper = new JobHelper(driver);
		LOG.info("Starting Test suite with Url: " + navigationHelper.getLoginUrl());
		if (isCustomerRequired)
			setUpCustomer();
	}

	private static void setUpCustomer() {
		customer = customerHelper.createCustomer("TestC");
	}

	@AfterSuite(alwaysRun = true)
	public void teardown() {
		if (isCustomerRequired) {
			loginHelper.login();
			customerHelper.deleteCustomer(customer);
			loginHelper.logout();
		}
		LOG.info("Closing down webdriver");
		if (driver != null) {
			driver.close();
			driver.quit();
		}
	}

	public static void takeScreenShot(String name) {

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String time = formater.format(calendar.getTime()) + ".png";
		String path = "test-output/screenshots/" + name + "_" + time;
		String pathHTML = "../test-output/screenshots/" + name + "_" + time;

		try {
			FileUtils.copyFile(scrFile, new File(path));
			Reporter.log("[[ATTACHMENT|" + path, true);
			Reporter.log("<font color='red'>***Placed screen shot in: " + pathHTML + " ***</font>", false);
			Reporter.log("<br> <img src='" + pathHTML + "' height='400' with='400'/></b>", false);
		} catch (IOException e) {
			Reporter.log("<font color='red'>Failed to create screen shot file :</font>" + e.getMessage(),false);
		}

	}

	@Override
	public void run(IConfigureCallBack callBack, ITestResult testResult) {
		Retriable retriable = testResult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(Retriable.class);
		int attempts = 1;
		if (retriable != null) {
			attempts = retriable.attempts();
		}
		for (int attempt = 1; attempt <= attempts; attempt++) {
			callBack.runConfigurationMethod(testResult);
			if (testResult.getThrowable() == null) {
				break;
			} else {
				takeScreenShot(testResult.getTestClass().getName() + "." + testResult.getName() + "_FAILED");
			}
		}
	}
}
