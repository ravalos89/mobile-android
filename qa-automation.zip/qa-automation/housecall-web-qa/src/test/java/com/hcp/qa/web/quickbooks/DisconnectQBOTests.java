package com.hcp.qa.web.quickbooks;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.PropertiesReader;
import com.hcp.qa.pages.common.PageUtils;
import com.hcp.qa.pages.customer.CustomerListOptionsMenu;
import com.hcp.qa.pages.customer.CustomersListPage;
import com.hcp.qa.pages.quickbooks.DisconnectQuickBooksDialog;
import com.hcp.qa.pages.quickbooks.QBOImportPage;
import com.hcp.qa.web.BaseWebTest;
import com.hcp.qa.web.WebTestListener;
@Listeners(WebTestListener.class)
public class DisconnectQBOTests extends BaseWebTest{

	String qboUser = PropertiesReader.getInstance().getQBOUser();
	
	@Test
	public void disconnectQuickBooks()
	{
		loginHelper.login(qboUser, PropertiesReader.getInstance().getPassword());
		navigationHelper.goToCustomersListPage();
		CustomersListPage customers = new CustomersListPage(driver);
		customers.waitForPageToLoad(2);
		customers.clickThreeDotsIcon();
		CustomerListOptionsMenu options = new CustomerListOptionsMenu(driver);
		options.clickImportFromQuickooks();

		QBOImportPage qboImport = new QBOImportPage(driver);
		PageUtils.scrollToBottom(driver);
		qboImport.waitForPageToLoad(2);
		qboImport.clickDisconnectQuickBooks();
		qboImport.waitForPageToLoad(1);
		DisconnectQuickBooksDialog disconnectDialog=new DisconnectQuickBooksDialog(driver);
		disconnectDialog.selectDisconnectReason();
		
		disconnectDialog.confirmDisconnect();
		disconnectDialog.clickDisconnect();
	
		Assert.assertFalse(qboImport.isDisconnectFromQuickBooksDisplayed(),"Disconnect from Quickbooks should not be Displayed");
		
		
	
		
	}
}
