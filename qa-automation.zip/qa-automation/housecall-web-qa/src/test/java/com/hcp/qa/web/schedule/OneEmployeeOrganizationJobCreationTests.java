package com.hcp.qa.web.schedule;

import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.common.ProDto;
import com.hcp.qa.helpers.OnboardingHelper;
import com.hcp.qa.helpers.StringHelper;
import com.hcp.qa.pages.common.CustomerSearchWidget;
import com.hcp.qa.pages.customer.AddNewCustomerPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.JobFlowWidget;
import com.hcp.qa.pages.job.NewJobPage;
import com.hcp.qa.testng.Retriable;
import com.hcp.qa.web.BaseWebTest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class OneEmployeeOrganizationJobCreationTests extends BaseWebTest {

    private ProDto pro;
    private NewJobPage newJob;

    @BeforeClass
    @Retriable
    public void setUp() {
        pro = new OnboardingHelper(driver).createNewProThroughApi();
    }

    @BeforeMethod
    public void jobCreation() {
        navigationHelper.goToNewJobPage();

        newJob = new NewJobPage(driver);
        newJob.turnProModeOn();
        CustomerSearchWidget customerWidget = new CustomerSearchWidget(driver);
        customerWidget.clickNewCustomer();

        AddNewCustomerPage addCustomer = new AddNewCustomerPage(driver);
        addCustomer.enterFirstName("Schedule customer");
        addCustomer.enterLastName("Customer last name");
        addCustomer.clickCreateCustomer();
    }

    @Test
    public void createUnscheduledJob() {
        assertThat(newJob.isDispatchByDisplayed())
                .as("When org has one employee, this field should not be visible, only employee assigned by default")
                .isFalse();

        newJob.save();
        SoftAssertions soft = new SoftAssertions();
        assertAssignedEmployee(soft);

        JobFlowWidget flowWidget = new JobFlowWidget(driver);
        soft.assertThat(flowWidget.getScheduleText()).isEqualTo("SCHEDULE");
        soft.assertAll();
    }

    @Test
    public void createScheduledJob() {
        assertThat(newJob.isDispatchByDisplayed())
                .as("When org has one employee, this field should not be visible, only employee assigned by default")
                .isFalse();
        newJob.enterStartTime("15:33");
        assertThat(newJob.isDispatchByDisplayed())
                .as("When org has one employee, this field should not be visible, only employee assigned by default")
                .isFalse();
        newJob.save();

        SoftAssertions soft = new SoftAssertions();
        assertAssignedEmployee(soft);

        JobFlowWidget flowWidget = new JobFlowWidget(driver);
        soft.assertThat(flowWidget.getScheduleText()).contains("3:33 pm-4:33 pm");
        soft.assertAll();
    }

    private void assertAssignedEmployee(SoftAssertions soft) {
        EditJobPage editJob = new EditJobPage(driver);
        List<String> employees = editJob.getAssignedEmployees();

        soft.assertThat(employees).hasSize(1);
        String firstNameCapitalized = StringHelper.capitalizeEachWord(pro.getFirstName());
        soft.assertThat(employees).containsExactly(firstNameCapitalized + " " + pro.getLastName());
    }

}
