package com.hcp.qa.web.reporting;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingJobsPage;
import com.hcp.qa.reports.ReportUtils;
import com.hcp.qa.web.BaseWebTest;

public class DefaultOptionsForJobsTest extends BaseWebTest {
	DashboardPage dashboard;
	ReportingJobsPage reportingJobs;
	ReportUtils reportUtils;
	ReportingHelper reportingHelper = new ReportingHelper();
	LeftMenuWidget leftMenuWidget;

	@BeforeTest
	public void loginAndGoToReporting() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickJobs();
		reportingJobs = new ReportingJobsPage(driver);
		reportUtils = new ReportUtils();

	}
	
	@Test(priority=6)
	public void validateMessages() {
		
		reportingJobs.clickHcpCoachVideoDate();
		reportingJobs.switchToFrame();
		verifyMessage();
		reportingJobs.clickClose();
		reportingJobs.switchToDefaultFrame();

	}

	@Test(priority=5)
	public void validateDateOptions() {
		List<String> actualDateOptions = reportingJobs.getDateSectionOptions();
		List<String> expectedDateOptions = reportingHelper.getExpectedDateOptionsJobs();
		reportingHelper.verifyOptions(actualDateOptions, expectedDateOptions);
		
		if(!reportingJobs.isHcpCoachVideoDateDisplayed()) {
			reportUtils.fail("buttons is not in the page");
			}



	}

	@Test(priority=4)
	public void validateTypeOptions() {
		List<String> actualTypeOptions = reportingJobs.getTypeSectionOptions();
		List<String> expectedTypeOptions = reportingHelper.getExpectedTypeOptionsJobs();
		reportingHelper.verifyOptions(actualTypeOptions, expectedTypeOptions);

		if(!reportingJobs.isHcpCoachVideoTypeDisplayed()) {
			reportUtils.fail("buttons is not in the page");
			}
	}

	@Test(priority=3)
	public void validateEmployeeOptions() {
		List<String> actualEmployeeOptions = reportingJobs.getEmployeeSectionOptions();
		List<String> expectedEmployeeOptions = reportingHelper.getExpectedEmployeeOptionsJobs();
		reportingHelper.verifyOptions(actualEmployeeOptions, expectedEmployeeOptions);

		if(!reportingJobs.isHcpCoachVideoEmployeeDisplayed()) {
			reportUtils.fail("buttons is not in the page");
			}

	}

	@Test(priority=2)
	public void validateCustomerOptions() {
		List<String> actualCustomerTrackingOptions = reportingJobs.getCustomerSectionOptions();
		List<String> expectedCustomerOptions = reportingHelper.getExpectedCustomerOptionsJobs();
		reportingHelper.verifyOptions(actualCustomerTrackingOptions, expectedCustomerOptions);
	}

	@Test(priority=1)
	public void validateTimeTrackingOptions() {
		List<String> actualTimeTrackingOptions = reportingJobs.getTimeTrackingSectionOptions();
		List<String> expectedTimeTrackingOptions = reportingHelper.getExpectedTimeTrackingOptionsJobs();
		reportingHelper.verifyOptions(actualTimeTrackingOptions, expectedTimeTrackingOptions);
		if(!reportingJobs.isHcpCoachVideoTimeTrackingDisplayed()) {
			reportUtils.fail("buttons is not in the page");
			}

	}



	private void verifyMessage() {
		String expectedText = "HCP is partnering with CONQUER to offer you the best strategies to running a successful business. "
				+ "We’re bringing together tools, tips and resources from industry experts to give you the best practices you need to "
				+ "make informed decisions for your business.";

		Assert.assertEquals(reportingJobs.getMessageText(), expectedText, "The Message Text is not correct ");
	}

	

}
