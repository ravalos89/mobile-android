package com.hcp.qa.web.reporting;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.LeadConversionByWeekPage;
import com.hcp.qa.pages.reporting.LeadsPage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.web.BaseWebTest;

public class LeadConversionByWeekTest extends BaseWebTest {

	private DashboardPage dashboard;
	private LeadsPage leadsPage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private LeadConversionByWeekPage leadConversionByWeek;
	private LeftMenuWidget leftMenuWidget;

	@BeforeTest
	public void loginHCP() {
		dashboard = loginHelper.login();
		driver.navigate().refresh();
		dashboard.getTopMenu().clickReporting();
		leadsPage = new LeadsPage(driver);
		leadConversionByWeek = new LeadConversionByWeekPage(driver);
		leftMenuWidget = new LeftMenuWidget(driver);
		leftMenuWidget.clickLeads();
		Assert.assertTrue(leadsPage.isCreateReportDisplayed(),"button is not in the page");
		leadsPage.openDateOption("Lead conversion by week");
	}

	@Test
	public void verifyOptionsConversionByWeek() {
		
		leadConversionByWeek.clickDateRange();
		reportingHelper.verifyOptions(leadConversionByWeek.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsLeads());
		leadConversionByWeek.clickOnPage();
		leadConversionByWeek.clickActionDate();
		reportingHelper.verifyOptions(leadConversionByWeek.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsLeads());
		leadConversionByWeek.clickOnPage();
	}


}
