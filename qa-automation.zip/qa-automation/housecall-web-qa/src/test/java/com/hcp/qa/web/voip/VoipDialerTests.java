package com.hcp.qa.web.voip;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.common.TabManager;
import com.hcp.qa.pages.navigation.TopNavigationWidget;
import com.hcp.qa.pages.navigation.TopNavigationWidgetFactory;
import com.hcp.qa.pages.voip.Dialer;
import com.hcp.qa.web.BaseWebTest;

public class VoipDialerTests extends BaseWebTest {

	@Test(groups = "smoke")
	public void testVoipDialerDisplayed() {
		loginHelper.login();
		TopNavigationWidget topNavigation = TopNavigationWidgetFactory.createTopNavigationWidget(driver);
		topNavigation.clickPhone();

		String mainWindow = driver.getWindowHandle();
		TabManager tabManager = new TabManager(driver);
		String dialerWindow = tabManager.switchToLatestTab(mainWindow);
		Dialer dialer = new Dialer(driver);
		Assert.assertTrue(dialer.isMainBusinessLineDisplayed(), "Dialer is not displayed");
		tabManager.closeTabAndSwitchtoAnother(dialerWindow, mainWindow);
	}

}
