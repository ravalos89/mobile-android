package com.hcp.qa.web.reporting;

import org.testng.annotations.Test;

import com.hcp.qa.helpers.ReportingHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.reporting.AverageJobSizePage;
import com.hcp.qa.pages.reporting.LeftMenuWidget;
import com.hcp.qa.pages.reporting.ReportingJobsPage;
import com.hcp.qa.reports.ReportUtils;
import com.hcp.qa.web.BaseWebTest;

public class AverageJobSizeTest extends BaseWebTest {
	private DashboardPage dashboard;
	private ReportingJobsPage reportingJobs;
	private ReportUtils reportUtils = new ReportUtils();
	private AverageJobSizePage averageJobSizePage;
	private ReportingHelper reportingHelper = new ReportingHelper();
	private LeftMenuWidget leftMenuWidget;
	
	@Test
	public void averageJobSize() {
	dashboard = loginHelper.login();
	driver.navigate().refresh();
	dashboard.getTopMenu().clickReporting(); 
	leftMenuWidget = new LeftMenuWidget(driver);
	leftMenuWidget.clickJobs();
	reportingJobs = new ReportingJobsPage(driver);
	reportingJobs.openDateOption("Average job size");
	averageJobSizePage = new AverageJobSizePage(driver);
	if(!averageJobSizePage.isMonthColumnDisplayed()) {
		reportUtils.fail("Month column is not in page ");
		}
	
	if(!averageJobSizePage.isAverageJobSizeColumnDisplayed()) {
		reportUtils.fail("Avg Job Size column is not in page ");
		}
	
	averageJobSizePage.clickDateRange();
	reportingHelper.verifyOptions(averageJobSizePage.getDateRangeOptions(),reportingHelper.getExpectedDateRangeOptionsJobs());
	averageJobSizePage.clickOnPage();
	averageJobSizePage.clickActionDate();
	reportingHelper.verifyOptions(averageJobSizePage.getActionDateOptions(),reportingHelper.getExpectedActionDateOptionsJobs());
	averageJobSizePage.clickOnPage();
	}
}