package com.hcp.qa.web.task;

import com.hcp.qa.api.EmployeeApiClient;
import com.hcp.qa.common.ProDto;
import com.hcp.qa.helpers.DataGenerator;
import com.hcp.qa.helpers.OnboardingHelper;
import com.hcp.qa.models.mobile.customer.CustomerPayload;
import com.hcp.qa.models.mobile.customer.CustomerResponse;
import com.hcp.qa.models.mobile.pros.DispatchablePros;
import com.hcp.qa.models.mobile.pros.OrganizationPros;
import com.hcp.qa.models.mobile.task.TaskPayload;
import com.hcp.qa.models.mobile.task.TaskResponse;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.navigation.TasksSidebar;
import com.hcp.qa.pages.onboarding.WelcomePage;
import com.hcp.qa.pages.task.TaskWidget;
import com.hcp.qa.web.BaseWebTest;
import lombok.extern.slf4j.Slf4j;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@Slf4j
public class TaskTests extends BaseWebTest {
	DashboardPage dashboard;
	ProDto pro;
	CustomerResponse taskCustomer;
	private final String taskDescription = "Task description";

	@BeforeClass
	public void setupOrganisationAndCustomer() {
		pro = new OnboardingHelper(driver).createNewProThroughApi();
		log.info("Will perform tests on user: " + pro.getEmail());
		employeeApiClient = new EmployeeApiClient(pro.getEmail(), pro.getPassword());
		CustomerPayload customerDto = CustomerPayload.builder()
				.firstName("QA")
				.lastName(DataGenerator.getInstance().getUniqueName("Task"))
				.build();
		taskCustomer = employeeApiClient.createCustomer(customerDto).as(CustomerResponse.class);

		WelcomePage welcomePage = new WelcomePage(driver);
		welcomePage.clickCloseVideo();
		dashboard = new DashboardPage(driver);
	}

	@Test
	public void createTask() {
		goToTasks();

		String title = DataGenerator.getInstance().getUniqueName("CreateTask");
		createTask(title);
		TaskWidget taskWidget = new TaskWidget(driver);
		Assert.assertTrue(taskWidget.searchForText(title));
	}


	@Test
	public void markTaskAsDone() {
		String title = DataGenerator.getInstance().getUniqueName("DoneTask");
		createTask(title);
		goToTasks();

		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.markTaskAsComplete(title);
		tasksSidebar.waitForTaskCompletedMessage();
		tasksSidebar.clickCompletedTasksSectionHeader();
		assertThat(tasksSidebar.isTaskInCompletedTab(title))
				.as("Completed task not displayed/found")
				.isTrue();
	}

	@Test
	public void editTask() {
		String title = DataGenerator.getInstance().getUniqueName("EdTask");
		createTaskApi(title);
		goToTasks();

		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.clickEditTaskIcon(title);
		String updatedTitle = title + " updated";
		TaskWidget taskWidget = new TaskWidget(driver);
		taskWidget.addTitle(updatedTitle);
		taskWidget.clickCloseOnEditTask();
		Assert.assertTrue(tasksSidebar.searchForText(updatedTitle));
	}

	@Test
	public void deleteTask() {
		String title = DataGenerator.getInstance().getUniqueName("Del Task");
		createTaskApi(title);
		goToTasks();

		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		assertThat(tasksSidebar.isTaskVisible(title)).as("Could not fulfill precondition").isTrue();
		deleteTask(title);
		assertThat(tasksSidebar.isTaskVisible(title)).as("Task still present after deleting").isFalse();
	}

	@Test
	public void deleteTaskFromCompletedList() {
		String taskTitle = DataGenerator.getInstance().getUniqueName("DelComp Task");
		createTaskApi(taskTitle, true);
		goToTasks();

		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.clickCompletedTasksSectionHeader();
		tasksSidebar.deleteCompletedTask(taskTitle);
		Assert.assertTrue(tasksSidebar.searchForText("Task deleted"), "Task deleted message not found");
	}

	@Test
	public void markTaskAsIncomplete() {
		String title = DataGenerator.getInstance().getUniqueName("InComp Task");
		createTaskApi(title);
		goToTasks();

		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.markTaskAsComplete(title);
		tasksSidebar.waitForTaskCompletedMessage();
		tasksSidebar.clickCompletedTasksSectionHeader();
		tasksSidebar.markTaskAsIncomplete(title);
		tasksSidebar.waitForTaskIncompleteMessage();
		Assert.assertTrue(tasksSidebar.searchForText("Task incomplete"), "Task incomplete message not found");
	}

	private void goToTasks() {
		navigationHelper.goToGetStartedPage();
		dashboard.waitForPageToLoad(2);
		dashboard.getTopMenu().clickTasks();
	}

	private void createTask(String title) {
		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.clickNewTaskLink();
		TaskWidget taskWidget = new TaskWidget(driver);
		taskWidget.addTitle(title);
		taskWidget.addDescription(taskDescription);
		taskWidget.addDateToTask();
		taskWidget.addEmployeeToTask(pro.getDisplayName());
		taskWidget.addCustomerToTask(taskCustomer.getBillableName());
		taskWidget.waitForSavedLabel();
		taskWidget.clickCloseIcon();
		taskWidget.waitForPageToLoad(1);
	}

	private void deleteTask(String title) {
		TasksSidebar tasksSidebar = new TasksSidebar(driver);
		tasksSidebar.clickEditTaskIcon(title);
		TaskWidget addTaskWidget = new TaskWidget(driver);
		addTaskWidget.clickDeleteTaskIcon();
		tasksSidebar.waitForTaskDeletedMessage();
		tasksSidebar.clickCloseIcon();
	}

	private void createTaskApi(String title) {
		createTaskApi(title, false);
	}

	private void createTaskApi(String title, boolean isCompleted) {
		OrganizationPros pros = employeeApiClient.getPros().as(OrganizationPros.class);
		DispatchablePros taskPro = pros.getDispatchablePros().get(0);

		TaskPayload task = TaskPayload.builder()
				.id(UUID.randomUUID().toString())
				.title(title)
				.description(taskDescription)
				.serviceProId(taskPro.getId())
				.completed(isCompleted)
				.build()
				.setDue(LocalDate.now());

		employeeApiClient.createTask(task);
	}

	@AfterMethod
	public void deleteTasks() {
		TaskResponse[] tasks = employeeApiClient.getTasks().as(TaskResponse[].class);
		Arrays.stream(tasks).forEach(t -> archiveTask(t.getId()));
	}

	private void archiveTask(String taskId) {
		TaskPayload task = TaskPayload.builder()
				.id(taskId)
				.archived(true)
				.build();
		employeeApiClient.createTask(task);
	}

	@AfterClass
	public void logout() {
		driver.manage().deleteAllCookies();
	}

}
