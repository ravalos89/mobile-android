package com.hcp.qa.web.smoke;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.pages.billing.pages.MyPlanPage;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.ConfigureYourPlanModal;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.PickYourPlanModal;
import com.hcp.qa.pages.billing.modals.changeplanpaywall.ReviewAndPayModal;
import com.hcp.qa.pages.common.SettingsPage;
import com.hcp.qa.web.BaseWebTest;

import static com.hcp.qa.pages.billing.enums.BillingPlanName.MAX;

public class BillingTests extends BaseWebTest {

    @BeforeClass
    public void setUp() {
        loginHelper.login();
    }

    @Test
    public void navigationThroughPaywall() {
        navigationHelper.goToSettingsPage();
        new SettingsPage(driver).clickBillingIcon();
        MyPlanPage myPlan = new MyPlanPage(driver);
        myPlan.chooseToChangePlan();
        PickYourPlanModal pickYourPlanModal = new PickYourPlanModal(driver);

        pickYourPlanModal.selectPlan(MAX);
        pickYourPlanModal.proceedToConfigureYourPlanModal();
        ConfigureYourPlanModal configureYourPlanModal = new ConfigureYourPlanModal(driver);
        configureYourPlanModal.waitForAmountDueRenewal();
        configureYourPlanModal.proceedToReviewAndPayPage();

        ReviewAndPayModal reviewAndPayModal = new ReviewAndPayModal(driver);
        reviewAndPayModal.waitForUpdatePlanButton();
        reviewAndPayModal.clickBackButton();
        configureYourPlanModal.waitForAnnualCadenceRadiobutton();
        configureYourPlanModal.clickBackButton();
        pickYourPlanModal.clickDurationToggle();
        pickYourPlanModal.clickCancelButton();

        myPlan.chooseToChangePlan();
    }
}
