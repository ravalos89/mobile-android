package com.hcp.qa.web.serviceplan;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.helpers.ServicePlanHelper;
import com.hcp.qa.models.Customer;
import com.hcp.qa.pages.customer.CustomerDetailsPage;
import com.hcp.qa.pages.job.EditJobPage;
import com.hcp.qa.pages.job.ServicePlanTileWidget;
import com.hcp.qa.web.BaseWebTest;

public class ServicePlanVisitTests extends BaseWebTest {
	String planName = "Test Service Plan";
	ServicePlanHelper servicePlanHelper;
	Customer servicePlanCustomerZerovisit;
	Customer servicePlanCustomerOneVisit;
	
	@BeforeClass
	public void setUp() {
		loginHelper.login();
		driver.navigate().refresh();
		servicePlanHelper = new ServicePlanHelper(driver);
		
		
	}
	
	@Test
	public void servicePlanWithZeroVisit() {
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
		servicePlanHelper.addServicePlanWithVisits(planName,"0");	
		servicePlanCustomerZerovisit= customerHelper.createCustomer("ServicePlanCustomer", ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key"));
		
		String customerId = servicePlanCustomerZerovisit.getId();
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId, planName);
		navigationHelper.goToCustomer(customerId);
		
		CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage(driver);
		customerDetailsPage.clickAddNewJob();
		
		ServicePlanTileWidget servicePlanTile = new ServicePlanTileWidget(driver);
		Assert.assertTrue(servicePlanTile.isNoVisitsMessagePresent(),
				"Service plan No visits message not present");
	}
	
	@Test(dependsOnMethods = "servicePlanWithZeroVisit")
	public void servicePlanWithOneVisit() {
		servicePlanHelper.goToServicePlanPage();
		servicePlanHelper.deleteExistingServicePlans();	
		servicePlanHelper.addServicePlanWithVisits(planName,"1");	
		
		servicePlanCustomerOneVisit= customerHelper.createCustomer("ServicePlanCustomer", ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.user.api.key"));
		
		String customerId = servicePlanCustomerOneVisit.getId();
		servicePlanHelper.acceptServicePlanForCustomerWithCC(customerId, planName);
		navigationHelper.goToCustomer(customerId);
		
		CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage(driver);
		customerDetailsPage.clickAddNewJob();
		
		ServicePlanTileWidget servicePlanTile = new ServicePlanTileWidget(driver);
		Assert.assertTrue(servicePlanTile.isVisitDueMessagePresent(),
				"Service plan visit due message not present");
		
	}
	
	@Test(dependsOnMethods = "servicePlanWithOneVisit")
	public void servicePlanWithVisitCompleted() {
		EditJobPage editJob = new EditJobPage(driver);
		ServicePlanTileWidget servicePlanTile = new ServicePlanTileWidget(driver);
		servicePlanTile.waitForPageToLoad(2);
		servicePlanTile.clickServicePlanVisit();
		servicePlanTile.selectVisit1();
		servicePlanTile.clickSave();
		editJob.clickFinishJob().clickFinish();
		String customerId = servicePlanCustomerOneVisit.getId();
		navigationHelper.goToCustomer(customerId);
		CustomerDetailsPage editCustomer = new CustomerDetailsPage(driver);
		editCustomer.clickAddNewJob();
		
		Assert.assertTrue(servicePlanTile.isVisitsCompletedMessagePresent(),
				"Service plan visit completed message not present");	
	}
	
	@AfterClass
	private void cleanUp() {
		customerHelper.deleteCustomer(servicePlanCustomerZerovisit);
		customerHelper.deleteCustomer(servicePlanCustomerOneVisit);
		loginHelper.logout();
	}

}
