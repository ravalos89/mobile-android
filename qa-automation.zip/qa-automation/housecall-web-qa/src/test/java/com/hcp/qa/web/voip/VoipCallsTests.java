package com.hcp.qa.web.voip;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.elements.driver.HcpChromeDriver;
import com.hcp.qa.helpers.LoginHelper;
import com.hcp.qa.helpers.WaitHelper;
import com.hcp.qa.pages.dashboard.DashboardPage;
import com.hcp.qa.pages.voip.Dialer;
import com.hcp.qa.web.BaseWebTest;

public class VoipCallsTests extends BaseWebTest {
  DashboardPage dashboardA;
  DashboardPage dashboardB;
  WebDriver driverB ;
	private String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
  private String voiceUrl = baseUrl + "/app/voice";
	private String voiceMonitoringEmailA = ConfigHandler.getStringPropertyValueFromKey("hcp.web.voip.monitoring.emaila");
	private String voiceMonitoringEmailB = ConfigHandler.getStringPropertyValueFromKey("hcp.web.voip.monitoring.emailb");
	private String password = ConfigHandler.getStringPropertyValueFromKey("hcp.web.voip.monitoring.password");
	private String organizationBBusinessLineNumber = ConfigHandler.getStringPropertyValueFromKey("hcp.web.voip.monitoring.organizationb.businessLineNumber");

  @BeforeClass
  private void setup() {
    dashboardA=loginHelper.login(voiceMonitoringEmailA, password);
    driverB = initializeSecondWebDriver();

    LoginHelper loginHelperB = new LoginHelper(driverB);
    dashboardB=loginHelperB.login(voiceMonitoringEmailB, password);

  }

  @Test
  public void initiateOutboundInboundCall() {
    driver.get(voiceUrl);
   
	Dialer dialerA = new Dialer(driver);
    dialerA.enterPhoneNumber(organizationBBusinessLineNumber);
    dialerA.clickDialButton();

    driverB.get(voiceUrl);
	Dialer dialerB = new Dialer(driverB);
	dashboardB.waitForPageToLoad(2);
    dialerB.clickAnswerButton();

    WaitHelper waitHelper = new WaitHelper(driverB);
    dashboardB.waitForPageToLoad(2);
    waitHelper.waitForElementToBeVisible(dialerB.endCallButton);
    dialerB.clickEndCallButton();

    waitHelper.waitForElementToBeVisible(dialerB.dialButton);
    
    
  }

  private WebDriver initializeSecondWebDriver() {
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--headless");
    options.addArguments("--mute-audio");
    options.addArguments("--disable-gpu");
    options.addArguments("--disable-dev-shm-usage");
    options.addArguments("--no-sandbox");
    options.addArguments("--allow-running-insecure-content");
    options.addArguments("--window-size=1920,1080");
    options.addArguments("--incognito");
    options.addArguments("--use-fake-ui-for-media-stream");
    options.addArguments("--use-fake-device-for-media-stream");
    WebDriver driverB =new HcpChromeDriver(options);
    driverB.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    return driverB;
  }
  
  @AfterClass
  public void closeDriver()
  {
		if (driverB != null) {
			driverB.close();
			driverB.quit();
		}
  }
}
