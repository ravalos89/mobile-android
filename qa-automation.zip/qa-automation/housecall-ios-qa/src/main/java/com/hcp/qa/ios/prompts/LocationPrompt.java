package com.hcp.qa.ios.prompts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.ios.pages.common.Page;

import io.appium.java_client.ios.IOSDriver;

public class LocationPrompt extends Page{
	public LocationPrompt(IOSDriver driver) {
		super(driver);
	}
	@FindBy(xpath = "//XCUIElementTypeButton[@name='SHARE YOUR LOCATION']")
	private WebElement allowBtn;

	@FindBy(xpath = "//XCUIElementTypeButton[@name='Allow Once']")
	private WebElement allowOnceBtn;
	public void clickAllowLocationAccess() {
		waitForPageToLoad(2);
		allowBtn.click();
		allowOnceBtn.click();

	}

}
