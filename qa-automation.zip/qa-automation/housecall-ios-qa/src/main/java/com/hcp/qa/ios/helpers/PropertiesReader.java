package com.hcp.qa.ios.helpers;

import com.hcp.qa.common.ConfigHandler;

public class PropertiesReader {
	private static PropertiesReader instance = null;
	private String proUser = ConfigHandler.getStringPropertyValueFromKey("hcp.ios.pro.user");

	private String proPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.ios.pro.password");

	private String email = ConfigHandler.getStringPropertyValueFromKey("hcp.ios.email");

	private String gmailPassword = ConfigHandler.getStringPropertyValueFromKey("hcp.ios.gmail.password");

	private String phone = ConfigHandler.getStringPropertyValueFromKey("hcp.ios.phone");
	

	private String ccNumber = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.number");

	private String cvc = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.cvc");

	private String expiryDate = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.expirationDate");

	private String postalCode = ConfigHandler.getStringPropertyValueFromKey("hcp.web.cc.postalCode");

	private PropertiesReader() {
	}

	public static PropertiesReader getInstance() {
		if (instance == null)
			instance = new PropertiesReader();
		return instance;
	}

	public String getProUser() {
		return proUser;
	}

	public String getProPassword() {
		return proPassword;
	}

	public String getEmail() {
		return email;
	}

	public String getGmailPassword() {
		return gmailPassword;
	}

	public String getPhone() {
		return phone;
	}

	public String getCcNumber() {
		return ccNumber;
	}

	public String getCvc() {
		return cvc;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public String getPostalCode() {
		return postalCode;
	}
}
