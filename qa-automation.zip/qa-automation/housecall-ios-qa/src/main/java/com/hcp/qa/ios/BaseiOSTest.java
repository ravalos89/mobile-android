package com.hcp.qa.ios;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.hcp.qa.ios.helpers.CustomerHelper;
import com.hcp.qa.ios.helpers.LoginHelper;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

import static java.time.Duration.ofSeconds;

public class BaseiOSTest {
	protected static IOSDriver driver;
	private static AppiumDriverLocalService service;

	private static String iOSApp = System.getenv("BITRISE_APP_DIR_PATH");
	//private static String platformVersion = System.getProperty("platformVersion", "14.4");
	private static String deviceName = System.getProperty("deviceName", "iPhone 12");

	private static final Logger LOG = LoggerFactory.getLogger(BaseiOSTest.class);

	protected static LoginHelper loginHelper;
	protected static CustomerHelper customerHelper;
	@BeforeSuite
	public void setUpSuite() throws MalformedURLException {
		LOG.info("****BITRISE_APP_DIR_PATH***** : " + iOSApp);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "iOS");
		//capabilities.setCapability("platformVersion", platformVersion);
		capabilities.setCapability("deviceName", deviceName);
		capabilities.setCapability("app", iOSApp);
		capabilities.setCapability("appActivity", "housecall.pros.launcher.LauncherActivity");
		capabilities.setCapability("appWaitActivity", "housecall.pros.onboarding.SignupLoginOnboardingActivity");
		capabilities.setCapability("wdaStartupRetries", "4");
		capabilities.setCapability("iosInstallPause", "1000");
		capabilities.setCapability("wdaStartupRetryInterval", "20000");
		
		capabilities.setCapability("xcodeOrgId", "4R8R3SQJC8");
		capabilities.setCapability("xcodeSigningId", "iPhone Developer");
		capabilities.setCapability("appium:simulatorStartupTimeout", "800000");
		
		capabilities.setCapability("automationName", "XCUITest");

		driver = new IOSDriver(new URL("http://127.0.0.1:4723"), capabilities);
		driver.manage().timeouts().implicitlyWait(ofSeconds(15));
		loginHelper = new LoginHelper(driver);
		customerHelper=new CustomerHelper(driver);
		loginHelper.login();
	}

	public URL getServiceUrl() {
		return service.getUrl();
	}

	@AfterSuite
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
		if (service != null) {
			service.stop();
		}
	}

	public void takeScreenShot(String name) {
		File screenshotLocation;
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String path = "screenshots/" + name + "_" + UUID.randomUUID() + ".png";

		screenshotLocation = new File(System.getProperty("user.dir") + File.separator + path);
		try {
			FileUtils.copyFile(scrFile, screenshotLocation);
		} catch (IOException e) {
			LOG.error("Failed to create screen shot file :" + e.getMessage());
		}

		LOG.info(screenshotLocation.toString());

	}
	
	public void restartApp() {
		driver.launchApp();
		loginHelper.login();
		//FIXME: This is a workaround in place so launch darkly flag is read after restart
		loginHelper.logout();
		loginHelper.login();
	}
	


}
