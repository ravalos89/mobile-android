package com.hcp.qa.ios.helpers;

import com.hcp.qa.ios.pages.common.BottomNavigationMenu;
import com.hcp.qa.ios.pages.common.MoreMenu;
import com.hcp.qa.ios.pages.signin.LogInPage;
import com.hcp.qa.ios.pages.signin.OnboardSignInPage;

import io.appium.java_client.ios.IOSDriver;

public class LoginHelper {
	
	IOSDriver driver;
	
	public LoginHelper(IOSDriver driver) {
		this.driver = driver;
	}
	public void login() {
		OnboardSignInPage onboardPage = new OnboardSignInPage(driver);
		onboardPage.clickLogin();
		LogInPage logInPage = new LogInPage(driver);
		String proUser=PropertiesReader.getInstance().getProUser();
		String proPassword=PropertiesReader.getInstance().getProPassword();
		logInPage.logIn(proUser, proPassword);
	}

	public void logout() {
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.clickMore();
		MoreMenu menu = new MoreMenu(driver);
		menu.waitForPageToLoad(3);
		menu.scrollDown();
		menu.clickLogout();
		menu.waitForPageToLoad(1);
		menu.confirmLogout();
	}
}
