package com.hcp.qa.ios.helpers;

import com.hcp.qa.ios.pages.common.AddMenu;
import com.hcp.qa.ios.pages.common.DashboardPage;
import com.hcp.qa.ios.pages.estimate.EstimateCustomerSearchPage;
import com.hcp.qa.ios.pages.estimate.NewEstimatePage;

import io.appium.java_client.ios.IOSDriver;

public class EstimateHelper extends BaseJobEstimateHelper{
	String customerName = "Test Customer";
	String lineItemName = "Test Line Item";
	// FIXME: Customer search page id different from customer search Note Job
	public EstimateHelper(IOSDriver driver) {
		this.driver = driver;
	}

	public void createEstimate() {
		gotoNewEstimatePage();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickCustomers();
		searchAndSelectCustomerFromEstimatePage(customerName);
		newEstimate.waitForPageToLoad(1);
		saveEstimateAndHandlePrompts();
	}

	public void createEstimateWithLineItem() {
		gotoNewEstimatePage();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickCustomers();
		searchAndSelectCustomerFromEstimatePage(customerName);
		newEstimate.waitForPageToLoad(5);
		newEstimate.clickLineItem();
		addLineItem(lineItemName);
		saveEstimateAndHandlePrompts();
	}
	
	public void saveEstimateAndHandlePrompts()
	{
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickDone();
		handleNotificationsPrompt();
		handleLocationAccessPrompt();	
	}

	public void gotoNewEstimatePage() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.waitForPageToLoad(2);
		dashboard.clickAdd();
		dashboard.waitForPageToLoad(1);
		AddMenu addMenu = new AddMenu(driver);
		addMenu.clickAddNewEstimate();

	}

	public void searchAndSelectCustomerFromEstimatePage(String customerName) {
		EstimateCustomerSearchPage customerSearch = new EstimateCustomerSearchPage(driver);
		customerSearch.searchforCustomer(customerName);
		customerSearch.clickCustomer(customerName);
	}
}
