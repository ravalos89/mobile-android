package com.hcp.qa.ios.helpers;

import com.hcp.qa.ios.pages.common.AddMenu;
import com.hcp.qa.ios.pages.common.DashboardPage;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.job.JobCustomerSearchPage;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.payment.CreditCardPage;

import io.appium.java_client.ios.IOSDriver;

public class JobHelper extends BaseJobEstimateHelper {
	CustomerHelper customerHelper;

	public JobHelper(IOSDriver driver) {
		this.driver = driver;
		this.customerHelper = new CustomerHelper(driver);
	}

	public String createJobFromCustomerDetails(String customerName) {
		customerHelper.searchAndSelectCustomer(customerName);
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		customerDetails.clickAddJob();
		customerDetails.waitForPageToLoad(1);
		return createJob();

	}

	public String createJob() {
		NewJobPage newJob = new NewJobPage(driver);
		newJob.waitForPageToLoad(2);
		newJob.clickLineItem();
		addLineItem("Test Line Item");
		saveJobAndHandlePrompts();
		JobPage job = new JobPage(driver);
		return job.getId();
	}

	public NewJobPage gotoNewJob() {
		DashboardPage dashboard = new DashboardPage(driver);
		dashboard.waitForPageToLoad(1);
		dashboard.clickAdd();
		dashboard.waitForPageToLoad(1);

		NewJobPage newJob = new NewJobPage(driver);
		newJob.waitForPageToLoad(2);
		AddMenu addMenu = new AddMenu(driver);
		addMenu.clickAddNewJob();
		dashboard.waitForPageToLoad(1);
		return newJob;
	}

	public NewJobPage searchAndSelectCustomerFromJobPage(String customerName) {
		NewJobPage newJob = gotoNewJob();
		newJob.clickCustomers();

		JobCustomerSearchPage customerSearch = new JobCustomerSearchPage(driver);
		customerSearch.searchforCustomer(customerName);
		customerSearch.waitForPageToLoad(2);
		customerSearch.clickCustomer(customerName);
		customerSearch.waitForPageToLoad(2);
		return newJob;
	}

	public void saveJobAndHandlePrompts() {
		NewJobPage newJob = new NewJobPage(driver);
		newJob.clickSave();
		handleNotificationsPrompt();
		handleLocationAccessPrompt();
	}

	public void enterCCDetails() {
		CreditCardPage ccPage = new CreditCardPage(driver);
		PropertiesReader properties = PropertiesReader.getInstance();
		ccPage.enterCCNumber(properties.getCcNumber());
		ccPage.enterExpiryDate(properties.getExpiryDate());
		ccPage.enterCvc(properties.getCvc());
		ccPage.enterPostalCode(properties.getPostalCode());
	}
}
