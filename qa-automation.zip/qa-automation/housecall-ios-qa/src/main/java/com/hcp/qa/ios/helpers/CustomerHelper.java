package com.hcp.qa.ios.helpers;

import org.openqa.selenium.By;

import com.hcp.qa.ios.pages.common.BottomNavigationMenu;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.customer.CustomerListPage;
import com.hcp.qa.ios.pages.customer.EditCustomerPage;
import com.hcp.qa.models.Customer;

import io.appium.java_client.ios.IOSDriver;

public class CustomerHelper {
	private final IOSDriver driver;
	public CustomerHelper(IOSDriver driver) {
		this.driver = driver;
	}
	public Customer createCustomer() {
		Customer customer = DataGenerator.getInstance().generateCustomerData("iOS");
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.clickCustomers();
		CustomerListPage customerList = new CustomerListPage(driver);
		customerList.clickAdd();
		customerList.clickNewCustomer();
		customerList.waitForPageToLoad(3);

		EditCustomerPage editCustomer = new EditCustomerPage(driver);
		editCustomer.enterFirstName(customer.getFirstName());
		editCustomer.enterLastName(customer.getLastName());
		editCustomer.enterEmail(customer.getEmail());

		editCustomer.enterMobile(customer.getMobileNumber());
		editCustomer.clickSave();
		return customer;
	}

	public void searchAndSelectCustomer(String customerName) {
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.waitForPageToLoad(4);
		bottomMenu.clickCustomers();
		CustomerListPage customerList = new CustomerListPage(driver);
		customerList.searchforCustomer(customerName);
		customerList.clickCustomer(customerName);
	}
	
	// FIXME:The searching for elements should go in a page class
	public void goToDashboardFromCustomer(String customerName) {
		driver.findElement(By.xpath("//XCUIElementTypeButton[@name='" + customerName + "']")).click();
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		customerDetails.gotoCustomerSearch();
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.waitForPageToLoad(1);
		bottomMenu.clickDashboard();
		bottomMenu.waitForPageToLoad(1);
	}
}
