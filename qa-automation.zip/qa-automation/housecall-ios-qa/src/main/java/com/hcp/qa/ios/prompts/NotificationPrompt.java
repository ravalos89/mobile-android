package com.hcp.qa.ios.prompts;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.hcp.qa.ios.pages.common.Page;

import io.appium.java_client.ios.IOSDriver;

public class NotificationPrompt extends Page{
	public NotificationPrompt(IOSDriver driver) {
		super(driver);
	}
	@FindBy(xpath = "//XCUIElementTypeButton[@name='Enable Notifications']")
	private WebElement enableNotificationsBtn;

	@FindBy(xpath = "//XCUIElementTypeButton[@name='Allow']")
	private WebElement allowBtn;
	public void enableNotifications() {
		waitForPageToLoad(2);
		enableNotificationsBtn.click();
		allowBtn.click();

	}

}
