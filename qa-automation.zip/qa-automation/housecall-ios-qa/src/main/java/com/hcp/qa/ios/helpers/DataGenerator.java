package com.hcp.qa.ios.helpers;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import com.hcp.qa.models.Address;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.LineItem;

public class DataGenerator {
	
	private static DataGenerator instance;

	PropertiesReader properties = PropertiesReader.getInstance();
	
	private DataGenerator()
	{}
	public static DataGenerator getInstance()
	{
		if (instance == null)
			instance = new DataGenerator();
		return instance;
	}

	public String getUniqueEmail(String suffix) {
		String email = properties.getEmail();
		String random = RandomStringUtils.randomAlphanumeric(5);

		return email.replace("@", "+" + suffix + "_" + random + "@");
	}

	public String getUniqueName(String name) {
		return name + " " + RandomStringUtils.randomAlphabetic(5);
	}

	public LineItem generateLineItem() {
		LineItem lineItem = new LineItem();
		lineItem.setName("Test Line Item");
		lineItem.setDescription("Test line item description");
		lineItem.setQuantity(1);
		lineItem.setUnitPrice(10);

		return lineItem;
	}

	public  Customer generateCustomerData(String prefix) {
		String uniqueCustomerEmail = getUniqueEmail("iOSCustomer");
		String lastName = "last" + RandomStringUtils.randomAlphabetic(5);
		Customer customer = new Customer();
		customer.setFirstName(prefix);
		customer.setLastName(lastName);
		customer.setEmail(uniqueCustomerEmail);
		customer.setMobileNumber(properties.getPhone());
		List<Address> addressList = new ArrayList<>();
		Address address = new Address();
		address.setStreet("123 Auto Street");
		address.setCity("San Diego");
		address.setState("CA");
		address.setZip("92130");

		addressList.add(address);
		customer.setAddresses(addressList);
		customer.setNotificationsEnabled(	true);
		return customer;
	}

}
