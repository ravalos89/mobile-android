package com.hcp.qa.ios.helpers;

import org.openqa.selenium.NoSuchElementException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcp.qa.ios.pages.common.LineItemPage;
import com.hcp.qa.ios.pages.job.AddItemsPage;
import com.hcp.qa.ios.pages.pricebook.PriceBookPage;
import com.hcp.qa.ios.prompts.LocationPrompt;
import com.hcp.qa.ios.prompts.NotificationPrompt;

import io.appium.java_client.ios.IOSDriver;

import static java.time.Duration.ofSeconds;

public abstract class BaseJobEstimateHelper {

	IOSDriver driver;
	protected static Logger LOG = LoggerFactory.getLogger(BaseJobEstimateHelper.class);

	public void handleLocationAccessPrompt() {
		LocationPrompt location = new LocationPrompt(driver);
		driver.manage().timeouts().implicitlyWait(ofSeconds(10));
		try {
			location.clickAllowLocationAccess();
		} catch (NoSuchElementException e) {
			LOG.info("No prompt for Location permission.Do Nothing");
		}
		driver.manage().timeouts().implicitlyWait(ofSeconds(15));
	}

	public void handleNotificationsPrompt() {
		NotificationPrompt notifications = new NotificationPrompt(driver);
		driver.manage().timeouts().implicitlyWait(ofSeconds(10));
		try {
			notifications.enableNotifications();
		} catch (NoSuchElementException e) {
			LOG.info("No prompt for enable Notifications.Do Nothing");
		}
		driver.manage().timeouts().implicitlyWait(ofSeconds(15));
	}

	public void addLineItem(String itemName) {
		AddItemsPage addItem = new AddItemsPage(driver);
		addItem.clickAddServices();
		PriceBookPage pricebook = new PriceBookPage(driver);
		pricebook.clickAdd();
		LineItemPage lineItem = new LineItemPage(driver);
		lineItem.enterName(itemName);
		lineItem.enterDescription("Test Description");
		lineItem.enterPrice("1000");
		lineItem.clickAdd();
		addItem.clickDone();
	}
}
