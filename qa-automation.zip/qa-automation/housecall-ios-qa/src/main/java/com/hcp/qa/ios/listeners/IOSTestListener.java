package com.hcp.qa.ios.listeners;

import org.testng.ITestResult;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.testng.CustomTestListener;

public class IOSTestListener extends CustomTestListener {

	public void onTestFailure(ITestResult result) {
		
		((BaseiOSTest) result.getInstance()).takeScreenShot(result.getName() + "_FAILED");
		((BaseiOSTest) result.getInstance()).restartApp();
	}
}
