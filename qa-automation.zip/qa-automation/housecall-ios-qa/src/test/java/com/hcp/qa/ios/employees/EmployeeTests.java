package com.hcp.qa.ios.employees;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.DataGenerator;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.helpers.PropertiesReader;
import com.hcp.qa.ios.pages.common.BottomNavigationMenu;
import com.hcp.qa.ios.pages.common.MoreMenu;
import com.hcp.qa.ios.pages.company.CompanySetupPage;
import com.hcp.qa.ios.pages.employee.AddEmployeePage;
import com.hcp.qa.ios.pages.employee.EmployeesListPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.schedule.DispatchEmployeePage;
import com.hcp.qa.ios.pages.schedule.SchedulePage;

public class EmployeeTests extends BaseiOSTest {

	String employeeName = "Test Employee";

	@Test
	public void createEmployee() {
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.clickMore();
		MoreMenu moreMenu = new MoreMenu(driver);
		moreMenu.clickCompanySetup();
		CompanySetupPage companySetup = new CompanySetupPage(driver);
		companySetup.clickEmployees();
		EmployeesListPage employeeList = new EmployeesListPage(driver);
		employeeList.waitForPageToLoad(1);
		employeeList.clickAddManually();
		employeeList.waitForPageToLoad(1);
		AddEmployeePage addEmployee = new AddEmployeePage(driver);
		addEmployee.enterFirstName("Test");
		addEmployee.enterLastName("Employee");
		addEmployee.enterEmail(DataGenerator.getInstance().getUniqueEmail("employee"));
		addEmployee.enterPhone(PropertiesReader.getInstance().getPhone());
		addEmployee.clickSave();
		employeeList = new EmployeesListPage(driver);
		employeeList.waitForPageToLoad(10);
		Assert.assertTrue(employeeList.isEmployeeFound(employeeName), "Employee not found in the list");
		employeeList.waitForPageToLoad(1);
		bottomMenu.clickDashboard();
		bottomMenu.waitForPageToLoad(1);
	}

	@Test(dependsOnMethods = "createEmployee")
	public void assignJobToEmployee() {
		JobHelper jobHelper=new JobHelper(driver);
		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickSchedule();
		newJob.waitForPageToLoad(2);

		SchedulePage schedule = new SchedulePage(driver);
		schedule.selectEmployees();

		DispatchEmployeePage dispatch = new DispatchEmployeePage(driver);
		dispatch.searchEmployee(employeeName);
		dispatch.clickSearch();
		newJob.waitForPageToLoad(2);
		dispatch.clickEmployee(employeeName);
		newJob.waitForPageToLoad(2);
		dispatch.clickDone();
		newJob.waitForPageToLoad(2);

		Assert.assertTrue(schedule.checkEmployeeCount("2"), "The employee count is incorrect");
		schedule.clickDone();

		newJob.clickClose();
		newJob.waitForPageToLoad(1);

	}

}
