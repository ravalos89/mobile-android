package com.hcp.qa.ios.customers;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.pages.common.BottomNavigationMenu;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.customer.CustomerListPage;
import com.hcp.qa.models.Customer;

public class CustomerCreationTests extends BaseiOSTest {

	@Test()
	public void createCustomer() {

		Customer customer = customerHelper.createCustomer();
        BottomNavigationMenu menu=new BottomNavigationMenu(driver);
        menu.waitForPageToLoad(2);
        menu.clickCustomers();
        menu.waitForPageToLoad(1);
		CustomerListPage customerList = new CustomerListPage(driver);
		boolean isCustomerFound = customerList.searchforCustomer(customer.getDisplayName());
		Assert.assertTrue(isCustomerFound, "Customer not found");
		customerList.clickCustomer(customer.getDisplayName());
		CustomerDetailsPage customerDetails=new CustomerDetailsPage(driver);
		customerDetails.gotoCustomerSearch();
		
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.waitForPageToLoad(1);
		bottomMenu.clickCustomers();
		bottomMenu.clickDashboard();
		bottomMenu.waitForPageToLoad(1);
		
	}
}
