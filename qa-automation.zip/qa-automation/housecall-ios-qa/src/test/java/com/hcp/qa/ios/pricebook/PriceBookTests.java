package com.hcp.qa.ios.pricebook;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.common.LineItemPage;
import com.hcp.qa.ios.pages.job.AddItemsPage;
import com.hcp.qa.ios.pages.job.JobCustomerSearchPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.pricebook.VisualPricebookPage;

public class PriceBookTests extends BaseiOSTest {
	String customerName = "Test Customer";
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}
	@Test
	public void addLineItemFromPricebook() {
		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickCustomers();

		JobCustomerSearchPage customerSearch = new JobCustomerSearchPage(driver);
		customerSearch.searchforCustomer(customerName);
		customerSearch.waitForPageToLoad(1);
		customerSearch.clickCustomer(customerName);

		newJob.waitForPageToLoad(2);
		newJob.clickLineItem();

		AddItemsPage addItem = new AddItemsPage(driver);
		addItem.clickServicePriceBook();

		String category = "Test";
		String service = "AC Cleaning";
		VisualPricebookPage pricebook = new VisualPricebookPage(driver);
		pricebook.clickCategory(category);

		pricebook.clickService(service);

		pricebook.clickAddToJob();

		pricebook.clickConfirm();

		LineItemPage lineItem = new LineItemPage(driver);
		lineItem.waitForPageToLoad(2);
		Assert.assertTrue(lineItem.isLineItemPresent(service));
		lineItem.clickDone();
		newJob.clickClose();

	}

}
