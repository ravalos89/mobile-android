package com.hcp.qa.ios.estimate;

import java.util.Calendar;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.estimate.EstimateTag;

public class EstimateTagTests extends BaseiOSTest {
	
	static String tagName;
	private EstimateHelper estimateHelper;

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}
	@Test
	public void addTag() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		tagName = createTag();
		Assert.assertTrue(estimate.isTagDisplayed(tagName), "New Tag is not added");
	}

	@Test(dependsOnMethods="addTag")
	public void deleteTag() {
		EstimatePage estimate = new EstimatePage(driver);
		EstimateTag estimateTag=new EstimateTag(driver);
		estimateTag.clickEditTag();
		
		estimateTag.clickClose(tagName);
		estimateTag.clickSaveBtn();
		Assert.assertFalse(estimate.isTagDisplayed(tagName), "Added Tag is not Deleted");
	}
	
	private String createTag() {
		EstimatePage estimate = new EstimatePage(driver);
		estimate.scrollDown();
		estimate.clickJobTags();
		
		EstimateTag estimateTag=new EstimateTag(driver);
		estimateTag.clickAddTag();
		String tagName="Tag_"+Calendar.getInstance().getTimeInMillis();
		
		estimateTag.enterTagInSearch(tagName);
		estimateTag.clickOnBack();
		estimateTag.clickSaveBtn();
		return tagName;
	}
	
	@AfterClass
	public void endTest() {
		EstimatePage estimate = new EstimatePage(driver);
		estimate.goBackToDashboard();
	}	
}
