package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.common.LineItemPage;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.NotePage;

public class EstimateManagementTests extends BaseiOSTest {

	private EstimateHelper estimateHelper;
	String lineItemName = "Test Line Item";

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}

	@Test
	public void addLineItem() {
		estimateHelper.createEstimateWithLineItem();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.scrollDown();
		estimate.waitForPageToLoad(2);
		LineItemPage lineItem = new LineItemPage(driver);
		Assert.assertTrue(lineItem.isLineItemPresent(lineItemName), "Line Item is not added");
		estimate.goBackToDashboard();
	}

	@Test
	public void deleteLineItem() {
		estimateHelper.createEstimateWithLineItem();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.waitForPageToLoad(1);
		estimate.clickEditLineItem();
		LineItemPage lineItem = new LineItemPage(driver);
		lineItem.clickOnLineItem(lineItemName);
		lineItem.clickDeleteLineItem();
		lineItem.confirmDeleteLineItem();
		lineItem.clickDone();
		lineItem.waitForPageToLoad(2);

		Assert.assertFalse(lineItem.isLineItemPresent(lineItemName), "Line Item is not deleted");
		estimate.goBackToDashboard();
	}

	@Test
	public void updatePrivateNotes() {
		estimateHelper.createEstimate();
		String note = "New Note";
		String updatedNote = "New Note Updated";

		EstimatePage estimate = new EstimatePage(driver);

		estimate.scrollDown();
		estimate.clickPrivateNotes();

		NotePage noteWidget = new NotePage(driver);
		noteWidget.editNote(note);
		noteWidget.clickSave();

		estimate.scrollDown();
		noteWidget.clickNote(note);

		noteWidget.editNote(updatedNote);
		noteWidget.clickSave();
		Assert.assertTrue(estimate.isPrivateNotePresent(updatedNote), "Private Note is not updated");
		estimate.goBackToDashboard();
	}

	@Test
	public void copyToJobEstimate() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickCopyToJob();
		estimate.clickCopyToNewJob();

		JobPage jobPage = new JobPage(driver);
		jobPage.waitForPageToLoad(1);
		Assert.assertTrue(jobPage.isPayButtonPresent(), "Pay button not found for job");

		jobPage.goBackToEstimateDetails();
		estimate.goBackToDashboard();
	}
}
