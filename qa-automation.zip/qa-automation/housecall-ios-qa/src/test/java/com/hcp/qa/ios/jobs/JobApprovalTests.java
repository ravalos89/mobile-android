package com.hcp.qa.ios.jobs;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.job.ApproveDialog;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.SignaturePage;
import com.hcp.qa.ios.pages.job.NewJobPage;

public class JobApprovalTests extends BaseiOSTest{

	JobHelper jobHelper;
	
	@BeforeClass
	public void setUp()
	{
		jobHelper=new JobHelper(driver);
	}
	
	@Test
	public void jobApproveBeforeWorkStarts()
	{
	String customerName = "Test Customer";
	jobHelper.searchAndSelectCustomerFromJobPage(customerName);
	NewJobPage newJob = new NewJobPage(driver);
	newJob.waitForPageToLoad(2);
	newJob.clickSave();
	jobHelper.handleNotificationsPrompt();
	jobHelper.handleLocationAccessPrompt();
	
	JobPage job = new JobPage(driver);
	job.clickApprove();
	
	ApproveDialog approveDialog = new ApproveDialog(driver);
	approveDialog.clickBeforeWorkStarts();
	SignaturePage jobSignature = new SignaturePage(driver);
	jobSignature.addSignature();
	jobSignature.clickDoneSigning();
	
	job.waitForPageToLoad(2);
	job.clickApprove();
	job.waitForPageToLoad(2);
	approveDialog = new ApproveDialog(driver);
	Assert.assertFalse(approveDialog.isBeforeWorkStartsEnabled(),"The BeforeWorkStarts Button should be disabled");
	

	}
	
	@Test(dependsOnMethods="jobApproveBeforeWorkStarts")
	public void jobApproveAfterWorkComplete()
	{
		ApproveDialog approveDialog=new ApproveDialog(driver);
		approveDialog.clickAfterWorkComplete();
		SignaturePage jobSignature=new SignaturePage(driver);
		jobSignature.addSignature();
		jobSignature.clickDoneSigning();
		
		JobPage job =new JobPage(driver);
		job.waitForPageToLoad(2);
		job.clickApprove();
		approveDialog=new ApproveDialog(driver);
		Assert.assertFalse(approveDialog.isBeforeWorkStartsEnabled(),"The BeforeWorkStarts Button should be disabled");
		approveDialog.clickCancel();
		job.goBackToDashboard();

	}
	
}
