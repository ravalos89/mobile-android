package com.hcp.qa.ios.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.payment.InvoicePage;

public class InvoiceEstimateTests extends BaseiOSTest {
	String customerName = "Test Customer";
	private static Logger LOG = LoggerFactory.getLogger(InvoiceEstimateTests.class);
	private EstimateHelper estimateHelper;

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}
	@Test
	public void checkInvoicePreview() {
		estimateHelper.createEstimate();
		EstimatePage estimateJob = new EstimatePage(driver);
		estimateJob.clickEstimateBtn();
		
		LOG.info("After Click invoice Context " + driver.getContext() + "\nContext Handles "
				+ driver.getContextHandles() + "\n\n");

		InvoicePage invoice = new InvoicePage(driver);
		invoice.waitForPageToLoad(5);
		
		// FIXME: Assert Invoice number. This is not working on Bitrise. Look at contexts on Bitrise
		
		invoice.clickNext();
		invoice.clickSendBtnFromEstimateFlow();

		Assert.assertTrue(invoice.isSentMessageDisplayed(), "Invoice sent message is not displayed.");

		invoice.clickClose();
		invoice.waitForPageToLoad(1);
		JobPage job = new JobPage(driver);

		job.goBackToDashboard();
	}
}
