package com.hcp.qa.ios.jobs;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.job.JobCustomerSearchPage;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.NewJobPage;

public class JobCreationTests extends BaseiOSTest {

	String customerName = "Test Customer";
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}

	@Test
	public void createJobFromNew() {

		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickCustomers();

		JobCustomerSearchPage customerSearch = new JobCustomerSearchPage(driver);
		customerSearch.searchforCustomer(customerName);
		customerSearch.waitForPageToLoad(1);
		customerSearch.clickCustomer(customerName);

		jobHelper.createJob();

		JobPage job = new JobPage(driver);
		Assert.assertTrue(job.isPayButtonPresent(), "Pay button is not present");
		job.goBackToDashboard();
	}

	@Test
	public void createJobFromCustomerDetails() {
		customerHelper.searchAndSelectCustomer(customerName);
		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		customerDetails.clickAddJob();
		customerDetails.waitForPageToLoad(1);

		jobHelper.createJob();
		JobPage job = new JobPage(driver);
		Assert.assertTrue(job.isPayButtonPresent(), "Pay button is not present");

		customerHelper.goToDashboardFromCustomer(customerName);
	}

}
