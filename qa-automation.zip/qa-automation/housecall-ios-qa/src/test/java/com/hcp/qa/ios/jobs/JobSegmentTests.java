package com.hcp.qa.ios.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.job.JobMoreMenu;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.job.segments.AddSegmentDialog;
import com.hcp.qa.ios.pages.job.segments.CopySegmentDialog;
import com.hcp.qa.ios.pages.job.segments.DeleteCancelDialog;
import com.hcp.qa.ios.pages.job.segments.RenameSegmentDialog;

public class JobSegmentTests extends BaseiOSTest {

	protected static Logger LOG = LoggerFactory.getLogger(JobSegmentTests.class);
	String customerName = "Test Customer";
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}
	@BeforeMethod
	private void createNewJobFromCustomer() {
		jobHelper.searchAndSelectCustomerFromJobPage(customerName);
		NewJobPage newJob = new NewJobPage(driver);
		newJob.waitForPageToLoad(2);
		newJob.clickSave();
		jobHelper.handleNotificationsPrompt();
		jobHelper.handleLocationAccessPrompt();
	}

	@Test
	public void addSegment() {

		String newSegmentName = "SEGMENT #2";

		createNewSegment();
		JobPage job = new JobPage(driver);
		Assert.assertTrue(job.isSegmentDisplayed(newSegmentName), "New Segment is not added");
		job.goBackToDashboard();
	}

	@Test
	public void copySegment() {
		String copiedSegmentName = "COPY OF SEGMENT #1";
		JobPage job = new JobPage(driver);
		job.clickMore();

		JobMoreMenu moreMenu = new JobMoreMenu(driver);
		moreMenu.clickCopySegment();

		CopySegmentDialog copyDialog = new CopySegmentDialog(driver);
		copyDialog.clickCopy();

		job.clickSegment(copiedSegmentName);
		Assert.assertTrue(job.isSegmentDisplayed(copiedSegmentName), "New Segment is not added");
		job.goBackToDashboard();
	}

	@Test
	public void cancelSegment() {
		String segmentToCancel = "SEGMENT #1";

		createNewSegment();

		JobPage job = new JobPage(driver);
		job.clickSegment(segmentToCancel);
		job.clickMore();

		JobMoreMenu moreMenu = new JobMoreMenu(driver);
		moreMenu.clickCancelSegment();

		DeleteCancelDialog cancelDialog = new DeleteCancelDialog(driver);
		cancelDialog.clickConfirm();
		cancelDialog.waitForPageToLoad(3);

		Assert.assertFalse(job.isSegmentDisplayed(segmentToCancel), "Canceled Segment is displaying");
		job.goBackToDashboard();
	}

	@Test
	public void renameSegment() {
		String segmentToRename = "SEGMENT #2";
		String renamedsegment = "SEGMENT #2 RENAMED";

		createNewSegment();

		JobPage job = new JobPage(driver);
		job.clickSegment(segmentToRename);
		job.clickMore();

		JobMoreMenu moreMenu = new JobMoreMenu(driver);
		moreMenu.clickRenameSegment();

		RenameSegmentDialog renameDialog = new RenameSegmentDialog(driver);
		renameDialog.enterSegmentName(renamedsegment);
		renameDialog.clickConfirm();

		Assert.assertTrue(job.isSegmentDisplayed(renamedsegment), "New Segment is not renamed");
		job.goBackToDashboard();
	}

	@Test
	public void deleteSegment() {
		String segmentToDelete = "SEGMENT #1";

		createNewSegment();

		JobPage job = new JobPage(driver);
		job.clickSegment(segmentToDelete);
		job.clickMore();

		JobMoreMenu moreMenu = new JobMoreMenu(driver);

		moreMenu.clickDeleteSegment();
		DeleteCancelDialog deleteDialog = new DeleteCancelDialog(driver);
		deleteDialog.clickConfirm();

		Assert.assertFalse(job.isSegmentDisplayed(segmentToDelete), "Deleted Segment is displaying");
		job.goBackToDashboard();
	}

	private void createNewSegment() {
		JobPage job = new JobPage(driver);
		job.clickMore();
		JobMoreMenu moreMenu = new JobMoreMenu(driver);
		moreMenu.clickAddSegment();

		AddSegmentDialog addDialog = new AddSegmentDialog(driver);
		addDialog.clickAdd();

	}

}