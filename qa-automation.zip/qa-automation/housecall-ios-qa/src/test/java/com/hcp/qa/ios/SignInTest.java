package com.hcp.qa.ios;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.pages.common.DashboardPage;

public class SignInTest extends BaseiOSTest {

	protected static Logger LOG = LoggerFactory.getLogger(SignInTest.class);

	@Test()
	public void signIn() {
		DashboardPage dashboard = new DashboardPage(driver);
		Assert.assertTrue(dashboard.isDisplayed(), "The add button is not displayed");

	}

	@Test(dependsOnMethods="signIn")
	public void logout() {
		loginHelper.logout();
		loginHelper.login();
	}
}
