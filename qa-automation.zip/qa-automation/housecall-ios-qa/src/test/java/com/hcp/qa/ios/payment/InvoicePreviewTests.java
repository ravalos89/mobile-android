package com.hcp.qa.ios.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.payment.InvoicePage;
import com.hcp.qa.ios.pages.payment.InvoiceSettingsPage;

public class InvoicePreviewTests extends BaseiOSTest {
	String customerName = "Test Customer";
	private static Logger LOG = LoggerFactory.getLogger(InvoicePreviewTests.class);
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}
	@Test
	public void checkInvoicePreview() {
		String jobId = jobHelper.createJobFromCustomerDetails(customerName);
		LOG.info("Created Job " + jobId);
		LOG.info("Context " + driver.getContext() + "\nContext Handles " + driver.getContextHandles() + "\n\n");
		JobPage job = new JobPage(driver);
		job.clickInvoice();
		job.waitForPageToLoad(5);
		LOG.info("After Click invoice Context " + driver.getContext() + "\nContext Handles "
				+ driver.getContextHandles() + "\n\n");

		InvoicePage invoice = new InvoicePage(driver);
		// FIXME: This is not working on Bitrise. Look at contexts on Bitrise
		//Assert.assertTrue(invoice.isInvoiceNumberDisplayed(jobId),
		//		"Invoice number not displayed. \n\n" + driver.getPageSource() + "\n\n");

		invoice.clickNext();
		invoice.clickPaymentSettings();

		InvoiceSettingsPage invoiceSettings = new InvoiceSettingsPage(driver);
		invoiceSettings.waitForPageToLoad(1);
		invoiceSettings.clickAcceptCC();
		invoiceSettings.waitForPageToLoad(2);
		invoiceSettings.clickDone();

		invoice.clickSend();

		Assert.assertTrue(invoice.isSentMessageDisplayed(), "Invoice sent message is not displayed.");

		invoice.clickClose();
		job.waitForPageToLoad(1);
		customerHelper.goToDashboardFromCustomer(customerName);

	}
}
