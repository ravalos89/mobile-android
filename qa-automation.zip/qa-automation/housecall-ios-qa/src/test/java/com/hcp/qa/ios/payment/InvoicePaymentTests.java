package com.hcp.qa.ios.payment;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.payment.CreditCardPage;
import com.hcp.qa.ios.pages.payment.PaymentPage;

public class InvoicePaymentTests extends BaseiOSTest {
	String customerName = "Test Customer";
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}
	@Test
	public void payInvoiceWithCC() {
		jobHelper.createJobFromCustomerDetails(customerName);
		JobPage job = new JobPage(driver);
		
		job.clickPay();
		job.waitForPageToLoad(5);
		
		PaymentPage payment=new PaymentPage(driver);
		payment.clicNext();
		payment.clickCreditCard();
		
		CreditCardPage ccPage=new CreditCardPage(driver);
		jobHelper.enterCCDetails();
		
		ccPage.clickNext();
		ccPage.addSignature();
		ccPage.clickPay();
		Assert.assertTrue(ccPage.isPaymentMessagePresent(),"Payment Message not found after successful Payment");
		ccPage.clickClose();
		ccPage.waitForPageToLoad(1);
		
		Assert.assertTrue(job.isPaidStatusDisplayed(),"'Paid in full' status not displayed on Job Page");
        customerHelper.goToDashboardFromCustomer(customerName);
		
	}
}
