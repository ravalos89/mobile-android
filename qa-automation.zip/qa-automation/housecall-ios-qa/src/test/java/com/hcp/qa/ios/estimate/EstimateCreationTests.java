package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.estimate.NewEstimatePage;

public class EstimateCreationTests extends BaseiOSTest {

	private EstimateHelper estimateHelper;

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}

	@Test
	public void createEstimateFromNew() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		Assert.assertTrue(estimate.isApproveButtonPresent(), "Approve button is not present");
		estimate.goBackToDashboard();
	}

	@Test
	public void createEstimateFromCustomerDetails() {
		String customerName = "Test Customer";
		customerHelper.searchAndSelectCustomer(customerName);

		CustomerDetailsPage customerDetails = new CustomerDetailsPage(driver);
		customerDetails.clickAddEstimate();
		customerDetails.waitForPageToLoad(1);

		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickLineItem();
		String lineItemName = "Test Line Item";
		estimateHelper.addLineItem(lineItemName);
		estimateHelper.saveEstimateAndHandlePrompts();
		EstimatePage estimate = new EstimatePage(driver);
		Assert.assertTrue(estimate.isApproveButtonPresent(), "Estimate button is not present");
		customerHelper.goToDashboardFromCustomer(customerName);
	}

}
