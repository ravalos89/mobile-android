package com.hcp.qa.ios.customers;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.pages.common.BottomNavigationMenu;
import com.hcp.qa.ios.pages.customer.CustomerDetailsPage;
import com.hcp.qa.ios.pages.customer.EditCustomerPage;
import com.hcp.qa.models.Customer;

public class CustomerManagementTests extends BaseiOSTest {

	@Test
	public void updateCustomer() {
		Customer customer = customerHelper.createCustomer();
		CustomerDetailsPage customerDetails=new CustomerDetailsPage(driver);
		customerDetails.waitForPageToLoad(1);
		customerDetails.clickEditICon();
		
		EditCustomerPage editCustomer = new EditCustomerPage(driver);
		editCustomer.waitForPageToLoad(1);
		String firstNameUpdated = customer.getFirstName()+" updated";
		String lastNameUpdated = customer.getLastName()+" updated";
		String customerNameUpdated=  firstNameUpdated + " " + lastNameUpdated;
		editCustomer.enterFirstName(firstNameUpdated);
		editCustomer.enterLastName(lastNameUpdated);
		
		String mobileNumber =customer.getMobileNumber();
		String newMobileNumber =mobileNumber.substring(0,mobileNumber.length()-1)+"0";
		editCustomer.enterMobile(newMobileNumber);
		editCustomer.clickSave();
		editCustomer.waitForPageToLoad(2);
		
		Assert.assertEquals(customerDetails.getCustomerName(), customerNameUpdated ,"Customer name not updated");
		Assert.assertEquals(customerDetails.getCustomerMobile().replace("(", "").replace(")", "").replace("-", "").replaceAll("\\s+", ""), 
				newMobileNumber ,"Mobile Number not updated");
		BottomNavigationMenu bottomMenu=new BottomNavigationMenu(driver);
		bottomMenu.waitForPageToLoad(1);
		bottomMenu.clickCustomers();
		bottomMenu.clickDashboard();
		bottomMenu.waitForPageToLoad(1);
	}
}
