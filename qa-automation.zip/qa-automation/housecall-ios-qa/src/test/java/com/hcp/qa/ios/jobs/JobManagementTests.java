package com.hcp.qa.ios.jobs;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.common.LineItemPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.job.NotePage;

public class JobManagementTests extends BaseiOSTest {
	String customerName = "Test Customer";
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}
	@Test()
	public void updateLineItem() {

		String itemName = "Test Line Item";
		String updatedItemName = "Test Line Item Updated";

		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickLineItem();
		jobHelper.addLineItem(itemName);
		newJob.clickLineItem();

		LineItemPage lineItem = new LineItemPage(driver);
		lineItem.clickOnLineItem(itemName);
		lineItem.updateItem(itemName, updatedItemName);
		lineItem.clickUpdate();
		Assert.assertTrue(lineItem.isLineItemPresent(updatedItemName), "Newly Updated Line Item not Present");
		lineItem.clickDone();
		newJob.clickClose();
	}

	@Test()
	public void deleteLineItem() {
		String itemName = "Test Line Item";

		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickLineItem();
		jobHelper.addLineItem(itemName);
		newJob.clickLineItem();

		LineItemPage lineItem = new LineItemPage(driver);
		lineItem.clickOnLineItem(itemName);
		lineItem.clickDeleteLineItem();
		lineItem.waitForPageToLoad(2);
		lineItem.confirmDeleteLineItem();
		lineItem.waitForPageToLoad(2);
		lineItem.clickDone();
		lineItem.waitForPageToLoad(2);
		Assert.assertFalse(lineItem.isLineItemPresent(itemName), "Deleted Line Item is Present");
		newJob.clickClose();
	}

	@Test()
	public void updatePrivateNotes() {
		String note = "New Note";
		String updatedNote = "New Note Updated";

		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickPrivateNotes();

		NotePage noteWidget = new NotePage(driver);
		noteWidget.editNote(note);
		noteWidget.clickSave();

		noteWidget.clickNote(note);
		noteWidget.editNote(updatedNote);
		noteWidget.clickSave();
		noteWidget.waitForPageToLoad(2);
		Assert.assertTrue(noteWidget.isUpdated(updatedNote), "Updated Note is not Present");
		newJob.clickClose();
	}

}
