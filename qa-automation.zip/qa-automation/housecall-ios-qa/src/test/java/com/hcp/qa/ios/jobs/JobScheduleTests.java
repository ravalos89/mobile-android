package com.hcp.qa.ios.jobs;

import org.openqa.selenium.NoSuchElementException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.common.EstimateFlowWidget;
import com.hcp.qa.ios.pages.common.JobFlowWidget;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.NewJobPage;
import com.hcp.qa.ios.pages.schedule.SchedulePage;

public class JobScheduleTests extends BaseiOSTest {
	String customerName = "Test Customer";
	protected static Logger LOG = LoggerFactory.getLogger(JobScheduleTests.class);
	
	@Test
	public void schedule() {
		scheduleJobAndVerify();
		
		JobHelper jobHelper= new JobHelper(driver);
		jobHelper.saveJobAndHandlePrompts();
		JobPage job = new JobPage(driver);
		//FIXME: When new time tracking is standard
		try {
			Assert.assertTrue(job.isOnMyWayPresent(), "On my way is not Present");
			Assert.assertTrue(job.isStartTimeTrackingPresent(), "Start time tracking is not Present");
		} catch (NoSuchElementException e) {
			LOG.info("Old Flow OMW->Start->Finish");
			EstimateFlowWidget oldJobFlow = new EstimateFlowWidget(driver);
			Assert.assertTrue(oldJobFlow.isOnMyWayButtonPresent(), "ON MY WAY is not Present");
			Assert.assertTrue(oldJobFlow.isStartButtonPresent(), "START is not Present");
			Assert.assertTrue(oldJobFlow.isFinishButtonPresent(), "FINISH is not Present");

		}
		job.goBackToDashboard();
	}

	@Test
	public void unSchedule() {
		scheduleJobAndVerify();
		
		NewJobPage newJob= new NewJobPage(driver);
		newJob.clickOnSchedule();
		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.clickOnUnschedule();
		scheduleWidget.clickDone();
		JobHelper jobHelper= new JobHelper(driver);
		jobHelper.saveJobAndHandlePrompts();

		JobPage job = new JobPage(driver);
		Assert.assertTrue(job.isUnScheduledPresent(), "UnSchedule is not Present");
		job.goBackToDashboard();
	}
	
	@Test	
	public void scheduleOMWWorkflow() {
		scheduleJobAndVerify();
		
		JobHelper jobHelper= new JobHelper(driver);
		jobHelper.saveJobAndHandlePrompts();

		JobFlowWidget jobFlow = new JobFlowWidget(driver);
		jobFlow.waitForPageToLoad(2);
		jobFlow.clickOmw();
		jobFlow.waitForPageToLoad(2);
		jobFlow.confirmOMW();
		jobFlow.waitForPageToLoad(2);
		
		jobFlow.clickOK();

		Assert.assertEquals("In-progress", jobFlow.getJobStatus(), "Job Status is not IN PROGRESS");
		
		jobFlow.clickStartMyTime();
		String note = "New Note";
		jobFlow.enterNote(note);
		jobFlow.clickStart();
		Assert.assertEquals("In-progress", jobFlow.getJobStatus(), "Job Status is not IN PROGRESS");
		Assert.assertTrue(jobFlow.isTimerPresent(), "Timer is not Present");

		jobFlow.clickPauseMyTimeBtn();
		jobFlow.selectFirstOptionToPause();
		jobFlow.clickPauseBtn();
		jobFlow.waitForPageToLoad(2);
		jobFlow.clickFinishJobBtn();
		jobFlow.waitForPageToLoad(2);
		Assert.assertTrue(jobFlow.isJobMarkedAsCompletePresent(), "Job marked as completed not present");

		jobFlow.clickClose();
		Assert.assertEquals("Finished", jobFlow.getJobStatus(), "Job Status is not Finished");
		JobPage job = new JobPage(driver);
		job.goBackToDashboard();

	}
	
	private void scheduleJobAndVerify() {
		JobHelper jobHelper= new JobHelper(driver);
		NewJobPage newJob = jobHelper.searchAndSelectCustomerFromJobPage(customerName);
		newJob.clickSchedule();

		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.selectStartAndEndDate();
		newJob.scrollDown();

		Assert.assertTrue(newJob.isSchedulePresent(), "Schedule is not Present");
	
	}
	
	

}
