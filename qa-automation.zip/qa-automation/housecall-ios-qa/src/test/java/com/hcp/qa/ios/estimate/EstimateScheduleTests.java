package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.common.EstimateFlowWidget;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.estimate.NewEstimatePage;
import com.hcp.qa.ios.pages.schedule.SchedulePage;

public class EstimateScheduleTests extends BaseiOSTest {
	
	private EstimateHelper estimateHelper;

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}
	
	@Test
	public void scheduleEstimate() {
		createAndScheduleEstimate();

		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.waitForPageToLoad(2);
		estimateHelper.saveEstimateAndHandlePrompts();

		EstimatePage estimate = new EstimatePage(driver);
		estimate.scrollDown();
		Assert.assertTrue(estimate.isSchedulePresent(), "Schedule is not Present");
		estimate.scrollUp();
		EstimateFlowWidget estimateFlow = new EstimateFlowWidget(driver);
		Assert.assertTrue(estimateFlow.isOnMyWayButtonPresent(), "ON MY WAY is not Present");
		Assert.assertTrue(estimateFlow.isStartButtonPresent(), "START is not Present");
		Assert.assertTrue(estimateFlow.isFinishButtonPresent(), "FINISH is not Present");
		estimate.goBackToDashboard();
	}

	@Test
	public void unscheduleEstimate() {

		createAndScheduleEstimate();
		estimateHelper.saveEstimateAndHandlePrompts();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.scrollDown();
		estimate.waitForPageToLoad(2);
		estimate.clickSchedule();

		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.clickOnUnschedule();
		scheduleWidget.clickDone();
		estimate.waitForPageToLoad(2);
		
		estimate = new EstimatePage(driver);
		// FIXME: Change to Unscheduled when TS-289 is fixed
		Assert.assertFalse(estimate.isSchedulePresent(), "Schedule is Present");
		estimate.goBackToDashboard();
	}

	@Test
	public void scheduleWithEmployee() {
		createAndScheduleEstimate();

		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.clickMyEmployees();
		scheduleWidget.selectTestEmployee();
		scheduleWidget.clickDone();

		estimateHelper.saveEstimateAndHandlePrompts();

		EstimatePage estimate = new EstimatePage(driver);
		estimate.scrollDown();
		Assert.assertTrue(estimate.isSchedulePresent(), "Schedule is not Present");
		Assert.assertTrue(estimate.isEmployeePresent(), "Employee is not Present");
		estimate.goBackToDashboard();
	}

	private void createAndScheduleEstimate() {
		estimateHelper.gotoNewEstimatePage();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickCustomers();
		String customerName = "Test Customer";
		estimateHelper.searchAndSelectCustomerFromEstimatePage(customerName);

		newEstimate.waitForPageToLoad(2);
		newEstimate.clickAddSchedule();
		newEstimate.waitForPageToLoad(2);

		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.clickDone();
	}

}
