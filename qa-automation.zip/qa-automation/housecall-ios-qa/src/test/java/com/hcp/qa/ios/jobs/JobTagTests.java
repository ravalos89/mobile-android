package com.hcp.qa.ios.jobs;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.JobHelper;
import com.hcp.qa.ios.pages.job.JobCustomerSearchPage;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.JobTagPage;
import com.hcp.qa.ios.pages.job.NewJobPage;

public class JobTagTests extends BaseiOSTest{
	
	protected static Logger LOG = LoggerFactory.getLogger(JobTagTests.class);
	String customerName = "Test Customer";
	static String tagName;
	JobHelper jobHelper;

	@BeforeClass
	public void setUp() {
		jobHelper = new JobHelper(driver);
	}

	@Test
	public void addJobTag() {
		NewJobPage newJob = jobHelper.gotoNewJob();
		newJob.clickCustomers();

		JobCustomerSearchPage customerSearch = new JobCustomerSearchPage(driver);
		customerSearch.searchforCustomer(customerName);
		customerSearch.waitForPageToLoad(1);
		customerSearch.clickCustomer(customerName);

		jobHelper.createJob();
		
		JobTagPage tagWidget = new JobTagPage(driver);
		tagName = createTag();
		Assert.assertTrue(tagWidget.isTagDisplayed(tagName), "New Tag is not added");
	}

	@Test(dependsOnMethods="addJobTag")
	public void deleteJobTag() {
		JobTagPage tagWidget = new JobTagPage(driver);
		tagWidget.clickEditTag();

		tagWidget.enterTagInSearch(tagName);
		tagWidget.clickOnTag(tagName);
		tagWidget.clickOnBack();
		tagWidget.waitForPageToLoad(3);
		Assert.assertFalse(tagWidget.isTagDisplayed(tagName), "Added Tag is not Deleted");
		
		JobPage jobPage = new JobPage(driver);
		jobPage.goBackToDashboard();
	}
	
	private String createTag() {
		JobTagPage tagWidget = new JobTagPage(driver);
		
		NewJobPage newJob = new NewJobPage(driver);
		newJob.scrollDown();
		newJob.clickJobTags();
		
		tagWidget.clickAddTag();
		String tagName="Tag_"+Calendar.getInstance().getTimeInMillis();
		tagWidget.enterNewTag(tagName);
		tagWidget.clickAddBtn();
		tagWidget.clickOnBack();
		tagWidget.waitForPageToLoad(4);
		return tagName;
	}

}
