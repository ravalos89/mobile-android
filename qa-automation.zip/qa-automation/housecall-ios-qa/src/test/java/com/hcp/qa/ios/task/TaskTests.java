package com.hcp.qa.ios.task;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.task.TaskPage;

public class TaskTests extends BaseiOSTest{
	
	protected static Logger LOG = LoggerFactory.getLogger(TaskTests.class);
	String employeeName = "HCP QA Pro";
	static String taskName;
	
	@Test
	public void addTask() {
		TaskPage taskPage = new TaskPage(driver);
		taskName = createTask();
		Assert.assertTrue(taskPage.isTaskDisplayed(taskName), "New Task is not added");
	}
	
	@Test(dependsOnMethods="addTask")
	public void completeTask() {
		TaskPage taskPage = new TaskPage(driver);
		taskPage.clickCircleBtn(taskName);
		taskPage.waitForPageToLoad(2);
		taskPage.navigateToMyTask();
		Assert.assertTrue(taskPage.isTaskDisplayed(taskName), "New Task is not completed");
	}

	@Test(dependsOnMethods="addTask")
	public void deleteTask() {
		JobPage jobPage = new JobPage(driver);
		TaskPage taskPage = new TaskPage(driver);
		taskPage.clickCircleBtn(taskName);
		taskPage.waitForPageToLoad(2);
		
		taskPage.navigateToAllTasks();
		Assert.assertTrue(taskPage.isTaskDisplayed(taskName), "New Task is not displayed");
		taskPage.clickTask(taskName);
		
		taskPage.clickDeleteTask();
		taskPage.confirmDeleteTask();
		Assert.assertFalse(taskPage.isTaskDisplayed(taskName), "New Task is not deleted");
		jobPage.goBackToDashboard();
	}
	
	private String createTask() {
		TaskPage taskPage = new TaskPage(driver);
		taskPage.clickHambergurMenu();
		
		taskPage.clickAddTask();
		String taskName="Task_"+Calendar.getInstance().getTimeInMillis();
		taskPage.enterNewTask(taskName);
		taskPage.clickDateBtn();
		taskPage.clickSaveBtn();
		taskPage.clickAssignTo();
		
		taskPage.clickEmployee(employeeName);
		taskPage.clickDoneBtn();
		taskPage.waitForPageToLoad(4);
		return taskName;
	}

}
