package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.job.ApproveDialog;
import com.hcp.qa.ios.pages.job.JobPage;
import com.hcp.qa.ios.pages.job.SignaturePage;

public class EstimateApprovalTests extends BaseiOSTest{
	
	private EstimateHelper estimateHelper;
	
	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}

	@Test
	public void estimateApprove()
	{
		estimateHelper.createEstimate();
		
		EstimatePage estimate = new EstimatePage(driver);
		JobPage job = new JobPage(driver);
		job.clickApprove();
		
		ApproveDialog approveDialog = new ApproveDialog(driver);
		approveDialog.clickApproveEstimate();
		
		SignaturePage estimateSignature = new SignaturePage(driver);
		estimateSignature.addSignature();
		estimateSignature.clickDoneSigning();
		
		Assert.assertFalse(estimate.isApprovedStatusPresent(),"Approved Status is not present");
		job.goBackToDashboard();
	}

}
