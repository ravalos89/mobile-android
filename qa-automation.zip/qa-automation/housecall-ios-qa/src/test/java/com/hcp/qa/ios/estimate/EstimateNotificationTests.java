package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.common.EstimateFlowWidget;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.estimate.NewEstimatePage;
import com.hcp.qa.ios.pages.schedule.SchedulePage;

public class EstimateNotificationTests extends BaseiOSTest {

	private static EstimateHelper estimateHelper;

	@BeforeClass
	public void createAndScheduleEstimate() {
		estimateHelper = new EstimateHelper(driver);
		estimateHelper.gotoNewEstimatePage();
		NewEstimatePage newEstimate = new NewEstimatePage(driver);
		newEstimate.clickCustomers();
		String customerName = "Test Customer";
		estimateHelper.searchAndSelectCustomerFromEstimatePage(customerName);

		newEstimate.waitForPageToLoad(2);
		newEstimate.clickAddSchedule();
		newEstimate.waitForPageToLoad(2);

		SchedulePage scheduleWidget = new SchedulePage(driver);
		scheduleWidget.clickDone();

		newEstimate.waitForPageToLoad(2);
		estimateHelper.saveEstimateAndHandlePrompts();

	}

	@Test
	public void checkOMW() {
		EstimateFlowWidget estimateFlow = new EstimateFlowWidget(driver);
		estimateFlow.clickOmw();
		estimateFlow.confirmOMW();
		estimateFlow.clickOK();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.waitForPageToLoad(2);
		Assert.assertTrue(estimate.isStatusInProgress(), "The status of the Estimate is not in Progress");
		// FIXME: Gmail connectivity issues on bitrise
		// NotificationHelper notificationHelper=new NotificationHelper();
		// notificationHelper.checkNotification("en route", "en route", true);

	}

	@Test(dependsOnMethods = "checkOMW")
	public void checkStart() {
		EstimateFlowWidget estimateFlow = new EstimateFlowWidget(driver);
		estimateFlow.clickStart();
		estimateFlow.confirmStart();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.waitForPageToLoad(2);
		Assert.assertTrue(estimate.isStatusInProgress(), "The status of the Estimate is not in Progress");
	}

	@Test(dependsOnMethods = "checkStart")
	public void checkFinish() {
		EstimateFlowWidget estimateFlow = new EstimateFlowWidget(driver);
		estimateFlow.clickFinish();
		EstimatePage estimate = new EstimatePage(driver);
		estimateFlow.confirmFinish();
		estimateFlow.clickOK();
		estimate.waitForPageToLoad(2);

		Assert.assertTrue(estimate.isStatusDone(), "The status of the Estimate is not Done ");
		// FIXME: Gmail connectivity issues on bitrise put a maven flag for check
		// notifications
		// NotificationHelper notificationHelper=new NotificationHelper();
		// notificationHelper.checkNotification("finished", "finished", true);
		estimate.goBackToDashboard();

	}

}
