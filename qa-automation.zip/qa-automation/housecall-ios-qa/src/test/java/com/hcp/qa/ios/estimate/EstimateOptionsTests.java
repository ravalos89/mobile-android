package com.hcp.qa.ios.estimate;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.hcp.qa.ios.BaseiOSTest;
import com.hcp.qa.ios.helpers.EstimateHelper;
import com.hcp.qa.ios.pages.common.DashboardPage;
import com.hcp.qa.ios.pages.estimate.CancelEstimateDialog;
import com.hcp.qa.ios.pages.estimate.DeleteEstimateDialog;
import com.hcp.qa.ios.pages.estimate.EstimateMoreMenu;
import com.hcp.qa.ios.pages.estimate.EstimatePage;
import com.hcp.qa.ios.pages.estimate.options.AddOptionDialog;
import com.hcp.qa.ios.pages.estimate.options.CopyOptionDialog;
import com.hcp.qa.ios.pages.estimate.options.RenameOptionDialog;

public class EstimateOptionsTests extends BaseiOSTest {

	private EstimateHelper estimateHelper;

	@BeforeClass
	public void setup() {
		estimateHelper = new EstimateHelper(driver);
	}
	@Test
	public void addOption() {
		createNewOption();
		EstimatePage estimate = new EstimatePage(driver);
		Assert.assertTrue(estimate.isOptionDisplayed("OPTION #1"), "New Option is not added");
		estimate.goBackToDashboard();
	}

	@Test
	public void copyToOption() {
        String copiedOptionName = "COPY OF OPTION #1";

        copyOption();
		EstimatePage estimate = new EstimatePage(driver);
    	estimate.clickOption(copiedOptionName);
		
		Assert.assertTrue(estimate.isOptionDisplayed(copiedOptionName), "New Option is not added");
		estimate.goBackToDashboard();
	}

	@Test
	public void renameOption() {

		String renamedOptionName = "OPTION #2 RENAMED";
		createNewOption();
		EstimatePage estimate = new EstimatePage(driver);

		estimate.clickMore();
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickRenameOption();

		RenameOptionDialog renameDialog = new RenameOptionDialog(driver);
		renameDialog.enterOptionName(renamedOptionName);
		renameDialog.clickConfirm();
		Assert.assertTrue(estimate.isOptionDisplayed(renamedOptionName), "New Option is not renamed");
		estimate.goBackToDashboard();
	}
	
	@Test
	public void cancelEstimate() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickMore();
		
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickCancelEstimate();
		
		CancelEstimateDialog cancelDialog = new CancelEstimateDialog(driver);
		cancelDialog.confirmCancel();
		
	    DashboardPage dashboard= new DashboardPage(driver); 
	    Assert.assertTrue(dashboard.isDisplayed(), "Estimate is not cancelled");
	}
	
	@Test
	public void deleteEstimate() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickMore();
		
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickDeleteEstimate();
		
		DeleteEstimateDialog deleteDialog = new DeleteEstimateDialog(driver);
		deleteDialog.confirmDelete();
		
		DashboardPage dashboard= new DashboardPage(driver); 
		Assert.assertTrue(dashboard.isDisplayed(), "Estimate is not deleted");
	}
	
	
	@Test
	public void deleteOption() {
		String copiedOptionName = "COPY OF OPTION #1";
		
		copyOption();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickOption(copiedOptionName);
		estimate.clickMore();
		
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickDeleteOption();
		
		DeleteEstimateDialog deleteDialog = new DeleteEstimateDialog(driver);
		deleteDialog.confirmOption();
		
		Assert.assertFalse(estimate.isOptionDisplayed(copiedOptionName), "New Option is not deleted");
		estimate.goBackToDashboard();
	}
	
	@Test
  	public void cancelOption() {
		String copiedOptionName = "COPY OF OPTION #1";
	
		copyOption();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickOption(copiedOptionName);
		estimate.clickMore();
		
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickCancelOption();
		
		DeleteEstimateDialog deleteDialog = new DeleteEstimateDialog(driver);
		deleteDialog.confirmOption();
		
		Assert.assertFalse(estimate.isOptionDisplayed(copiedOptionName), "New Option is not cancelled");
		estimate.goBackToDashboard();
	}

	private void createNewOption() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickMore();

		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickAddOption();
		AddOptionDialog addOptionDialog = new AddOptionDialog(driver);
		addOptionDialog.clickAdd();
	}
	
	private void copyOption() {
		estimateHelper.createEstimate();
		EstimatePage estimate = new EstimatePage(driver);
		estimate.clickMore();
		
		EstimateMoreMenu moreMenu = new EstimateMoreMenu(driver);
		moreMenu.clickCopyToOption();

		CopyOptionDialog copyOptionDialog = new CopyOptionDialog(driver);
		copyOptionDialog.clickCopy();
	}
		
}