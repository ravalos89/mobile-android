package com.hcp.qa.api;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.testdataprovider.CsvDataProvider;
import com.hcp.qa.helpers.PaginationHelper;
import com.hcp.qa.models.Employee;
import com.hcp.qa.models.ResultsList;

import io.restassured.response.Response;

import static org.hamcrest.CoreMatchers.notNullValue;

public class EmployeeTest extends BaseAPITest {

	public static final String EMPLOYEE_URI = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.employee.uri");

	@Test
	public void getAllEmployees() {
		ResultsList response = getEmployeeResponse();
		response.getEmployees().get(0).getId();
	}

	@Test(dataProvider = "CSVDataProvider", dataProviderClass = CsvDataProvider.class)
	public void getPaginatedDataEmployee(int page, int page_size, int expectedStatusCode, int expected_page,
			int expected_page_size) {
		Response response = getPagedData(EMPLOYEE_URI, page, page_size, expectedStatusCode);
		PaginationHelper.verifyPaginationDetails(response, expected_page, expected_page_size);
	}

	// There is no end point currently to create an employee from V1 API - Monday
	// January 4th 2021.
	@Test(enabled = false)
	public void testCreateEmployee() {
		Response employeeResponse = createEmployee();
		assertResponse(employeeResponse);
	}

	private ResultsList getEmployeeResponse() {
		getUrl(EmployeeTest.EMPLOYEE_URI, HttpStatus.SC_OK).getBody().prettyPeek();
		return getUrl(EmployeeTest.EMPLOYEE_URI, HttpStatus.SC_OK).as(ResultsList.class);
	}

	private Response createEmployee() {
		Employee newEmployee = generateEmployee();
		return postUrl(EMPLOYEE_URI, newEmployee, HttpStatus.SC_CREATED);
	}

	private Employee generateEmployee() {
		Employee employee = new Employee();
		employee.setFirstName("EmployeeTestAuto" + System.currentTimeMillis());
		employee.setLastName("Test");
		employee.setRole("field tech");
		return employee;
	}

	private static void assertResponse(Response response) {
		response.
		//@formatter:off
                        then().assertThat()
                .statusCode(HttpStatus.SC_CREATED)
                .body("id", notNullValue());
        //@formatter:off
    }

}
