package com.hcp.qa.api;

import java.io.File;

import org.apache.http.HttpStatus;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.testdataprovider.CsvDataProvider;
import com.hcp.qa.helpers.PaginationHelper;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.ResultsList;
import com.hcp.qa.models.search.CustomerSearchQuery;

import io.restassured.response.Response;

import static org.hamcrest.CoreMatchers.notNullValue;

public class CustomerTest extends BaseAPITest {
    public static final String ACCESS_TOKEN = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.token");
    public static final String CUSTOMER_URI = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.customer.uri");
    public static final String CUSTOMER_NAME = "API";
    public ApiClient client = new ApiClient(ACCESS_TOKEN);

    @Test
    public void getAllCustomers() {
        Response response = client.getCustomers();
        ResultsList resultList = response.as(ResultsList.class);

        SoftAssertions soft = new SoftAssertions();
        soft.assertThat(response.statusCode()).isEqualTo(HttpStatus.SC_OK);
        soft.assertThat(resultList.getCustomers().size()).isLessThan(resultList.getTotalItems());
        soft.assertAll();
    }

    @Test(dataProvider = "CSVDataProvider", dataProviderClass = CsvDataProvider.class)
    public void getPaginatedDataCustomer(int page, int page_size, int expectedStatusCode, int expected_page,
                                         int expected_page_size) {

        CustomerSearchQuery query = new CustomerSearchQuery();
        query.setPage(page);
        query.setPageSize(page_size);

        Response response = client.getCustomers(query);
        PaginationHelper.verifyPaginationDetails(response, expected_page, expected_page_size);
    }

    @Test(dataProvider = "CSVDataProvider", dataProviderClass = CsvDataProvider.class)
    public void getIdInvalidDataCustomer(String description, String id, int expectedStatusCode) {
        String customerUrl = CUSTOMER_URI + File.separator + id;
        getUrl(customerUrl, expectedStatusCode);
    }

    @Test
    public void testCreateCustomer() {
        Response customerResponse = client.createCustomer(generateCustomer());
        assertResponse(customerResponse);
    }

    private Customer generateCustomer() {
        Customer customer = new Customer();
        customer.setFirstName(CUSTOMER_NAME + System.currentTimeMillis());
        return customer;
    }

    private void assertResponse(Response response) {
        response.then()
                .assertThat()
                .statusCode(HttpStatus.SC_CREATED)
                .body("id", notNullValue());
    }
}
