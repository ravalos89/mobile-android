package com.hcp.qa.api;

import org.apache.http.HttpStatus;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.models.search.SearchQuery;

import io.restassured.response.Response;

public class BaseAPITest {
	private static final String URL = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
	private static final String ORGANIZATION_AUTH_TOKEN = ConfigHandler
			.getStringPropertyValueFromKey("public.v1.api.token");
    private static final String THIRD_PARTY_APP_AUTH_TOKEN = ConfigHandler
			.getStringPropertyValueFromKey("public.v1.api.testapp.token");
	
	HttpRequestClient httpClient = new HttpRequestClient(URL, ORGANIZATION_AUTH_TOKEN);


	public Response getUrl(String url, int expectedStatusCode) {
		return httpClient.getUrl(url, expectedStatusCode);
	}

	public Response postUrl(String url, Object body, int expectedStatusCode) {
		return httpClient.postUrl(url, body, expectedStatusCode);
	}

	public Response postUrlWithThirdPartyAuth(String url, Object body, int expectedStatusCode) {
		HttpRequestClient httpClientThirdParty = new HttpRequestClient(THIRD_PARTY_APP_AUTH_TOKEN);
		return httpClientThirdParty.postUrl(url, body, expectedStatusCode);
	}
	
	public Response postUrlWithMultiPart(String url, String filePath) {
		return httpClient.postUrlWithMultiPart(url, filePath,  HttpStatus.SC_CREATED);
	}

    public Response getPagedData(String endpoint, int page, int page_size, int expectedStatusCode) {

        SearchQuery searchQuery = new SearchQuery();
		searchQuery.setPage(page);
		searchQuery.setPageSize(page_size);

       return httpClient.getWithQueryParams(searchQuery, endpoint);
    }

}
