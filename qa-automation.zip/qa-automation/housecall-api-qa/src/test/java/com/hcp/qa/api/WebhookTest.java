package com.hcp.qa.api;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;

public class WebhookTest extends BaseAPITest {
	private static final String WEBHOOK_SUBSCRIPTION_URI = ConfigHandler
			.getStringPropertyValueFromKey("public.v1.api.webhook.subscription.uri");

	private final String requestBody = "{}";

	@Test
	public void testPostWebhookSubscription() {
		postUrlWithThirdPartyAuth(WEBHOOK_SUBSCRIPTION_URI, requestBody, HttpStatus.SC_OK);

	}

//If deleted the webhook has to be enabled manually by running script in rails console.
	@Test(enabled = false)
	public void testDeleteWebhookSubscription() {
		postUrlWithThirdPartyAuth(WEBHOOK_SUBSCRIPTION_URI, requestBody, HttpStatus.SC_OK);

	}
}
