package com.hcp.qa.api;

import java.io.File;

import org.apache.http.HttpStatus;
import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Test;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.testdataprovider.CsvDataProvider;
import com.hcp.qa.helpers.PaginationHelper;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.JobLink;
import com.hcp.qa.models.LineItem;
import com.hcp.qa.models.ResultsList;
import com.hcp.qa.models.search.JobSearchQuery;

import io.restassured.response.Response;

import static org.hamcrest.CoreMatchers.notNullValue;

public class JobTest extends BaseAPITest {

	public static final String ACCESS_TOKEN = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.token");
	public static final String JOBS_URI = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.job.uri");
	public static final String LINKS_URI = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.links.uri");
	public static final String ATTACHMENTS_URI = ConfigHandler
			.getStringPropertyValueFromKey("public.v1.api.attachments.uri");
	public static final String CUSTOMER_ID = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.customer.id");
	public static final String ADDRESS_ID = ConfigHandler.getStringPropertyValueFromKey("public.v1.api.address.id");
	public static JobLink jobLink = new JobLink();
	public static final String jobLinkUrl = "http://google.com";
	private String jobId;

	public ApiClient client = new ApiClient(ACCESS_TOKEN);

	@Test
	public void getAllJobs() {
		ResultsList response = client.getJobs().getBody().as(ResultsList.class);
		jobId = response.getJobs().get(0).getId();
	}

	@Test(dataProvider = "CSVDataProvider", dataProviderClass = CsvDataProvider.class)
	public void getPaginatedData(int page, int page_size, int expectedStatusCode, int expected_page,
			int expected_page_size) {

		JobSearchQuery query = new JobSearchQuery();
		query.setPage(page);
		query.setPageSize(page_size);

		Response response = client.getJobs(query);
		PaginationHelper.verifyPaginationDetails(response, expected_page, expected_page_size);
	}

	@Test(dataProvider = "CSVDataProvider", dataProviderClass = CsvDataProvider.class)
	public void getIdInvalidData(String description, String id, int expectedStatusCode) {
		String jobsUrl = JOBS_URI+ File.separator + id;
		getUrl(jobsUrl, expectedStatusCode);
	}

	@Test(dependsOnMethods = "getAllJobs")
	public void testGetJobsByValidId() {
		String jobsUrl = JOBS_URI + File.separator + jobId;
		Response response = getUrl(jobsUrl, HttpStatus.SC_OK);
		assertJobResponse(response, HttpStatus.SC_OK);
	}

	@Test(enabled = false)
	public void testCreateJobs() {
		Response jobResponse = createJob();
		assertJobResponse(jobResponse, HttpStatus.SC_CREATED);
	}

	@Test(dependsOnMethods = "getAllJobs")
	public void testAddingAttachmentToJob() {
		String jobsUrl = JOBS_URI + File.separator + jobId + ATTACHMENTS_URI;
		String filePath = getAttachmentPath();
		Response response = postUrlWithMultiPart(jobsUrl, filePath);
		assertJobAttachmentResponse(response);
	}

	@Test(dependsOnMethods = "getAllJobs", enabled = false)
	public void testAddJobLinkFromThirdPartyApp() {
		Response jobLinkResponse = createJobLink(jobId);
		assertCreateJobLinkResponse(jobLinkResponse);
	}

	@Test
	public void createJobWithLineItem() {
		Job job = new Job();
		Customer customer = client.getCustomers().as(ResultsList.class).getCustomers().get(0);
		job.setCustomerId(customer.getId());

		LineItem lineItem = new LineItem();
		String lineItemName = "line item name";
		String lineItemDescription = "Line item desc";
		double unitCost = 99.9;
		double unitPrice = 44;
		int quantity = 5;

		lineItem.setName(lineItemName);
		lineItem.setDescription(lineItemDescription);
		lineItem.setUnitCost(unitCost);
		lineItem.setUnitPrice(unitPrice);
		lineItem.setQuantity(quantity);
		job.addLineItem(lineItem);

		Response jobResponse = client.createJob(job);


		Job result = jobResponse.as(Job.class);

		SoftAssertions soft = new SoftAssertions();
		soft.assertThat(result.getDescription()).isEqualTo(lineItemName);
		soft.assertThat(result.getTotalAmount()).isEqualTo(unitPrice * quantity);
		soft.assertAll();

	}

	protected String getAttachmentPath() {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("testdata/com/hcp/qa/api/job-attachment.jpeg").getFile());
		return file.getAbsolutePath();
	}

	

	public Response createJob() {
		Job newJob = generateJob();
		return postUrl(JOBS_URI, newJob, HttpStatus.SC_CREATED);
	}

	private Response createJobLink(String jobId) {
		jobLink.setTitle(jobId);
		jobLink.setUrl(jobLinkUrl);
		String jobsUrl = JOBS_URI + File.separator + jobId + LINKS_URI;
		return postUrlWithThirdPartyAuth(jobsUrl, jobLink, HttpStatus.SC_CREATED);
	}

	private Job generateJob() {
		Job job = new Job();
		job.setAddressId(ADDRESS_ID);
		job.setCustomerId(CUSTOMER_ID);
		return job;
	}

	public ResultsList getJobsResponse(String requestUrl, int expectedStatusCode) {
		return getUrl(requestUrl, expectedStatusCode).as(ResultsList.class);
	}

	public static void assertJobResponse(Response response, int httpStatusCode) {
		response.
		//@formatter:off
                        then().assertThat()
                .statusCode(httpStatusCode)
                .log().all()
                .body("id", notNullValue())
                .body("customer.id", notNullValue());
        //@formatter:off
    }

    public static void assertCreateJobAttachmentResponse(Response response, int httpStatusCode) {
        response.
                //@formatter:off
                        then().assertThat()
                .statusCode(httpStatusCode)
                .log().all()
                .body("id", notNullValue());
        //@formatter:off
    }

    public static void assertCreateJobLinkResponse(Response response) {
        response.
                //@formatter:off
                        then().assertThat()
                .statusCode(HttpStatus.SC_CREATED)
                .log().all()
                .body("id", notNullValue());
        //@formatter:off
    }

    public static void assertJobAttachmentResponse(Response response) {
        response.
                //@formatter:off
                        then().assertThat()
                .statusCode(HttpStatus.SC_CREATED)
                .log().all()
                .body("id", notNullValue());
        //@formatter:off
    }

}
