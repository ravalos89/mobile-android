package com.hcp.qa.common;

import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;

public class URLHandler {

    public static String createURL(final String SCHEME, final String APITOKEN, final String DOMAIN, final int PORT, final String uri){
        return getURL(SCHEME, APITOKEN, DOMAIN, PORT, uri, null, null);
    }

    public static String createURL(final String SCHEME, final String APITOKEN, final String DOMAIN, final int PORT, final String uri, List<NameValuePair> parameterQueryString){
        return getURL(SCHEME, APITOKEN, DOMAIN, PORT, uri, parameterQueryString, null);
    }

    public static String getURL(final String scheme, final String userInfo,
                                final String host, final int port, final String path,
                                final List<NameValuePair> queryParameters, final String fragment) {

        URIBuilder uri = getUriBuilder(scheme, userInfo, host, port, path, fragment);
        if (queryParameters != null) {
            uri.setParameters(queryParameters);
        }
        return uri.toString();
    }

    public static String getURLWithCustomQueryString(final String scheme, final String userInfo,
                                                    final String host, final int port, final String path,
                                                    final String queryString, final String fragment) {

        URIBuilder uri = getUriBuilder(scheme, userInfo, host, port, path, fragment);
        if (queryString != null) {
            uri.setCustomQuery(queryString);
        }
        return uri.toString();
    }

    private static URIBuilder getUriBuilder(final String scheme, final String userInfo,
                              final String host, final int port, final String path,
                              final String fragment) {
        URIBuilder uri = new URIBuilder();
        if (scheme != null) {
            uri.setScheme(scheme);
        }

        if (userInfo != null) {
            uri.setUserInfo(userInfo);
        }

        if (host != null) {
            uri.setHost(host);
        }

        if (port != 0) {
            uri.setPort(port);
        }

        if (path != null) {
            uri.setPath(path);
        }

        if (fragment != null) {
            uri.setFragment(fragment);
        }
        return uri;
    }
}

