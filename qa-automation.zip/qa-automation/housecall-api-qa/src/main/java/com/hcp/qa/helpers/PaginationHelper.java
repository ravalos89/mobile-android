package com.hcp.qa.helpers;

import java.util.ArrayList;

import org.testng.Assert;

import com.hcp.qa.models.ResultsList;

import io.restassured.response.Response;

public class PaginationHelper {

   public static void verifyPaginationDetails(Response response, int expected_page,
                                                   int expected_page_size) {
       ResultsList jobResultsList = response.as(ResultsList.class);
        int actual_page = jobResultsList.getPage();
        int actual_page_size = jobResultsList.getPageSize();
        Assert.assertEquals(actual_page, expected_page);
        Assert.assertEquals(actual_page_size, expected_page_size);
   }

    public static boolean checkIfListIsSortedInAscendingOrder(ArrayList<Integer> arraylist) {
        boolean isSortedInAscendingOrder = true;
        for (int i = 1; i < arraylist.size(); i++) {
            if (arraylist.get(i - 1).compareTo(arraylist.get(i)) > 0) {
                isSortedInAscendingOrder = false;
                break;
            }
        }
        return isSortedInAscendingOrder;
    }

    public static boolean checkIfListIsSortedInDescendingOrder(ArrayList<Integer> arraylist) {
        boolean isSortedInDescendingOrder = true;
        for (int i = 1; i < arraylist.size(); i++) {
            if (arraylist.get(i - 1).compareTo(arraylist.get(i)) < 0) {
                isSortedInDescendingOrder = false;
                break;
            }
        }
        return isSortedInDescendingOrder;
    }
}
