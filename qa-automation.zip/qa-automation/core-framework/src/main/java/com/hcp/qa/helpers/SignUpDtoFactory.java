package com.hcp.qa.helpers;

import java.util.ArrayList;

import org.apache.commons.lang.RandomStringUtils;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.models.growth.CompanySize;
import com.hcp.qa.models.growth.Industry;
import com.hcp.qa.models.growth.SignUp;


public class SignUpDtoFactory {

    public final static String DEFAULT_ORGANIZATION_TIME_ZONE = TimezoneHelper
            .getNewAppointmentTimeZoneShortcut(TimezoneHelper.defaultOrganizationTimeZoneId);

    public static SignUp getDefaultCompany(String email) {
        SignUp signUp = new SignUp();

        signUp.setEmail(email);

        String refererLink = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url") + "/signup/";

        signUp.setPhone(ConfigHandler.getStringPropertyValueFromKey("hcp.web.mobile.number"));
        signUp.setDeclaredIndustry(Industry.HANDYMAN);
        signUp.setNumberOfEmployees(CompanySize.OWNER);
        signUp.setPassword(ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.password"));
        signUp.setStreet("1234 Auto Street");
        signUp.setCity("Carlsbad");
        signUp.setState("CA");
        signUp.setCountry("US");
        signUp.setPostalCode("92008");
        signUp.setCompanyName("Company" + RandomStringUtils.randomAlphabetic(5));
        signUp.setLatitude(33.9415889);
        signUp.setLongitude(-118.40853);
        signUp.setOnboardingFlow("progressive_setup_onboarding");
        signUp.setMarketingChannel("OrganicOther");
        signUp.setLeadType("MQL");
        signUp.setConversionPage(refererLink);
        signUp.setDontSendAppDownloadLink(false);
        signUp.setRequestedGatedContent("");
        signUp.setCompanyGoal("");
        signUp.setFeatures(new ArrayList<>());
        signUp.setFeatureInterests(new ArrayList<>());
        signUp.setGoogleClickId("");
        signUp.setHttpReferer(refererLink);
        signUp.setLeadId("lead_1925f6e20ca7421682cab5cda1c38d0a");
        signUp.setGrowthExperiments(new ArrayList<>());
        signUp.setIndustry("");
        signUp.setSignUpSource("web");


        signUp.setFirstName("QA " + RandomStringUtils.randomAlphabetic(5));
        signUp.setLastName("PRO");
        signUp.setCompanyName("Company" + RandomStringUtils.randomAlphabetic(5));
        signUp.setMarketingSubchannel(ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url"));

        return signUp;
    }
}
