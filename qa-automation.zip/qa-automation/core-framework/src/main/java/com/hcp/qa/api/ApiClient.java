package com.hcp.qa.api;

import org.apache.http.HttpStatus;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.models.Customer;
import com.hcp.qa.models.Job;
import com.hcp.qa.models.estimate.payload.EstimatePayload;
import com.hcp.qa.models.search.CustomerSearchQuery;
import com.hcp.qa.models.search.EmployeeSearchQuery;
import com.hcp.qa.models.search.JobSearchQuery;

import io.restassured.response.Response;

public class ApiClient {
    private final String JOBS_ENDPOINT = "/jobs";
    private final String CUSTOMERS_ENDPOINT = "/customers";
    private final String EMPLOYEES_ENDPOINT = "/employees";
    private final String ESTIMATES_ENDPOINT = "/estimates";
    private HttpRequestClient client;

    public ApiClient(String accessKey) {
        String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
        this.client = new HttpRequestClient(baseUrl, accessKey);
    }

    public ApiClient setAccessKey(String accessKey) {
        String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
        this.client = new HttpRequestClient(baseUrl, accessKey);
        return this;
    }

    public Response createJob(Job job) {
        return client.postUrl( JOBS_ENDPOINT, job, HttpStatus.SC_CREATED);
    }

    public Response getJobs() {
        return getJobs(new JobSearchQuery());
    }

    public Response getJobs(JobSearchQuery searchQuery) {
        return client.getWithQueryParams(searchQuery, JOBS_ENDPOINT);
    }

    public Response getCustomers() {
        return getCustomers(new CustomerSearchQuery());
    }

    public Response getCustomers(CustomerSearchQuery searchQuery) {
        return client.getWithQueryParams(searchQuery, CUSTOMERS_ENDPOINT);
    }

    public Response getEmployees(EmployeeSearchQuery searchQuery) {
        return client.getWithQueryParams(searchQuery, EMPLOYEES_ENDPOINT);
    }

    public Response createCustomer(Customer customer) {
        return client.postUrl( CUSTOMERS_ENDPOINT, customer, HttpStatus.SC_CREATED);
    }

    public Response createEstimate(EstimatePayload estimate) {
        return client.postUrl( ESTIMATES_ENDPOINT, estimate, HttpStatus.SC_CREATED);
    }
}
