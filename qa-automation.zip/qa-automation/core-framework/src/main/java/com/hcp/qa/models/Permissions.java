package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Permissions {

    private boolean can_add_and_edit_job;
    private boolean can_be_booked_online;
    private boolean can_call_and_text_with_customers;
    private boolean can_chat_with_customers;
    private boolean can_delete_and_cancel_job;
    private boolean can_edit_message_on_invoice;
    private boolean can_see_street_view_data;
    private boolean can_share_job;
    private boolean can_take_payment_see_prices;
    private boolean can_see_customers;
    private boolean can_see_full_schedule;
    private boolean can_see_future_jobs;
    private boolean can_see_marketing_campaigns;
    private boolean can_see_reporting;
    private boolean can_edit_settings;
    private boolean is_point_of_contact;
    private boolean is_admin;
    private boolean show_customers;
}
