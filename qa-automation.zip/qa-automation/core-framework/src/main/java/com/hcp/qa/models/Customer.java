package com.hcp.qa.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Customer {
    private String id;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    private String email;
    @JsonProperty("mobile_number")
    private String mobileNumber;
    @JsonProperty("home_number")
    private String homeNumber;
    @JsonProperty("work_number")
    private String workNumber;
    private String company;
    @JsonProperty("notifications_enabled")
    private boolean notificationsEnabled;
    private List<String> tags;
    private List<Address> addresses;
    @JsonProperty("lead_source")
    private String leadSource;

    public String getDisplayName() {
        return firstName + " " + lastName;
    }
}
