package com.hcp.qa.common;

public class Sleep {

    public static void seconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException ignored) {
        }
    }
}
