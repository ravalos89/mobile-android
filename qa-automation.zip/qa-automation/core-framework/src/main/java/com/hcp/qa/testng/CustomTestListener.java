package com.hcp.qa.testng;

import java.util.Arrays;
import java.util.Iterator;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

import static com.hcp.qa.testng.LogHelper.log;
import static com.hcp.qa.testng.LogHelper.printLine;

public class CustomTestListener implements ITestListener,ISuiteListener {
	@Override
	public void onTestStart(ITestResult result) {

		log(result.getName() + " STARTED ");
		if (result.getParameters() != null && result.getParameters().length != 0)
			log("with parameters " + Arrays.toString(result.getParameters()));
		printLine();
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		log(result.getName() + " SUCCESS");
		printLine();
	}

	@Override
	public void onTestFailure(ITestResult result) {
		log(result.getName() + " FAILED  with following Exception\n" + result.getThrowable().getLocalizedMessage());
		printLine();
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		log(result.getName() + " SKIPPED because of the following Exception\n" + result.getThrowable().getLocalizedMessage());
		printLine();
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onStart(ITestContext context) {
		log("\n" + context.getName() + " STARTED");
		printLine();
	}

	@Override
	public void onFinish(ITestContext context) {
		log(context.getName() + " FINISHED");

		Iterator<ITestResult> skippedTestCases = context.getSkippedTests().getAllResults().iterator();
		while (skippedTestCases.hasNext()) {
			ITestResult skippedTestCase = skippedTestCases.next();
			ITestNGMethod method = skippedTestCase.getMethod();
			if (context.getSkippedTests().getResults(method).size() > 0) {
				System.out.println("Removing skipped test case result for:" + skippedTestCase.getName());
				skippedTestCases.remove();
			}
		}
		printLine();
	}
	
	@Override
	public void onFinish(ISuite suite) {		
		Iterator<ITestNGMethod> excludedTestCases =  suite.getExcludedMethods().iterator();
		printLine();
		System.out.println("Excluded Tests ");
		while (excludedTestCases.hasNext()) {
			ITestNGMethod excludedTestCase = excludedTestCases.next();
			String method = excludedTestCase.getMethodName();
			System.out.println(method);
		}
		printLine();
	}



}
