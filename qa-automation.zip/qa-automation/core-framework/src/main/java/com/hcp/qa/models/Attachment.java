package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Attachment {

    private String id;
    private String url;
    @JsonProperty("file_name")
    private String fileName;
    @JsonProperty("file_type")
    private String fileType;
}
