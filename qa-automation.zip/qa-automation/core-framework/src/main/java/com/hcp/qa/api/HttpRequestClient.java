package com.hcp.qa.api;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.util.Collection;
import java.util.Map;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;

import com.hcp.qa.models.mobile.FormDataPayload;
import com.hcp.qa.models.search.SearchQuery;

import io.restassured.config.EncoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class HttpRequestClient {

    protected final String url;
    private final Header apiKeyHeader;
    protected static EncoderConfig enConfig = new EncoderConfig();
    protected static RestAssuredConfig rConfig = RestAssuredConfig.config()
            .encoderConfig(enConfig
                    .appendDefaultContentCharsetToContentTypeIfUndefined(
                            false));
    protected static final String HEADER_CONTENT_TYPE = "content-type";
    protected static final String HEADER_ACCEPT = "Accept";
    protected static final String APPLICATION_JSON = "application/json";
    protected static final String MULTI_PART_FORM_DATA = "multipart/form-data";

    public HttpRequestClient(String url) {
        checkUrlNotEmpty(url);
        this.url = url;
        apiKeyHeader = null;
    }

    public HttpRequestClient(String url, String accessKey) {
        checkUrlNotEmpty(url);
        this.url = url;
        apiKeyHeader = new Header(HttpHeaders.AUTHORIZATION,
                ("Token " + accessKey));
    }

    private void checkUrlNotEmpty(String url) {
        if(url == null) {
            throw new RuntimeException("Cannot initialize with empty URL");
        }
    }

    public Response getUrl(String endpoint, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .config(rConfig)
                .log().ifValidationFails().
                        expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails().
                        when()
                .get(url + endpoint);
    }

    public Response deleteUrl(String endpoint, int expectedStatusCode) {
        return given()
                .header(apiKeyHeader)
                .config(rConfig)
                .log().ifValidationFails().
                expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails().
                when()
                .delete(url + endpoint);
    }

    public Response postUrl(String endpoint, Object body, int expectedStatusCode) {
        RequestSpecification request = given().header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON);

        if(apiKeyHeader != null) {
            request.header(apiKeyHeader);
        }

        return  request
                .config(rConfig)
                .body(body)
                .log().ifValidationFails()
                .expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails()
                .when()
                .post(url + endpoint);
    }

    public Response postUrl(String endpoint, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .config(rConfig)
                .log().ifValidationFails()
                .expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails()
                .when()
                .post(url + endpoint);
    }

    public Response postUrlWithMultiPart(String endpoint, String filePath, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .config(rConfig)
                .log().ifValidationFails()
                .expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails()
                .request() .multiPart("file", new File(filePath))
                .when()
                .post(url + endpoint);
    }

    public Response putUrl(String endpoint, Object body, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .config(rConfig).body(body)
                .log().all().
                        expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails().
                        when()
                .put(url + endpoint);
    }

    public Response patchUrl(String endpoint, String body, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .config(rConfig).body(body)
                .log().all().
                        expect()
                .statusCode(expectedStatusCode)
                .log().ifValidationFails().
                        when()
                .patch(url + endpoint);
    }

    protected Response delete(String endpoint, int expectedStatusCode) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(apiKeyHeader)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .urlEncodingEnabled(false)
                .log().all().
                        expect()
                .statusCode(expectedStatusCode)
                .log().body().
                        when()
                .delete(url + endpoint);
    }

    public Response getWithQueryParams(SearchQuery searchQuery, String endpoint) {
        return given()
                .header(HEADER_CONTENT_TYPE, APPLICATION_JSON)
                .header(HEADER_ACCEPT, APPLICATION_JSON)
                .header(apiKeyHeader)
                .queryParams(searchQuery.getParams())
                .config(rConfig)
                .log().ifValidationFails().
                expect()
                .statusCode(HttpStatus.SC_OK)
                .log().ifValidationFails().
                when()
                .get(url + endpoint);
    }

    public Response postForm(String endpoint, FormDataPayload formParams) {
        RequestSpecification request = given()
                .header(HEADER_CONTENT_TYPE, MULTI_PART_FORM_DATA)
                .header(apiKeyHeader)
                .formParams(formParams.getSingleValueParameters());

        Map<String, Collection<?>> multiValueParams = formParams.getMultiValueParameters();
        multiValueParams.forEach(request::formParam);

        return request
                .config(RestAssuredConfig.config().encoderConfig(EncoderConfig.encoderConfig()
                        .encodeContentTypeAs(MULTI_PART_FORM_DATA, ContentType.TEXT)))
                .log().ifValidationFails().
                expect()
                .statusCode(HttpStatus.SC_CREATED)
                .log().ifValidationFails().
                when()
                .post(url + endpoint);
    }
}

