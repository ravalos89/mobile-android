package com.hcp.qa.models;

import lombok.Data;

@Data
public class JobLink {
    private String title;
    private String url;
}
