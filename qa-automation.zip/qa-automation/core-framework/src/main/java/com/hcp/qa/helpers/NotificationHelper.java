package com.hcp.qa.helpers;

import com.hcp.qa.gmail.GmailMessageClient;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class NotificationHelper {

    public void checkNotification(String searchTxt, String notificationTxt, boolean notificationsEnabled) {
        int defaultTimeout = 15;
        GmailMessageClient gmailClient = GmailMessageClient.getInstance();
        if (notificationsEnabled) {
            String html = gmailClient.searchEmailAndGetMessageBody(searchTxt, defaultTimeout, true);
            assertThat(html).as("Notifications should be sent to Customer").contains(notificationTxt);
        } else {
            checkNotificationNotPresent(searchTxt, defaultTimeout);
        }
    }

    public void checkNotificationExists(String searchTxt, int timeout) {
        GmailMessageClient.getInstance().searchEmailAndGetMessageBody(searchTxt, timeout, true);
    }

    public void checkNotificationNotPresent(String searchTxt, int timeout) {
        String html;
        try {
            html = GmailMessageClient.getInstance().searchEmailAndGetMessageBody(searchTxt, timeout, true);
            assertThat(html).as("Notification should not be sent, but test found something").isNull();
        } catch (RuntimeException e) {
            String expectedException = "Email message for " + searchTxt + " not found";
            assertThat(e.getMessage()).as("Email not found exception not thrown ").contains(expectedException);
        }
    }
}
