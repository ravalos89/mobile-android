package com.hcp.qa.api;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static com.hcp.qa.helpers.TimezoneHelper.defaultOrganizationTimeZoneId;
import static java.time.ZoneId.of;
import static java.time.ZoneId.systemDefault;

public class ApiDateTimeFormatter {

    public static String formatLocalTimeToGmtTime(LocalDateTime datetime) {
        ZonedDateTime zonedSelectedTime = datetime.atZone(systemDefault());
        ZonedDateTime gmt0 = zonedSelectedTime.withZoneSameInstant(of("Etc/UTC"));
        return gmt0.format(DateTimeFormatter.ofPattern("EEE dd MMM yyyy HH:mm:ss ZZZZ"));
    }

    public static String formatLocalTimeToGmtTimeInRequestPayload(LocalDateTime datetime) {
        ZonedDateTime zonedDateTime = datetime.atZone(defaultOrganizationTimeZoneId);
        return formatZonedTimeToGmtTimeInRequestPayload(zonedDateTime);
    }

    public static String formatZonedTimeToGmtTime(ZonedDateTime datetime) {
        ZonedDateTime gmt0 = datetime.withZoneSameInstant(of("Etc/UTC"));
        return gmt0.format(DateTimeFormatter.ofPattern("EEE dd MMM yyyy HH:mm:ss ZZZZ"));
    }

    public static String formatZonedTimeToGmtTimeInRequestPayload(ZonedDateTime datetime) {
        ZonedDateTime gmt0 = datetime.withZoneSameInstant(of("Etc/UTC"));
        return gmt0.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'"));
    }
}
