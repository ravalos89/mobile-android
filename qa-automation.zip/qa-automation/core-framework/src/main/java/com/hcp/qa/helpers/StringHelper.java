package com.hcp.qa.helpers;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

public class StringHelper {

     // Each word in employee first/last name is capitalized, even if written in lowerCase
    public static String capitalizeEachWord(String stringWithSpaces) {
        return Arrays.stream(stringWithSpaces.split(" "))
                .map(StringUtils::capitalize)
                .collect(Collectors.joining(" "));
    }
}
