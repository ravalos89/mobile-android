package com.hcp.qa.helpers;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import static java.time.ZoneId.of;
import static java.time.ZoneId.systemDefault;

public class TimezoneHelper {

    public final static ZoneId defaultOrganizationTimeZoneId = of("America/Los_Angeles");

    public static LocalDateTime translateLocalhostTimeIntoDefaultOrganizationTimezone(LocalDateTime machineLocalDateTime) {
        return translateLocalhostTimeIntoTimezone(machineLocalDateTime, defaultOrganizationTimeZoneId);
    }
    
    public static LocalDateTime translateLocalhostTimeIntoTimezone(LocalDateTime machineLocalDateTime, ZoneId timezoneId) {
        ZonedDateTime zonedSelectedTime = machineLocalDateTime.atZone(systemDefault());
        ZonedDateTime selectedTimeInOrganizationTimezone = zonedSelectedTime.withZoneSameInstant(defaultOrganizationTimeZoneId);
        return selectedTimeInOrganizationTimezone.toLocalDateTime();
    }

    public static ZonedDateTime translateTimeIntoTimezone(ZonedDateTime dateTime, ZoneId timezoneId) {
        return dateTime.withZoneSameInstant(timezoneId);
    }

    public static String getNewAppointmentTimeZoneShortcut(ZoneId zoneId) {
        TimeZone timeZone = TimeZone.getTimeZone(zoneId);
        return getNewAppointmentTimeZoneShortcut(timeZone);
    }

    public static String getNewAppointmentTimeZoneShortcut(TimeZone timeZone) {
        return getDisplayNameInLocale(timeZone, Locale.US);
    }

    public static String getGmtString(TimeZone timeZone) {
        return getDisplayNameInLocale(timeZone, Locale.UK);
    }

    private static String getDisplayNameInLocale(TimeZone timeZone, Locale locale) {
        boolean isDaylightSavingTimeOn = timeZone.inDaylightTime(new Date());
        return timeZone.getDisplayName(isDaylightSavingTimeOn, TimeZone.SHORT, locale);
    }
}
