package com.hcp.qa.gmail;

import java.io.File;
import java.util.List;

public class EmailMessage {
	
	String msgBody;

	List<Attachment> attachments;

	public String getMsgBody() {
		return msgBody;
	}

	public void setMsgBody(String msgBody) {
		this.msgBody = msgBody;
	}

	public List<Attachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<Attachment> attachments) {
		this.attachments = attachments;
	}

	public boolean isAttachmentPresent(String attachmentName) {
		boolean isAttachmentPresent = false;
		for (Attachment attachment : attachments) {
			if (attachment.getAttachmentName().contains(attachmentName)) {
				isAttachmentPresent = true;
			}
		}
		return isAttachmentPresent;
	}
	
	public File getAttachmentFile(String attachmentName)
	{
		for (Attachment attachment : attachments) {
			if (attachment.getAttachmentName().contains(attachmentName)) {
				return attachment.getAttachmentFile();
			}
		}
		return null;
	}

}
