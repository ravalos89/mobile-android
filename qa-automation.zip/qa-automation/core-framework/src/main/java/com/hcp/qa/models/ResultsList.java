package com.hcp.qa.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ResultsList {

    private int page;
    @JsonProperty("page_size")
    private int pageSize;
    @JsonProperty("total_pages")
    private int totalPages;
    @JsonProperty("total_items")
    private int totalItems;
    //TODO QA-1107
    private List<Job> jobs;
    private List<Customer> customers;
    private List<Employee> employees;
}