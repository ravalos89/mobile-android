package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LineItem {
    private String name;
    private String description;
    @JsonProperty("unit_price")
    private double unitPrice;
    private int quantity;
    @JsonProperty("unit_cost")
    private double unitCost;
}
