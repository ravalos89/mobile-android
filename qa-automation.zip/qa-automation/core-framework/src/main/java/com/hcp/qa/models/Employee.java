package com.hcp.qa.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Employee {

    private String id;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    private String email;
    @JsonProperty("mobile_number")
    private String mobileNumber;
    private String role;
    @JsonProperty("color_hex")
    private String colorHex;
    @JsonProperty("avatar_url")
    private String avatarUrl;
    private List<String> tags;
    private Permissions permissions;
    @JsonProperty("company_name")
    private String companyName;
    @JsonProperty("company_id")
    private String companyId;

}
