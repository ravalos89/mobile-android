package com.hcp.qa.gmail;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.search.BodyTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.SearchTerm;

import org.apache.commons.io.FileUtils;
import org.apache.commons.mail.util.MimeMessageParser;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.common.Sleep;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GmailMessageClient {

	private static GmailMessageClient instance = null;

	String email = ConfigHandler.getStringPropertyValueFromKey("hcp.web.email");
	String password = ConfigHandler.getStringPropertyValueFromKey("hcp.web.gmail.password");

	private GmailMessageClient() {
	}

	public static GmailMessageClient getInstance() {
		if (instance == null)
			instance = new GmailMessageClient();
		return instance;
	}

	// Fetch the first message form the list returned for search term and get its
	// text
	public String searchEmailAndGetMessageBody(String searchFor, int timeOutInSecs, boolean deleteMsg) {
		return getEmailWithAttachments(searchFor, timeOutInSecs, deleteMsg).getMsgBody();
	}

	public EmailMessage getEmailWithAttachments(String searchFor, int timeOutInSecs, boolean deleteMsg) {
		Properties props = new Properties();
		props.put("mail.store.protocol", "imaps");
		EmailMessage emailMsg = new EmailMessage();

		Session session = Session.getDefaultInstance(props, null);
		String content;
		boolean isFound = false;
		try {
			for (int i = 0; i < timeOutInSecs; i++) {
				Store store = session.getStore("imaps");
				store.connect("imap.gmail.com", email, password);
				Folder inbox = store.getFolder("inbox");
				inbox.open(Folder.READ_WRITE);

				SearchTerm searchTerm = new BodyTerm(searchFor);
				Message[] messages = inbox.search(searchTerm);
				if (messages != null && messages.length != 0) {

					isFound = true;
					Message msg = messages[0];
					if (msg.getContent() instanceof String) {
						content = (String) msg.getContent();
						emailMsg.setMsgBody(content);
					} else {
						Multipart mp = (Multipart) msg.getContent();
						Object o = mp.getBodyPart(0).getContent();
						if (o instanceof String)
							content = (String) o;
						else {
							MimeMessage mme = (MimeMessage) msg;
							content = new MimeMessageParser(mme).parse().getHtmlContent();
						}
						emailMsg.setMsgBody(content);
						emailMsg.setAttachments(getAttachments(mp));
					}

					if (deleteMsg)
						msg.setFlag(Flags.Flag.DELETED, true);

					inbox.close(true);
					store.close();
					break;

				} else {
					Sleep.seconds(1);
					inbox.close(true);
					store.close();
				}
			}
			if (!isFound) {
				throw new RuntimeException("Email message for " + searchFor + " not found");
			}
		} catch (Exception e) {
			log.error("Problem fetching email " + e.getMessage());
			throw new RuntimeException(e);
		}

		return emailMsg;
	}

	public List<Attachment> getAttachments(Multipart mp) {
		List<Attachment> attachments = new ArrayList<>();
		try {
			int numberOfParts = mp.getCount();
			for (int i = 0; i < numberOfParts; i++) {
				MimeBodyPart part = (MimeBodyPart) mp.getBodyPart(i);
				if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) {
					Attachment attachment = new Attachment();
					attachment.setAttachmentName(part.getFileName());
					File file = new File(part.getFileName());
					FileUtils.copyInputStreamToFile(part.getInputStream(), file);
					attachment.setAttachmentFile(file);
					attachments.add(attachment);
				}
			}
		} catch (MessagingException e) {
			log.error("Problem fetching attachment" + e.getMessage());
		} catch (IOException e) {
			log.error("Problem reading messageBody" + e.getMessage());
		}

		return attachments;
	}

	public void deleteMessages() {
		deleteEmailsOlderThanToday();
		deleteEmailsFromToday(1);
	}

	private void deleteEmailsOlderThanToday() {
		try {
			Store store = createSession();

			Folder folder = store.getFolder("inbox");
			folder.open(Folder.READ_WRITE);
			Date date = new Date();
			SearchTerm olderThan = new ReceivedDateTerm(ComparisonTerm.LT, date);
			Message[] messages = folder.search(olderThan);
			log.info("Messages to Delete older than today :" + messages.length);
			for (Message message : messages) {
				log.info("deleting message older than today with subject " + message.getSubject());
				message.setFlag(Flags.Flag.DELETED, true);
			}
			folder.close(true);
			store.close();
		} catch (MessagingException e) {
			log.info("Problem reading Messages" + e.getMessage());
			e.printStackTrace();
		}
	}

	private void deleteEmailsFromToday(int hoursAgo) {
		try {

			Store store = createSession();

			Folder folder = store.getFolder("inbox");
			folder.open(Folder.READ_WRITE);
			// IMAP does not allow search by time so will be checking each email time before
			// deleting
			Date date = new Date();

			SearchTerm today = new ReceivedDateTerm(ComparisonTerm.EQ, date);
			long timeIntervalForDelete = hoursAgo * 3600000L;
			long timeAgo = System.currentTimeMillis() - timeIntervalForDelete;

			Message[] messages = folder.search(today);
			log.info("Total Messages from today :" + messages.length);
			for (Message message : messages) {
				if (message.getReceivedDate().getTime() < timeAgo) {
					log.info("Deleting message from today with subject " + message.getSubject());
					message.setFlag(Flags.Flag.DELETED, true);
				}
			}
			folder.close(true);
			store.close();

		} catch (MessagingException e) {
			log.info("Problem reading Messages" + e.getMessage());
		}
	}

	private Store createSession() throws MessagingException {

		Properties props = new Properties();
		props.put("mail.store.protocol", "imaps");

		Session session = Session.getDefaultInstance(props, null);

		Store store = session.getStore("imaps");
		store.connect("imap.gmail.com", email, password);
		return store;
	}
}