package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonValue;

/*
    There are two roles in application. Third role, Admin, is a Field tech with is_admin flag on
 */
public enum EmployeeRole {

    FIELD_TECH("Field Tech"),
    OFFICE_STAFF("Office Staff");

    private final String value;

    EmployeeRole(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return value;
    }

}
