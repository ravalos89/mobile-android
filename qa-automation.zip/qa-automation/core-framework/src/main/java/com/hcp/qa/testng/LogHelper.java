package com.hcp.qa.testng;

import java.util.Arrays;

import org.testng.ITestResult;

public class LogHelper {

    public static void log(String string) {
        System.out.println(string);
    }

    public static void printLine() {
        System.out.println("============================================================");
    }

    public static void logHcpStackTrace(ITestResult result) {
        log("------------------------------------------------------------");
        log("HCP stack trace: ");
        Arrays.stream(result.getThrowable().getStackTrace()).filter(line -> line.getClassName().contains("hcp")).forEach(System.out::println);
    }
}
