package com.hcp.qa.models;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Job {

    private String id;
    @JsonProperty("invoice_number")
    private String invoiceNumber;
    private String description;
    private Customer customer;
    private Address address;
    private String note;
    @JsonProperty("work_status")
    private String workStatus;
    @JsonProperty("work_timestamps")
    private WorkTimestamps workTimeStamps;
    public Schedule schedule;
    @JsonProperty("total_amount")
    private double totalAmount;
    @JsonProperty("outstanding_balance")
    private double outstandingBalance;
    @JsonProperty("original_estimate_id")
    private String originalEstimateId;
    @JsonProperty("assigned_employees")
    private List<Employee> assignedEmployees;

    //Create Job
    @JsonProperty("customer_id")
    private String customerId;
    @JsonProperty("address_id")
    private String addressId;

    @JsonProperty("assigned_employee_ids")
    private List<String> assignedEmployeeIds;
    @JsonProperty("line_items")
    private List<LineItem> lineItems;
    private List<String> tags;
    @JsonProperty("lead_source")
    private String leadSource;

    public void addLineItem(LineItem lineItem) {
        if(lineItems == null) {
            lineItems = new ArrayList<>();
        }
        lineItems.add(lineItem);
    }
}