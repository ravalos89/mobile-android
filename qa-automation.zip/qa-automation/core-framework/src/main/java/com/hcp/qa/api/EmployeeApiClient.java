package com.hcp.qa.api;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.models.EmployeePayload;
import com.hcp.qa.models.ftu.OnboardingCurrentPage;
import com.hcp.qa.models.ftu.OnboardingStage;
import com.hcp.qa.models.ftu.OnboardingUpdatePayload;
import com.hcp.qa.models.login.EmployeeData;
import com.hcp.qa.models.login.LoginData;
import com.hcp.qa.models.mobile.Event;
import com.hcp.qa.models.mobile.customer.CustomerPayload;
import com.hcp.qa.models.mobile.estimate.EstimatePayload;
import com.hcp.qa.models.mobile.events.EventsPayload;
import com.hcp.qa.models.mobile.job.AssignJob;
import com.hcp.qa.models.mobile.job.JobPayload;
import com.hcp.qa.models.mobile.job.Schedule;
import com.hcp.qa.models.mobile.job.status.OmwJobPayload;
import com.hcp.qa.models.mobile.job.status.StartJobPayload;
import com.hcp.qa.models.mobile.task.TaskPayload;
import com.hcp.qa.models.search.CalendarItemsSearchQuery;
import com.hcp.qa.models.search.CustomerSearchQuery;
import io.restassured.response.Response;

import static java.lang.String.format;
import static org.apache.http.HttpStatus.SC_CREATED;
import static org.apache.http.HttpStatus.SC_OK;

public class EmployeeApiClient {
    private static final String JOBS_ENDPOINT = "/alpha/jobs/";
    private static final String PRO_LOG_IN = "/api/pros/log_in";
    private static final String DELETE_EVENT_ENDPOINT = "/api/pros/event/%d/delete";
    private static final String EVENTS_ENDPOINT = "/api/pros/event/create_or_update";
    private static final String DISPATCHABLE_PROS_ENDPOINT = "/api/pros/dispatchable_pros";
    private static final String ORGANIZATION_CALENDAR_ITEMS_ENDPOINT = "/alpha/organization/calendar/calendar_items";
    private static final String EMPLOYEE_ENDPOINT = "/alpha/organization/employees/";
    private static final String ASSIGN_JOB_ENDPOINT = "/alpha/jobs/%s/assign";
    private static final String SCHEDULE_JOB_ENDPOINT = "/alpha/jobs/%s/schedule";
    private static final String CUSTOMERS_ENDPOINT = "/alpha/customers";
    private static final String TASKS_ENDPOINT = "/api/pros/tasks";
    private static final String UPDATE_FTU_STATE_ENDPOINT = "/alpha/onboardings";
    private static final String START_JOB_AS_PRO_ENDPOINT = "/alpha/jobs/%s/dispatched_pros/%s/start";
    private static final String OMW_JOB_AS_PRO_ENDPOINT = "/alpha/jobs/%s/dispatched_pros/%s/on_my_way";
    private static final String FINISH_JOB_ENDPOINT = "/alpha/jobs/%s/finish";
    private static final String ALPHA_EVENTS_ENDPOINT = "/alpha/scheduling/events";
    private static final String ALPHA_ESTIMATES = "/alpha/estimates";
    private HttpRequestClient client;

    public EmployeeApiClient(String employeeAccessKey) {
        String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
        this.client = new HttpRequestClient(baseUrl, employeeAccessKey);
    }

    public EmployeeApiClient(String email, String password) {
        this(new LoginData(email, password));
    }

    private String getUnregisteredUserToken() {
        String unregisteredUserToken = ConfigHandler.getStringPropertyValueFromKey("hcp.web.unregistered.user.token");
        if (unregisteredUserToken == null) {
            throw new RuntimeException("Missing token for unregistered user");
        }
        return unregisteredUserToken;
    }

    public EmployeeApiClient(LoginData loginData) {
        String baseUrl = ConfigHandler.getStringPropertyValueFromKey("hcp.web.pro.base.url");
        EmployeeData employeeData = new HttpRequestClient(baseUrl, getUnregisteredUserToken())
                .postUrl(PRO_LOG_IN, loginData, SC_OK).getBody().as(EmployeeData.class);
        client = new HttpRequestClient(baseUrl, employeeData.getApiKey());
    }

    public EmployeeApiClient setAccessKey(String employeeAccessKey) {
        this.client = new HttpRequestClient(employeeAccessKey);
        return this;
    }

    public Response deleteJobOrEstimate(String longJobId) {
        return client.deleteUrl(JOBS_ENDPOINT + longJobId, SC_OK);
    }

    public Response deleteEvent(String eventId) {
        return deleteEvent(Integer.parseInt(eventId));
    }

    public Response deleteEvent(int eventId) {
        return client.postUrl(format(DELETE_EVENT_ENDPOINT, eventId), SC_OK);
    }

    public Response createEvent(Event event) {
        return client.postUrl(EVENTS_ENDPOINT, event, SC_OK);
    }

    public Response getPros() {
        return client.getUrl(DISPATCHABLE_PROS_ENDPOINT, SC_OK);
    }

    public Response getCalendarItems(CalendarItemsSearchQuery query) {
        return client.getWithQueryParams(query, ORGANIZATION_CALENDAR_ITEMS_ENDPOINT);
    }

    public Response deleteEmployee(String proId) {
        return client.deleteUrl(EMPLOYEE_ENDPOINT + proId, SC_OK);
    }

    public Response createEmployee(EmployeePayload employee) {
        return client.postForm(EMPLOYEE_ENDPOINT, employee);
    }

    public Response assignJob(String jobLongId, AssignJob assignJobDto) {
        return client.putUrl(format(ASSIGN_JOB_ENDPOINT, jobLongId), assignJobDto, SC_OK);
    }

    public Response createJob(JobPayload job) {
        return client.postUrl(JOBS_ENDPOINT, job, SC_CREATED);
    }

    public Response createSchedule(String jobLongId, Schedule schedule) {
        return client.putUrl(format(SCHEDULE_JOB_ENDPOINT, jobLongId), schedule, SC_OK);
    }

    public Response getCustomers(CustomerSearchQuery query) {
        return client.getWithQueryParams(query, CUSTOMERS_ENDPOINT);
    }

    public Response createCustomer(CustomerPayload customer){
        return client.postUrl(CUSTOMERS_ENDPOINT, customer, SC_CREATED);
    }

    public Response createTask(TaskPayload task) {
        return client.putUrl(TASKS_ENDPOINT + "/" + task.getId(), task, SC_OK);
    }

    public Response getTasks() {
        return client.getUrl(TASKS_ENDPOINT, SC_OK);
    }

    public Response updateFtuState(OnboardingStage stage, OnboardingCurrentPage currentPage) {
        return client.putUrl(UPDATE_FTU_STATE_ENDPOINT, new OnboardingUpdatePayload(stage, currentPage), SC_OK);
    }

    public Response startJobAsEmployee(String longJobId, String longProId, StartJobPayload body) {
        String formattedEndpoint = format(START_JOB_AS_PRO_ENDPOINT, longJobId, longProId);
        return client.postUrl(formattedEndpoint, body, SC_OK);
    }

    public Response turnOmwOnJobForPro(String longJobId, String longProId, OmwJobPayload body) {
        String formattedEndpoint = format(OMW_JOB_AS_PRO_ENDPOINT, longJobId, longProId);
        return client.postUrl(formattedEndpoint, body, SC_OK);
    }

    public Response finishJob(String longJobId) {
        String formattedEndpoint = format(FINISH_JOB_ENDPOINT, longJobId);
        return client.postUrl(formattedEndpoint, SC_OK);
    }

    public Response createEventThroughAlpha(EventsPayload event) {
        return client.postUrl(ALPHA_EVENTS_ENDPOINT, event, SC_OK);
    }

    public Response getEventThroughAlpha(int eventId, int status) {
        return client.getUrl(ALPHA_EVENTS_ENDPOINT + "/" + eventId, status);
    }

    public Response createEstimate(EstimatePayload payload) {
        return client.postForm(ALPHA_ESTIMATES, payload);
    }
}
