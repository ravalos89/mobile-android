package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WorkTimestamps {
    @JsonProperty("on_my_way_at")
    private String onMyWayAt = null;
    @JsonProperty("started_at")
    private String startedAt = null;
    @JsonProperty("completed_at")
    private String completedAt = null;

    public String getOnMyWayAt() {
        return onMyWayAt;
    }

    public WorkTimestamps setOnMyWayAt(String onMyWayAt) {
        this.onMyWayAt = onMyWayAt;
        return this;
    }

    public String getStartedAt() {
        return startedAt;
    }

    public WorkTimestamps setStartedAt(String startedAt) {
        this.startedAt = startedAt;
        return this;
    }

    public String getCompletedAt() {
        return completedAt;
    }

    public WorkTimestamps setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
        return this;
    }
}
