package com.hcp.qa.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
    private String id;
    private String type;
    private String street;
    @JsonProperty("street_line_2")
    private String streetLine2;
    private String city;
    private String state;
    private String zip;
    private String country;
}
