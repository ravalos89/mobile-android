package com.hcp.qa.gmail;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class AttachmentUtils {
	private static Logger LOG = LoggerFactory.getLogger(AttachmentUtils.class);

	public static String getTextFromPdf(File file) {
		try {
			InputStream is = new FileInputStream(file);
			PdfReader reader = new PdfReader(is);

			String textFromPdf = PdfTextExtractor.getTextFromPage(reader, 1);
			Files.deleteIfExists(file.toPath());
			return textFromPdf;
		} catch (IOException e) {
			LOG.error("Error reading pdf document. " + e.getMessage());
		}
		return null;
	}

	public static List<String> getRows(File file) {
		List<String> rows = new ArrayList<String>();
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));

			String row;
			while ((row = br.readLine()) != null)
				rows.add(row);

			Files.deleteIfExists(file.toPath());
		} catch (FileNotFoundException e) {
			LOG.error("Problem loading file " + e.getMessage());
		} catch (IOException e) {
			LOG.error("Problem reading file " + e.getMessage());
		}

		return rows;

	}

	public static void deleteFiles(List<Attachment> attachments) {
		for (Attachment attachment : attachments) {
			try {
				Files.deleteIfExists(attachment.getAttachmentFile().toPath());
			} catch (IOException e) {
				LOG.error("Problem deleting files from local storage" + e.getMessage());
			}
		}
	}

}
