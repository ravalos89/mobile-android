package com.hcp.qa.models;

import java.util.HashMap;
import java.util.Map;

import com.hcp.qa.models.mobile.FormDataPayload;

public class EmployeePayload implements FormDataPayload {

    private final String FIRST_NAME_KEY = "first_name";
    private final String LAST_NAME_KEY = "last_name";
    private final String FULL_NAME_KEY = "full_name";
    private final String EMAIL_KEY = "email";
    private final String MOBILE_NUMBER_KEY = "mobile_number";
    private final String ROLE_KEY = "role";
    private final String INITIALS_KEY = "initials";
    private final String COLOR_HEX_KEY = "color_hex";
    private final String PASSWORD_KEY = "password";
    private final String SHOW_COMPANY_SETUP_KEY = "permissions[show_company_setup]";
    private final String SHOW_CUSTOMERS_KEY = "permissions[show_customers]";
    private final String CAN_CHAT_WITH_CUSTOMERS_KEY = "permissions[can_chat_with_customers]";
    private final String CAN_CALL_AND_TEXT_WITH_CUSTOMERS = "permissions[can_call_and_text_with_customers]";
    private final String CAN_BE_BOOKED_ONLINE_KEY = "permissions[can_be_booked_online]";
    private final String SHOW_FUTURE_JOBS_KEY = "permissions[show_future_jobs]";
    private final String SHOW_FULL_SCHEDULE_KEY = "permissions[show_full_schedule]";
    private final String CAN_SHARE_JOB_KEY = "permissions[can_share_job]";
    private final String CAN_ADD_AND_EDIT_JOB_KEY = "permissions[can_add_and_edit_job]";
    private final String CAN_DELETE_AND_CANCEL_JOB_KEY = "permissions[can_delete_and_cancel_job]";
    private final String SHOW_REPORTING_KEY = "permissions[show_reporting]";
    private final String CAN_EDIT_MESSAGE_ON_INVOICE_KEY = "permissions[can_edit_message_on_invoice]";
    private final String CAN_TAKE_PAYMENT_SEE_PRICES_KEY = "permissions[can_take_payment_see_prices]";
    private final String CAN_SEE_HOME_DATA_KEY = "permissions[can_see_home_data]";
    private final String CAN_EDIT_COMMUNICATION_SETTINGS = "permissions[can_edit_communication_settings]";
    private final String CAN_RECEIVE_CALL_NOTIFICATIONS_KEY = "permissions[can_receive_call_notifications]";
    private final String IS_ADMIN_KEY = "permissions[is_admin]";

    private final Map<String, Object> formParameters = new HashMap<>();

    public String getFirstName() {
        return String.valueOf(formParameters.get(FIRST_NAME_KEY));
    }

    public EmployeePayload setFirstName(String firstName) {
        formParameters.put(FIRST_NAME_KEY, firstName);
        return this;
    }

    public String getLastName() {
        return String.valueOf(formParameters.get(LAST_NAME_KEY));
    }

    public EmployeePayload setLastName(String lastName) {
        formParameters.put(LAST_NAME_KEY, lastName);
        return this;
    }

    public String getFullName() {
        return String.valueOf(formParameters.get(FULL_NAME_KEY));
    }

    public EmployeePayload setFullName(String fullName) {
        formParameters.put(FULL_NAME_KEY, fullName);
        return this;
    }

    public String getEmail() {
        return String.valueOf(formParameters.get(EMAIL_KEY));
    }

    public EmployeePayload setEmail(String email) {
        formParameters.put(EMAIL_KEY, email);
        return this;
    }

    public String getMobileNumber() {
        return String.valueOf(formParameters.get(MOBILE_NUMBER_KEY));
    }

    public EmployeePayload setMobileNumber(String mobileNumber) {
        formParameters.put(MOBILE_NUMBER_KEY, mobileNumber);
        return this;
    }

    public EmployeeRole getRole() {
        return EmployeeRole.valueOf(String.valueOf(formParameters.get(ROLE_KEY)));

    }

    public EmployeePayload setRole(EmployeeRole employeeRole) {
        formParameters.put(ROLE_KEY, employeeRole.toString());
        return this;
    }

    public String getInitials() {
        return String.valueOf(formParameters.get(INITIALS_KEY));
    }

    public EmployeePayload setInitials(String initials) {
        formParameters.put(INITIALS_KEY, initials);
        return this;
    }

    public String getColorHex() {
        return String.valueOf(formParameters.get(COLOR_HEX_KEY));
    }

    public EmployeePayload setColorHex(String colorHex) {
        formParameters.put(COLOR_HEX_KEY, colorHex);
        return this;
    }

    public String getPassword() {
        return String.valueOf(formParameters.get(PASSWORD_KEY));
    }

    public EmployeePayload setPassword(String password) {
        formParameters.put(PASSWORD_KEY, password);
        return this;
    }

    public boolean getShowCompanySetup() {
        return (boolean) formParameters.get(SHOW_COMPANY_SETUP_KEY);
    }

    public EmployeePayload setShowCompanySetup(boolean showCompanySetup) {
        formParameters.put(SHOW_COMPANY_SETUP_KEY, showCompanySetup);
        return this;
    }

    public boolean getShowCustomers() {
        return (boolean) formParameters.get(SHOW_CUSTOMERS_KEY);
    }

    public EmployeePayload setShowCustomers(boolean showCustomers) {
        formParameters.put(SHOW_CUSTOMERS_KEY, showCustomers);
        return this;
    }

    public boolean getCanChatWithCustomers() {
        return (boolean) formParameters.get(CAN_CHAT_WITH_CUSTOMERS_KEY);
    }

    public EmployeePayload setCanChatWithCustomers(boolean canChatWithCustomers) {
        formParameters.put(CAN_CHAT_WITH_CUSTOMERS_KEY, canChatWithCustomers);
        return this;
    }

    public String getCanCallAndTextWithCustomers() {
        return (String) formParameters.get(CAN_CALL_AND_TEXT_WITH_CUSTOMERS);
    }

    public EmployeePayload setCanCallAndTextWithCustomers(boolean canCallAndTextWithCustomers) {
        formParameters.put(CAN_CALL_AND_TEXT_WITH_CUSTOMERS, canCallAndTextWithCustomers);
        return this;
    }

    public boolean getCanBeBookedOnline() {
        return (boolean) formParameters.get(CAN_BE_BOOKED_ONLINE_KEY);
    }

    public EmployeePayload setCanBeBookedOnline(boolean canBeBookedOnline) {
        formParameters.put(CAN_BE_BOOKED_ONLINE_KEY, canBeBookedOnline);
        return this;
    }

    public boolean getShowFutureJobs() {
        return (boolean) formParameters.get(SHOW_FUTURE_JOBS_KEY);
    }

    public EmployeePayload setShowFutureJobs(boolean showFutureJobs) {
        formParameters.put(SHOW_FUTURE_JOBS_KEY, showFutureJobs);
        return this;
    }

    public boolean getShowFullSchedule() {
        return (boolean) formParameters.get(SHOW_FULL_SCHEDULE_KEY);
    }

    public EmployeePayload setShowFullSchedule(boolean showFullSchedule) {
        formParameters.put(SHOW_FULL_SCHEDULE_KEY, showFullSchedule);
        return this;
    }

    public boolean getCanShareJob() {
        return (boolean) formParameters.get(CAN_SHARE_JOB_KEY);
    }

    public EmployeePayload setCanShareJob(boolean canShareJob) {
        formParameters.put(CAN_SHARE_JOB_KEY, canShareJob);
        return this;
    }

    public boolean getCanAddAndEditJob() {
        return (boolean) formParameters.get(CAN_ADD_AND_EDIT_JOB_KEY);
    }

    public EmployeePayload setCanAddAndEditJob(boolean canShareJob) {
        formParameters.put(CAN_ADD_AND_EDIT_JOB_KEY, canShareJob);
        return this;
    }

    public boolean getCanDeleteAndCancelJob() {
        return (boolean) formParameters.get(CAN_DELETE_AND_CANCEL_JOB_KEY);
    }

    public EmployeePayload setCanDeleteAndCancelJob(boolean canDeleteAndCancelJob) {
        formParameters.put(CAN_DELETE_AND_CANCEL_JOB_KEY, canDeleteAndCancelJob);
        return this;
    }

    public boolean getShowReporting() {
        return (boolean) formParameters.get(SHOW_REPORTING_KEY);
    }

    public EmployeePayload setShowReporting(boolean showReporting) {
        formParameters.put(SHOW_REPORTING_KEY, showReporting);
        return this;
    }

    public boolean getCanEditMessageOnInvoice() {
        return (boolean) formParameters.get(CAN_EDIT_MESSAGE_ON_INVOICE_KEY);
    }


    public EmployeePayload setCanEditMessageOnInvoice(boolean canEditMessageOnInvoice) {
        formParameters.put(CAN_EDIT_MESSAGE_ON_INVOICE_KEY, canEditMessageOnInvoice);
        return this;
    }

    public boolean getCanTakePaymentSeePrices() {
        return (boolean) formParameters.get(CAN_TAKE_PAYMENT_SEE_PRICES_KEY);
    }

    public EmployeePayload setCanTakePaymentSeePrices(boolean canTakePaymentSeePrices) {
        formParameters.put(CAN_TAKE_PAYMENT_SEE_PRICES_KEY, canTakePaymentSeePrices);
        return this;
    }

    public boolean getCanSeeHomeData() {
        return (boolean) formParameters.get(CAN_SEE_HOME_DATA_KEY);
    }

    public EmployeePayload setCanSeeHomeData(boolean canSeeHomeData) {
        formParameters.put(CAN_SEE_HOME_DATA_KEY, canSeeHomeData);
        return this;
    }

    public boolean getCanEditCommunicationSettings() {
        return (boolean) formParameters.get(CAN_EDIT_COMMUNICATION_SETTINGS);
    }

    public EmployeePayload setCanEditCommunicationSettings(boolean canEditCommunicationSettings) {
        formParameters.put(CAN_EDIT_COMMUNICATION_SETTINGS, canEditCommunicationSettings);
        return this;
    }

    public boolean getCanReceiveCallNotifications() {
        return (boolean) formParameters.get(CAN_RECEIVE_CALL_NOTIFICATIONS_KEY);
    }

    public EmployeePayload setCanReceiveCallNotifications(boolean canReceiveCallNotifications) {
        formParameters.put(CAN_RECEIVE_CALL_NOTIFICATIONS_KEY, canReceiveCallNotifications);
        return this;
    }

    public boolean getIsAdmin() {
        return (boolean) formParameters.get(IS_ADMIN_KEY);
    }

    public EmployeePayload setIsAdmin(boolean isAdmin) {
        formParameters.put(IS_ADMIN_KEY, isAdmin);
        return this;
    }

    public EmployeePayload setAllPermissionOn() {
        boolean value = true;
        return this.setIsAdmin(value)
                .setCanReceiveCallNotifications(value)
                .setCanEditCommunicationSettings(value)
                .setCanSeeHomeData(value)
                .setCanTakePaymentSeePrices(value)
                .setCanEditMessageOnInvoice(value)
                .setShowReporting(value)
                .setCanDeleteAndCancelJob(value)
                .setCanAddAndEditJob(value)
                .setCanShareJob(value)
                .setShowFullSchedule(value)
                .setShowFutureJobs(value)
                .setCanBeBookedOnline(value)
                .setCanCallAndTextWithCustomers(value)
                .setCanChatWithCustomers(value)
                .setShowCustomers(value)
                .setShowCompanySetup(value);
    }

    @Override
    public Map<String, ?> getSingleValueParameters() {
        return formParameters;
    }
}
