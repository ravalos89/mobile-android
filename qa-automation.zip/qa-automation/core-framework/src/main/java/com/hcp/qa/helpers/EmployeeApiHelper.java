package com.hcp.qa.helpers;

import com.hcp.qa.api.EmployeeApiClient;
import com.hcp.qa.models.login.LoginData;
import com.hcp.qa.models.mobile.pros.OrganizationPros;

public class EmployeeApiHelper {

    private final EmployeeApiClient client;

    public EmployeeApiHelper(EmployeeApiClient employeeApiClient) {
        client = employeeApiClient;
    }

    public EmployeeApiHelper(LoginData loginData) {
        client = new EmployeeApiClient(loginData);
    }

    public EmployeeApiHelper(String email, String password) {
        client = new EmployeeApiClient(email, password);
    }

    public String getOwnerEmployeeId() {
        return client.getPros().as(OrganizationPros.class)
                .getDispatchablePros()
                .get(0).getUuid();
    }

}
