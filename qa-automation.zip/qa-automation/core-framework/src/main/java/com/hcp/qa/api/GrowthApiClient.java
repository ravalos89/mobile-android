package com.hcp.qa.api;

import org.apache.http.HttpStatus;

import com.hcp.qa.common.ConfigHandler;
import com.hcp.qa.models.growth.SignUp;

import io.restassured.response.Response;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class GrowthApiClient {

    private final HttpRequestClient client;

    private final String LEADS_SIGN_UP_ENDPOINT = "/leads/sign_up";

    public GrowthApiClient() {
        String baseUrl = ConfigHandler.getStringPropertyValueFromKey("public.growth.server");
        this.client = new HttpRequestClient(baseUrl);
    }

    public Response createOrganization(SignUp signUp) {
        log.info("Creating pro with email: " + signUp.getEmail());
        return client.postUrl(LEADS_SIGN_UP_ENDPOINT, signUp, HttpStatus.SC_OK);
    }





}
