package com.hcp.qa.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeResponse {

    private String object;
    private String id;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("full_name")
    private String fullName;
    private String name;
    private String email;
    @JsonProperty("mobile_number")
    private String mobileNumber;
    @JsonProperty("organization_name")
    private String organizationName;
    @JsonProperty("is_admin")
    private boolean isAdmin;
    private String role;
    private String initials;
    private String avatar;
    @JsonProperty("avatar_thumb_web")
    private String avatarThumbWeb;
    private boolean archived;
    @JsonProperty("map_avatar")
    private String mapAvatar;
    @JsonProperty("map_pin")
    private String mapPin;
    @JsonProperty("color_hex")
    private String colorHex;
    private List<String> tags;
}
