package com.hcp.qa.common;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigHandler extends CompositeConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigHandler.class);

    private static CompositeConfiguration config;
    private static String targetEnv = System.getProperty("targetEnv", "qa");
    private static final String CONFIG_DIR = "config/";
    private static final String CONFIG_FILE_EXT = ".properties";

    public static String getStringPropertyValueFromKey(String propertyKey){
        return getConfig().getString(propertyKey);
    }

    public static int getIntegerPropertyValueFromKey(String propertyKey){
        return getConfig().getInt(propertyKey);
    }

    public static boolean getBooleanPropertyValueFromKey(String propertyKey){
        return getConfig().getBoolean(propertyKey);
    }

    private static void loadConfiguration(final String extension) throws ConfigurationException {
        config = new CompositeConfiguration();
        String targetEnvFile = CONFIG_DIR + targetEnv + CONFIG_FILE_EXT;
        LOG.info("Using environment properties [" + targetEnvFile + "]");
        try{
            config.addConfiguration(new PropertiesConfiguration(targetEnvFile));
        }catch(Exception ex){
            LOG.error("Loading config failed "+ ex.getMessage());
        }
    }

    public static Configuration getConfig() {
        return getConfig(targetEnv);
    }

    public static Configuration getConfig(final String extension) {
        if (config == null) {
            try {
                loadConfiguration(extension);
            } catch (ConfigurationException e) {
                e.printStackTrace();
            }
        }
        return config;
    }

    public static String getTargetEnv() {
        return targetEnv;
    }

    public static void setTargetEnv(String targetEnv) {
        ConfigHandler.targetEnv = targetEnv;
    }
}

