package com.hcp.qa.models;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcp.qa.api.ApiDateTimeFormatter;

public class Schedule {
    @JsonProperty("scheduled_start")
    private String scheduledStart = null;
    @JsonProperty("scheduled_end")
    private String scheduledEnd = null;
    @JsonProperty("arrival_window")
    private String arrivalWindow;


    // Getter Methods

    private String getDateTimeInGmt0(LocalDateTime scheduledTime) {
        return ApiDateTimeFormatter.formatLocalTimeToGmtTime(scheduledTime);
    }

    // Setter Methods
    @JsonProperty
    public void setScheduledStart(String scheduled_start) {
        this.scheduledStart = scheduled_start;
    }

    public void setScheduledStart(LocalDateTime scheduledStart) {
        this.scheduledStart = getDateTimeInGmt0(scheduledStart);
    }

    public void setScheduledEnd(LocalDateTime scheduledEnd) {
        this.scheduledEnd = getDateTimeInGmt0(scheduledEnd);
    }

    public void setScheduledStart(ZonedDateTime scheduledStart) {
        this.scheduledStart = ApiDateTimeFormatter.formatZonedTimeToGmtTime(scheduledStart);
    }

    public void setScheduledEnd(ZonedDateTime scheduledEnd) {
        this.scheduledEnd = ApiDateTimeFormatter.formatZonedTimeToGmtTime(scheduledEnd);
    }

    @JsonProperty
    public void setScheduled_end(String scheduledEnd) {
        this.scheduledEnd = scheduledEnd;
    }

    public void setArrivalWindow(String arrivalWindow) {
        this.arrivalWindow = arrivalWindow;
    }

    public String getScheduledStart() {
        return scheduledStart;
    }

    public String getScheduledEnd() {
        return scheduledEnd;
    }

    public Schedule setScheduledEnd(String scheduledEnd) {
        this.scheduledEnd = scheduledEnd;
        return this;
    }

    public String getArrivalWindow() {
        return arrivalWindow;
    }
}
