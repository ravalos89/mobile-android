package com.hcp.qa.android;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.hcp.qa.android.helpers.LoginHelper;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;

import static java.time.Duration.ofSeconds;

public abstract class BaseAndroidTest {
	private static final Logger LOG = LoggerFactory.getLogger(BaseAndroidTest.class);

	private static AppiumDriverLocalService service;

	private String androidSDKRoot = System.getenv("ANDROID_SDK_ROOT");
	private String javaHome = System.getenv("JAVA_HOME");
	private String appiumHome = System.getenv("APPIUM_HOME");
	private String apkPath = System.getenv("BITRISE_APK_PATH");

	protected static AndroidDriver driver;

	protected static LoginHelper loginHelper;
	
	protected String lineItemName = "Test Line Item";

	@BeforeSuite
	public void setupSuite() throws IOException {
		LOG.info("BITRISE_APK_PATH: " + apkPath);
		LOG.info("JAVA_HOME: " + javaHome);
		LOG.info("Appium_Home: " + appiumHome);
		LOG.info("ANDROID_SDK_ROOT: " + androidSDKRoot);

		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability("deviceReadyTimeout", 160);
		capabilities.setCapability("deviceName", "Android Emulator"); // This is a required element but ignored by
																		// appium
		capabilities.setCapability("unlockType", "pin");
		capabilities.setCapability("unlockKey", "0000");
		
		capabilities.setCapability("app", apkPath);
		capabilities.setCapability("appActivity", "housecall.pros.launcher.LauncherActivity");
		capabilities.setCapability("appWaitActivity", "housecall.pros.onboarding.SignupLoginOnboardingActivity");
		capabilities.setCapability("appium:automationName", "UIAutomator2");

		capabilities.setCapability("adbExecTimeout", "90000");
		capabilities.setCapability("androidInstallTimeout", "180000");
		
		capabilities.setCapability("appium:uiautomator2ServerLaunchTimeout", "90000");
		capabilities.setCapability("appium:ignoreHiddenApiPolicyError", true);
		capabilities.setCapability("appium:appWaitForLaunch", true);
	
		capabilities.setCapability("autoGrantPermissions", "true");
		driver = new AndroidDriver(new URL("http://0.0.0.0:4723/"), capabilities);
	
		driver.manage().timeouts().implicitlyWait(ofSeconds(5));
		loginHelper = new LoginHelper(driver);
		loginHelper.login();
	}

	@AfterSuite(alwaysRun = true)
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
		if (service != null) {
			service.stop();
		}
	}

	public URL getServiceUrl() {
		return service.getUrl();
	}

	public void takeScreenShot(String name) {
		File screenshotLocation;
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String path = "screenshots/" + name + "_" + UUID.randomUUID() + ".png";

		screenshotLocation = new File(System.getProperty("user.dir") + File.separator + path);
		try {
			FileUtils.copyFile(scrFile, screenshotLocation);
		} catch (IOException e) {
			LOG.error("Failed to create screen shot file :" + e.getMessage());
		}

		LOG.info(screenshotLocation.toString());

	}
	
	public void restartApp() {
		driver.launchApp();
		loginHelper.login();
	}

}
