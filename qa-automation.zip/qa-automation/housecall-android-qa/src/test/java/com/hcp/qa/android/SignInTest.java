package com.hcp.qa.android;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.hcp.qa.android.pages.common.BottomNavigationMenu;

public class SignInTest extends BaseAndroidTest {

	protected static Logger LOG = LoggerFactory.getLogger(SignInTest.class);

	@Test
	public void signIn() {
		BottomNavigationMenu bottomMenu = new BottomNavigationMenu(driver);
		bottomMenu.clickDashboard();
		Assert.assertEquals(driver.currentActivity(), "housecall.pros.pro.DashboardActivity", "Unexpected Activity");
	}

}
