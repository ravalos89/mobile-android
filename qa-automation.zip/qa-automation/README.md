# System Requirements

Install Java  
<https://docs.oracle.com/en/java/javase/15/install/installation-jdk-macos.html#GUID-F575EB4A-70D3-4AB4-A20E-DBE95171AB5F>

	'#Set JAVA Home'
	'export JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk-15.0.1.jdk/Contents/Home'

Install Maven  
<https://maven.apache.org/install.html>

	'# Add maven to path'
	'export PATH=$PATH:$HOME/maven/apache-maven-3.6.3/bin'

Install Chrome

Clone the Git Project to your local directory
  
To run all the tests  
>	mvn test

#### Tools used for the automation framework
* TestNG  
<https://testng.org/doc/documentation-main.html>  
* Selenium WebDriver  
<https://www.javadoc.io/doc/org.seleniumhq.selenium/selenium-api/2.50.1/org/openqa/selenium/WebDriver.html>  
* RestAssured  
<https://rest-assured.io/>
	
### Best Practices
* Always put the JIRA Ticket in the commit if available.
* Run tests using command line before checking in code
* Do not use test in the test method name .
* When naming a test class use the resource name followed by functionality being tested  eg for Job JobCreationTests, JobNotificationTests
* Make all Page WebElement member variables private
* Remove Unused imports
* Use A static Analysis tool like FindBugs to 
* Remove any dead/unused code. Do not leave commented code blocks.Use enabled attribute of the @Test annotation if you don't want to run the test . 
* When adding a test case to test NG file add it as a `</class>` rather than package as the logs are cleaner and test organization is easier if the tesNg file has to be split.

There are three modules for this project
* Core framework
* Web Automation
* API Automation

#### Core Framework:
This module contains all the common utilities used across projects

 * **TestNG customization**   
 	- Retry Analyzer for retrying a test on failure.Currently set to 3  
	- Custom listener for actions on beginning on ending of a test/Suite or on success or failure
 		
 * **JSON Parsing**  
 	- Marshalling and unmarshalling of JSON using Jackson parser
 
 * **Configuration handling**  
 	- Reading properties from configuration files. By default, the properties will be read from staging.properties file created in the module. But user can set the file to be used using the environment variable  "-DtargetEnv=production" while running the tests.
 		 
 * **URL Handler**   
 	- Creation of URLs to be used when testing API. 
 		
 * **CSV Data Providers**  
 	- Read test data from csv files.Requires the file to be named the same as test method and in the folder named packagename/classname/ in the src/test/resources folder  
 		
 * **Base Helper**  
 	- Contains common API HTTP calls  GET, PUT, DELETE, POST, PATCH
 
## Web Automation:
This module contains all the UI related tests. It requires a Docker image with the associated browser for Gitlab tests.  
Currently using this Docker image with Chrome in Gitlab:
> public.ecr.aws/s8y1p5m9/housecall/qa/housecall-web-qa-tools:LATEST

  
**Webdriver Manager**  
The Webdriver manager is used to select the appropriate webriver for the browser installed on the machine  
<https://github.com/bonigarcia/webdrivermanager>  

* Notes:   
	- The latest version of Safari comes with rest based webdriver so we do not need to download any exe for Safari.  
	- Safari is super slow and cannot run in headless mode so it has not been tested in gitlab.  
	- Firefox(local) and Chrome(local and Gitlab) are fully tested.  
	
**Page Object Model**  
The UI Test automation is written using the Page Object Model design pattern where the page element location and interaction is separated from testing Logic 
<https://www.selenium.dev/documentation/en/guidelines_and_recommendations/page_object_models/>  

* Use element id if available
* Use Xpath with a visual label( field label text, Menu label etc)
* Do not use full xpaths starting at html since the page structure and layout can change.
* Do not put any business logic or Assertions in the Page class
* Do not use Thread.sleep().There is implicit wait for driver which is set to 10 secs for now.
* Try using explicit wait method with condition.(use waitToBeClickable in Page class for clickable condition)
* Sometimes there is no way around using Sleep especially in headless mode. Use the waitforPageToLoad(int timeInSecs) method from Page class.Use this as a last resort as it will add to the total run time.
* If the page class is too large consider breaking it down into smaller components

### List of Apps needed for the Test Suite
* Wisetack
* Stripe
* Plaid

### Set up needed for organization/pro.
* Create the organization with XL Plan
* Organization must onboard onto Wisetack before offering loans:
	-  Go to the 'My money' tab and fully onboard onto payments. This means attaching a bank account and going through identity verification.
	-  Once you have onboarded, head over to the 'Apps' section, and navigate to the Wisetack app.
	-  Click ‘get’, this will redirect you to a new page to fill out your wisetack application.
	-  Fully fill out the Wisetack application. Important: When filling out the application, use approve wisetack as your business name. This will trigger your account to get auto verified on wisetack’s test environment.
	-  Once you have completed this, hop on the staging console and run this to finish setting up your account:
		- org = Organization.find(organization id)
		  org.organization_apps.apps_with_asset_id(App::WISETACK).last.update(state: 'enabled')
		  org.organization_preference.update(allow_consumer_financing: true)
* Setup bank account for the organization
* Create an employee
* Trun the pro-mode toggle on in the UI to disable the onboarding process.

## API Automation:
This module contains all API related tests. The document to the public API can be found here:https://housecallpro.stoplight.io/docs/housecall-public-api/reference/housecall.v1.yaml. Rest of the apis are not documented.

**Rest Assured**  
RestAssured is used to test the REST API. For further documentation please refer to:
https://rest-assured.io/
https://github.com/rest-assured/rest-assured/wiki/GettingStarted

## Mobile Automation:
### Android
### iOS

# Branching and PR process
1. Fork a branch from `qa` branch with following naming strategy
2. name must start with `feature/` and jira ticket number example `feature/QA-100-fixing-login-box`
3. Pull the changes from qa branch if you haven't already.
4. After proper validation on local system, create a PR in github.
5. After peer review, approve or reject the PR.
6. Once the PR is merged successfully to the qa branch, make sure that the regression tests are passing in gitlab.
7. For rejected PR's, fix and open a new PR for peer reviews.
8. Delete the branch after successful merge.

# QA Automation in GitLab
When ever there is a push to qa or merge to master branch in qa automation repo(https://github.com/Codefied/qa-automation), a job triggers in Gitalb (https://gitlab.housecalldev.com/housecall/qa-automation-framework) that runs the smoke test suite in staging environment.
There are 2 stages for the job in the pipeline:
* Build
* Smoke Tests
* Regression Tests

# QA Jira Board

**Link**
https://housecall.atlassian.net/secure/RapidBoard.jspa?rapidView=77

**Definition Of Done**

Ticket should be moved to Done only when:
* All tests passes locally.
* Pull request for the tests in qa branch has been reviewed and approved by atleast one pier.
* Tests are passing in qa automation pipeline for qa branch in gitlab
* Tests is merged to master.
* Tests are passing in qa automation pipeline for master branch in gitlab









